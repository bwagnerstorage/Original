import info.gridworld.actor.*;
import info.gridworld.grid.*;
import java.util.*;

public class Driver
{
    public static void main(String[] args)
    {
        UnboundedMultigrid grid = new UnboundedMultigrid();
        
        grid.put(new Location(1,1), "Bill");
        grid.put(new Location(1,1), "Tom");
        grid.put(new Location(1,1), "Steve");
        grid.put(new Location(0,1), "Mary");
        grid.put(new Location(1,2), "Karen");
        grid.put(new Location(1,2), "John");
        grid.put(new Location(2,0), "Peter");
        grid.put(new Location(2,1), "Sarah");
        grid.put(new Location(2,1), "Jose");
        grid.put(new Location(3,3), "Candace");
        
        System.out.println("Test get and put methods");
        System.out.println("-------------------------");
        
        System.out.println(grid.get(new Location(1,1)));
        System.out.println(grid.get(new Location(0,1)));
        System.out.println(grid.get(new Location(1,2)));
        System.out.println(grid.get(new Location(2,0)));
        System.out.println(grid.get(new Location(2,1)));
        System.out.println(grid.get(new Location(3,3)));
        System.out.println(grid.get(new Location(5,5)));
        System.out.println();
        
        System.out.println("Test getNeighbors method");
        System.out.println("------------------------");
        
        ArrayList<Object> list = grid.getNeighbors(new Location(1,1));
        
        for(Object s: list)
        {
        	System.out.println(s);
        }
        
        System.out.println();
    }
}