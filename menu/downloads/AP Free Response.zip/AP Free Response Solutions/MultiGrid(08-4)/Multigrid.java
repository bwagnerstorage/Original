import info.gridworld.grid.*;
import java.util.*;

public interface Multigrid
{
    Set<Object> get(Location loc);
    
    void put(Location loc, Object obj);
    
    ArrayList<Object> getNeighbors(Location loc);
    
    void remove(Location loc, Object obj);
    
    // other methods identical to the Grid interface
    boolean isValid(Location loc);
}