import java.util.*;
import info.gridworld.grid.*;

public class UnboundedMultigrid implements Multigrid
{
    private UnboundedGrid<Set<Object>> grid; // no other instance variables
    
    public UnboundedMultigrid()
    { 
        grid = new UnboundedGrid<Set<Object>>();
    }
    
    // part (a)
    /** @param loc a valid location in this grid
     *  @return a set of all objects at loc; an empty set, if no objects at loc
     *  Postcondition: the contents of this grid remain unchanged
     */
    public Set<Object> get(Location loc)
    { 
        Set<Object> set = grid.get(loc);
        
        return set;
    }
    
    // part (b)
    /** Puts an object at a given location in this grid.
     *       Precondition: (1) loc is valid in this grid. (2) obj is not null.
     *  @param loc the location at which to put the object
     *  @param obj the new object to be added
     */
    public void put(Location loc, Object obj)
    { 
       Set<Object> set = grid.get(loc);
       
       if(set == null)
       {
       	  HashSet s = new HashSet();
       	  s.add(obj);
       	  grid.put(loc, s);
       }
       else
       {
       	  set.add(obj);
       }
   
    }
    
    // part (c)
    /** Gets the neighboring occupants in all eight compass directions
     *  (north, northeast, east, southeast, south, southwest, west, and northwest).
     *  @param loc a location in this grid
     *         Precondition: loc is valid in this grid
     *  @return an array list of the objects in the occupied locations adjacent to loc in this grid
     */
    public ArrayList<Object> getNeighbors(Location loc)
    { 
       ArrayList<Object> list = new ArrayList<Object>();
       
       for(int i=0; i <= 315; i+=45)
       {
	       Set<Object> set = grid.get(loc.getAdjacentLocation(i));
	       if(set != null)
	       {
		       Iterator iter = set.iterator();
		       while(iter.hasNext())
		       {
		       	  list.add(iter.next());
		       }
	       }

       }
       
       return list;
   
 
    }
    public boolean isValid(Location loc)
    {
    	return true;
    }
    
    public void remove(Location loc, Object obj)
    {
    	/* implementation not shown */
    }
    // other methods not shown
}