import java.util.*;
import info.gridworld.actor.*;
import info.gridworld.grid.*;

public class GridChecker
{
	/** The grid to check; guaranteed never to be null */
	private BoundedGrid<Actor> gr;
	
	public GridChecker(Grid<Actor> g)
	{
		gr = (BoundedGrid)g;
	}
	
	
	// Part (a)
	/** @return an Actor in the grid gr with the most neighbors; 
	 *   null if no actors in the grid.
	*/
	public Actor actorWithMostNeighbors()
	{ 
	   int mostActors = 0;
	   Actor actor = null;
	   
	   for(int r = 0; r < gr.getNumRows(); r++)
	   {
	   	  for(int c = 0; c < gr.getNumCols(); c++)
	   	  {
	   	  	 Location loc = new Location(r, c);
	   	  	 if(gr.isValid(loc))
	   	  	 { 	
	   	  	 	Actor a = gr.get(loc);
	   	  	 	if(a != null)
	   	  	 	{
		   	  	 	ArrayList <Actor> list = gr.getNeighbors(loc);
		   	  	 	int n = list.size();
		   	  	 	if(n > mostActors)
		   	  	 	{
		   	  	 		mostActors = n;
		   	  	 		actor = a;
		   	  	 	}
	   	  	 	}

	   	  	 }
	   	  }
	   }
	   
	   return actor;
	
    }
	
	// Part (b)
	/** Returns a list of all occupied locations in the grid gr that are within 2 rows
	* and 2 columns of loc. The object references in the returned list may appear in any order.
	* @param loc a valid location in the grid gr
	* @return a list of all occupied locations in the grid gr that are within 2 rows
	* and 2 columns of loc.
	*/
	public List<Location> getOccupiedWithinTwo(Location loc)
	{
		ArrayList <Location> list = new ArrayList<Location>();
		for(int r = loc.getRow() - 2; r <= loc.getRow() + 2 ; r++)
		{
			for(int c =loc.getCol() - 2; c <= loc.getCol() + 2; c++)
			{
				Location location = new Location(r, c);
				if(gr.isValid(location))
				{
					if(gr.get(location) != null && !location.equals(loc))
					{
						list.add(location);
					}
				}
			}
		}
		
		return list;
		
    }
	
	
	// There may be instance variables, constructors, and methods that are not shown.
}