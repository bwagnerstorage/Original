import java.util.*;
import info.gridworld.actor.*;
import info.gridworld.grid.*;
import java.awt.Color;


public class GridCheckerRunner
{
    public static void main(String[] args)
    {
        ActorWorld world = new ActorWorld(); 
        
        
        
        
        world.add(new Location(0, 6),new Rock());
        world.add(new Location(2, 5),new Rock());
        world.add(new Location(3, 2),new Rock());
        world.add(new Location(3, 9),new Rock());
        world.add(new Location(4, 8),new Rock());
        world.add(new Location(5, 3),new Rock());
        world.add(new Location(6, 5),new Rock());
        world.add(new Location(8, 1),new Rock());
        world.add(new Location(9, 9),new Rock());
        
        world.add(new Location(1, 2),new Bug());
        world.add(new Location(1, 7),new Bug());
        world.add(new Location(4, 0),new Bug());
        world.add(new Location(4, 5),new Bug());
        world.add(new Location(4, 7),new Bug());
        world.add(new Location(5, 8),new Bug());
        world.add(new Location(6, 1),new Bug());
        world.add(new Location(8, 8),new Bug());
        world.add(new Location(9, 4),new Bug());
        
        Bug bug = new Bug();
        world.add(new Location(4, 3), bug);
        
        System.out.println("Test actorWithMostNeighbors");
        System.out.println("---------------------------");
        GridChecker checker = new GridChecker(bug.getGrid());
        Actor actor = checker.actorWithMostNeighbors();
        System.out.println(actor);
        System.out.println();
        
        System.out.println("Test getOccupiedWithinTwo");
        System.out.println("-------------------------");
        System.out.println("Occupied Locations around Location(4, 3) :");
        ArrayList <Location> list = (ArrayList)checker.getOccupiedWithinTwo(bug.getLocation());
        for(Location loc : list)
        {
        	System.out.println(loc);
        }
        System.out.println();       
        
        world.show();
        
    }
}