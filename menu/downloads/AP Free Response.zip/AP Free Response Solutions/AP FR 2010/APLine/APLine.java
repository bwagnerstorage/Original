public class APLine
{
	private int a;
	private int b;
	private int c;
	
	public APLine(int a, int b, int c)
	{
	   this.a = a;
	   this.b = b;
	   this.c = c;	
	}
	
	public double getSlope()
	{
	   return -a / (double)b;	
	}
	
	public boolean isOnLine(int x, int y)
	{
	   double value = a * x + b * y + c;
	   
	   if(value == 0)
	      return true;
	   else
	      return false;
	}
}