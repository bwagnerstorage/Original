public class Driver
{
	public static void main(String[] args)
	{
		int[] list1 = {100, 150, 105, 120, 90, 80, 50, 75, 75, 70, 80, 90, 100};
		
		Trail trail = new Trail(list1);
		
		System.out.println("Trail 1");
		System.out.println("-------");
		System.out.println("Level Trail (7-10): " + trail.isLevelTrailSegment(7,10));
		System.out.println("Level Trail (2-12): " + trail.isLevelTrailSegment(2,12));
		System.out.println("Difficult   : " + trail.isDifficult());
		System.out.println();
		
		int[] list2 = {85, 110, 105, 130, 90, 95, 95, 100, 120, 80, 90, 90, 100};
		
		trail = new Trail(list2);
		
		System.out.println("Trail 2");
		System.out.println("-------");
		System.out.println("Level Trail (4-7): " + trail.isLevelTrailSegment(4,7));
		System.out.println("Level Trail (0-4): " + trail.isLevelTrailSegment(0,4));
		System.out.println("Difficult   : " + trail.isDifficult());
		System.out.println();
	}
}