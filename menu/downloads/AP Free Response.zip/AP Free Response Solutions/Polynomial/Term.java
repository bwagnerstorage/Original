public class Term
{
	private int coefficient;
	private int exponent;
	
	public Term(int c, int x)
	{
		coefficient = c;
		exponent  = x;
	}
	
	public boolean isLikeTerm(Term otherTerm)
	{
		if(getExponent() == otherTerm.getExponent())
		   return true;
		else
		   return false;
	}
	
	public boolean isHigherOrder(Term otherTerm)
	{
		if(getExponent() > otherTerm.getExponent())
		   return true;
		else
		   return false;
	}
	
	public int getCoefficient()
	{
	    return coefficient;
	}
	
	public int getExponent()
	{
		return exponent;
	}
	
	public String toString()
	{
		if(exponent > 0)
		   return coefficient + "x^" + exponent;
		else
		   return "" + coefficient;
	}
}