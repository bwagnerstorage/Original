public class Driver
{
	public static void main(String[] args)
	{
		Polynomial p1 = new Polynomial();
		p1.addTerm(5,3);
		p1.addTerm(4,2);
		p1.addTerm(2,1);
		p1.addTerm(8,0);
		
		p1.print();
		
		Polynomial p2 = new Polynomial();
		p2.addTerm(8,3);
		p2.addTerm(3,2);
		p2.addTerm(6,1);
		p2.addTerm(2,0);
		
		p2.print();
		
		Polynomial p3 = p1.add(p2);
		
		p3.print();
		System.out.println();
		
		Polynomial p4 = new Polynomial();
		p4.addTerm(8,3);
		p4.addTerm(5,1);
		p4.addTerm(2,0);
		
		p4.print();
		
		Polynomial p5 = new Polynomial();
		p5.addTerm(3,2);
		p5.addTerm(6,1);
		p5.addTerm(7,0);
		
		p5.print();
		
		Polynomial p6 = p4.add(p5);
		
		p6.print();
		System.out.println();
	}
}