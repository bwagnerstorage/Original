import java.util.*;

public class Polynomial
{
	private LinkedList <Term> poly; 
	private int numTerms = 0;
	
	public Polynomial()
	{
	   poly = new LinkedList<Term>();
	   numTerms = 0;	
	}
	
	public int size()
	{
		return poly.size();
	}
	
	public void addTerm(int coefficient, int exp)
	{
		poly.add(new Term(coefficient, exp));
	}
	
	public Polynomial add(Polynomial otherPoly)
	{
	   Polynomial result = new Polynomial();
	   boolean found = false;
	  
	   int i=0;
	   int j=0;
	   while(i < size() && j < otherPoly.size())
	   {
	   	  Term term1 = poly.get(i);
	   	  Term term2 = otherPoly.poly.get(j);
	   	  
	   	  if(term1.isHigherOrder(term2))
	   	  {
	   	  	 for(int x=j; x < otherPoly.size(); x++)
	   	  	 {
	   	  	 	found = false;
	   	  	 	Term keyTerm = otherPoly.poly.get(x);
	   	  	 	if(term1.isLikeTerm(keyTerm))
	   	  	 	{
	   	  	 		result.addTerm(term1.getCoefficient() + keyTerm.getCoefficient(), term1.getExponent());
	   	  	 		found = true;
	   	  	 	}
	   	  	 }
	   	  	 if(found == false)
	   	  	 {
	   	  	 	result.addTerm(term1.getCoefficient(), term1.getExponent());
	   	  	 }
	   	  	 i++;
	   	  }
	   	  else
	   	  {
	   	  	 for(int x=i; x < otherPoly.size(); x++)
	   	  	 {
	   	  	 	found = false;
	   	  	 	Term keyTerm = poly.get(x);
	   	  	 	if(term2.isLikeTerm(keyTerm))
	   	  	 	{
	   	  	 		result.addTerm(term2.getCoefficient() + keyTerm.getCoefficient(), term2.getExponent());
	   	  	 		found = true;
	   	  	 	}
	   	  	 }
	   	  	 if(found == false)
	   	  	 {
	   	  	 	result.addTerm(term2.getCoefficient(), term2.getExponent());
	   	  	 }
	   	  	 j++;
	   	  }
	   }
	   
	   return result;
	  
	}
	
	public void print()
	{
		for(int i=0; i < poly.size(); i++)
		{
			if(i < poly.size() - 1)
			   System.out.print(poly.get(i) + " + ");
			else
			   System.out.print(poly.get(i));
		}
		System.out.println();
	}
}