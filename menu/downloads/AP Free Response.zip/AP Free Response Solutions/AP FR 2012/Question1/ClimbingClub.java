import java.util.*;

public class ClimbingClub
{
	/** The list of climbs completed by members of the club.
	* Guaranteed not to be null. Contains only non-null references.
	*/
	private List<ClimbInfo> climbList;

	/** Creates a new ClimbingClub object. */
	public ClimbingClub()
	{ climbList = new ArrayList<ClimbInfo>(); }

	/************/
	/* Parts A  */
	/************/

	/** Adds a new climb with name peakName and time climbTime to the list of climbs.
	* @param peakName the name of the mountain peak climbed
	* @param climbTime the number of minutes taken to complete the climb
	*/
	public void addClimb1(String peakName, int climbTime)
	{
       climbList.add(new ClimbInfo(peakName, climbTime));
	}

    /************/
	/* Parts B  */
	/************/

	/** Adds a new climb with name peakName and time climbTime to the list of climbs.
	* @param peakName the name of the mountain peak climbed
	* @param climbTime the number of minutes taken to complete the climb
	*/
	public void addClimb2(String peakName, int climbTime)
	{
       ClimbInfo climb = new ClimbInfo(peakName, climbTime);

       if(climbList.size() == 0)
       {
       	  climbList.add(climb);
       }
       else
       {
       	  int i = 0;
       	  while(i < climbList.size() && climb.getName().compareTo(climbList.get(i).getName()) > 0)
       	  {
       	  	i++;
       	  }
       	  climbList.add(i, climb);
       }

	}

	public String toString()
	{
		String str = "";

		for(ClimbInfo climb : climbList)
		{
			str += climb.toString() + "\n";
		}

		return str;
	}
}