import info.gridworld.actor.*;
import info.gridworld.grid.*;
import java.util.*;

public class RetroBug extends Bug
{
	private Location previousLoc;
	private int previousDirection;

    public void act()
    {

        previousLoc = getLocation();
        previousDirection = getDirection();

        if (canMove())
            move();
        else
            turn();


    }

    public void restore()
    {
    	if(previousLoc != null)
    	{
	    	Grid gr = getGrid();

	    	if(gr.get(previousLoc)== this)
	    	{
	    		setDirection(previousDirection);
	    	}

	    	else if(gr.get(previousLoc)== null ||
	    	        gr.get(previousLoc) instanceof Flower)
	    	{
		    	 moveTo(previousLoc);
		         setDirection(previousDirection);
	    	}
    	}

    }

}
