public class HorseBarn
{
	/** The spaces in the barn. Each array element holds a reference to the horse
	* that is currently occupying the space. A null value indicates an empty space.
	*/
	private Horse[] spaces;


	public HorseBarn(Horse[] sp)
	{
		spaces = sp;
	}

	/*******************/
	/* Part (A)        */
	/*******************/
	/** Returns the index of the space that contains the horse with the specified name.
	* Precondition: No two horses in the barn have the same name.
	* @param name the name of the horse to find
	* @return the index of the space containing the horse with the specified name;
	* -1 if no horse with the specified name is in the barn.
	*/
	public int findHorseSpace(String name)
	{
		int i = 0;

		for(Horse h : spaces)
		{
			if(h != null && h.getName().equals(name))
			{
				return i;
			}
			i++;
		}

		return -1;
    }


	/*******************/
	/* Part (B)        */
	/*******************/
	/** Consolidates the barn by moving horses so that the horses are in adjacent spaces,
	* starting at index 0, with no empty space between any two horses.
	* Postcondition: The order of the horses is the same as before the consolidation.
	*/
	public void consolidate()
	{
		for(int i=0; i<spaces.length; i++)
		{
			Horse h = spaces[i];
			if(h == null)
			{
				int j = i;
				while(j < spaces.length && spaces[j] == null)
				{
					j++;
				}
				if(j < spaces.length)
				{
					spaces[i] = spaces[j];
					spaces[j] = null;
				}

			}
		}
    }

	// There may be instance variables, constructors, and methods that are not shown.
	public String toString()
	{
		String str = "";

		for(Horse h: spaces)
		{
			if(h == null)
			{
				str += "\n";
			}
			else
			{
				str += h.getName() + " " + h.getWeight() + "\n";
			}

		}

		return str;
	}

}