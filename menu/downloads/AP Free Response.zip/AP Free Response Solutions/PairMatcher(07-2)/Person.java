public class Person
{ 
	private String firstName;
	
	public Person(String n)
	{
		firstName = n;
	}
	
	public boolean equals(Object other)
	{
	   return firstName.equals(((Person)other).firstName);
	}
	
	public int hashCode()
	{
		return firstName.hashCode();
	}
	
	public String toString()
	{
		return firstName;
	}
}