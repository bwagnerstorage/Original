import java.util.*;

public class PairMatcher
{
    private Map<Person, PriorityQueue<Pair>> personMap;
    
    /** Initializes and fills personMap so that each Person in personList is a key,
     *  and the value associated with each key k is a PriorityQueue of Pair objects
     *  pairing k with all other Persons in personList
     *  @param personList a nonempty list of Person objects
     */
    public PairMatcher(List<Person> personList)
    {  
       personMap = new HashMap<Person, PriorityQueue<Pair>>();
       
       for(int i=0; i < personList.size(); i++)
       {
       	  Person mainPerson = personList.get(i);
       	  PriorityQueue<Pair> queue = new PriorityQueue<Pair>();
       	  for(int j=0; j < personList.size(); j++)
       	  {
       	  	  if(j != i)
       	  	  {
       	  	  	 Person otherPerson = personList.get(j);
       	  	  
	             queue.add(new Pair(mainPerson, otherPerson)); 
       	  	  }
       	  	           
          }
          personMap.put(mainPerson, queue);
       }

    }
    
    
    /** @param p the Person to be matched
     *  @param num the number of Person objects to remove
     *         Precondition: if p is in personMap, then num is > 0 and less than or equal to 
     *                       the number of pairs in the priority queue associated with p
     *  @return an array of the num removed Person objects;
     *          null if p is not in personMap
     */
    public Person[] removeNumMatches(Person p, int num)
    {  
        PriorityQueue<Pair> queue = personMap.get(p);
         
        if(queue == null)
        {
           System.out.println("queue is null");
           return null;	
        }
          
        else
        {
           Person[] list = new Person[num];
	        
	       for(int i=0; i < num; i++)
	       {
	           list[i] = queue.remove().getPerson2();		
	       }
	       return list;
        }
    }
    
    
    
    // There may be fields, constructors, and methods not are not shown.
    public void print()
    {
    	Set set = personMap.keySet();
    	Iterator iterator = set.iterator();
    	
    	while(iterator.hasNext())
    	{
    		Person key = (Person)iterator.next();
    		System.out.printf("%-8s",key);
    		PriorityQueue<Pair> queue = personMap.get(key);
    		if(queue != null)
    		{
    			Iterator<Pair> queueIterator = queue.iterator();
    			while(queueIterator.hasNext())
    			{
    				Pair p = queueIterator.next();
    				String str = "[" + p.getPerson1() + "," + p.getPerson2() + "," + p.getCompatibilityIndex() + "]";
    				System.out.printf("%20s", str);
    			}
    			System.out.println();
    		}
    	}
    	
    }
}