public class Pair implements Comparable
{
	private Person Person1;
	private Person Person2;
	private int compatibilityIndex;
	
    /** @param p1 the first Person of the Pair
     *  @param p2 the second Person of the Pair
     */
    public Pair(Person p1, Person p2)
    { 
       Person1 = p1;
       Person2 = p2;
       calculateCompatibilityIndex();
    }
    
    /** @return first Person of this Pair
     */
    public Person getPerson1()
    {  return Person1; }
    
    /** @return second Person of this Pair
     */
    public Person getPerson2()
    {  return Person2; }
    
    public int getCompatibilityIndex()
    {	return compatibilityIndex;  }
    
    
    /** @param other the object to be compared to this Pair
     *         Precondition: other is a Pair object
     *  @ return the result of the comparison of the compatibility scores of this Pair and other
     */
    public int compareTo(Object other)
    {   
       if(compatibilityIndex < ((Pair)other).compatibilityIndex)
         return -1;
       else if(compatibilityIndex > ((Pair)other).compatibilityIndex)
         return 1;
       else
         return 0;   
    }
    
    
    // There may be fields, constructors, and methods that are not shown.
    
    private void calculateCompatibilityIndex()
    {
    	if(Person1.equals(new Person("Jamie")) && Person2.equals(new Person("Pat")) || 
    	   Person1.equals(new Person("Pat")) && Person2.equals(new Person("Jamie")))
               compatibilityIndex = 10;
        if(Person1.equals(new Person("Jamie")) && Person2.equals(new Person("Chris")) || 
    	   Person1.equals(new Person("Chris")) && Person2.equals(new Person("Jamie")))
               compatibilityIndex = 11;
        if(Person1.equals(new Person("Jamie")) && Person2.equals(new Person("Terry")) || 
    	   Person1.equals(new Person("Terry")) && Person2.equals(new Person("Jamie")))
               compatibilityIndex = 22;
        if(Person1.equals(new Person("Chris")) && Person2.equals(new Person("Terry")) || 
    	   Person1.equals(new Person("Terry")) && Person2.equals(new Person("Chris")))
               compatibilityIndex = 11;	
        if(Person1.equals(new Person("Chris")) && Person2.equals(new Person("Pat")) || 
    	   Person1.equals(new Person("Pat")) && Person2.equals(new Person("Chris")))
               compatibilityIndex = 21;
        if(Person1.equals(new Person("Pat")) && Person2.equals(new Person("Terry")) || 
    	   Person1.equals(new Person("Terry")) && Person2.equals(new Person("Pat")))
               compatibilityIndex = 32;		
    }
}