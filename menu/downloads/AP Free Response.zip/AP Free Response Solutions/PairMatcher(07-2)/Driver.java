import java.util.*;

public class Driver
{
	public static void main(String[] args)
	{
		ArrayList<Person> list = new ArrayList<Person>();
		list.add(new Person("Jamie"));
		list.add(new Person("Chris"));
		list.add(new Person("Pat"));
		list.add(new Person("Terry"));
		
		System.out.println("Test PairMatcher Constructor");
		System.out.println("----------------------------");
		
		PairMatcher matcher1 = new PairMatcher(list);
		matcher1.print();
		
		System.out.println(); System.out.println();
		
		System.out.println("Test removeNumMatches Method");
		System.out.println("----------------------------");
		Person[] list1 = matcher1.removeNumMatches(new Person("Terry"), 2);
		System.out.print("matcher1.removeNumMatches(new Person(\"Terry\"), 2) = ");
		for(Person p : list1)
		   System.out.print(p + " ");
		System.out.println();
		
		Person[] list2 = matcher1.removeNumMatches(new Person("Chris"), 1);
		System.out.print("matcher1.removeNumMatches(new Person(\"Chris\"), 1) = ");
		for(Person p : list2)
		   System.out.print(p + " ");
		System.out.println();
		
		Person[] list3 = matcher1.removeNumMatches(new Person("Pat"), 3);
		System.out.print("matcher1.removeNumMatches(new Person(\"Pat\"), 3) = ");
		for(Person p : list3)
		   System.out.print(p + " ");
		System.out.println(); 
		
		System.out.println(); System.out.println();
		
	}
}