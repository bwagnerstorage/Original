import java.util.*;

class Flight 
{ 
   private Seat[][] mySeats;
   
   // constructor
   public Flight(Seat[][] seats)
   {
   	  mySeats = seats;
   }
   
   // part (a)
   // returns the number of empty seats whose type is seatType;
   // if seatType is "any", returns the
   // total number of empty seats
   public int emptySeatCount(String seatType)
   {  
      int count = 0;
      if(seatType.equals("any"))
      {
      	 for(int r=0; r < mySeats.length; r++)
         {
      	    for(int c=0; c < mySeats[r].length; c++)
      	    {
      	    	Passenger p = mySeats[r][c].getPassenger();
      	    	if(p.getName().equals(""))
      	    	{
      	    		count++;
      	    	}
      	    }
      	 }  	
      }
      else
      {
	      for(int r=0; r < mySeats.length; r++)
	      {
	      	 for(int c=0; c < mySeats[r].length; c++)
	      	 {
	      	 	String type = mySeats[r][c].getType();
	      	 	Passenger p = mySeats[r][c].getPassenger();
	      	 	if(type.equals(seatType) && p.getName().equals(""))
	      	 	{
	      	 		count++;
	      	 	}
	       	 }
	      }
	   }
	   
	   return count;
   }

   // part (b)
   // returns column index of the first (lowest index)
   // seat in a block of seatsNeeded adjacent
   // empty seats in the specified row;
   // if no such block exists, returns -1
   public int findBlock(int row, int seatsNeeded)
   {  
      int count = 0;
      for(int c=0; c < mySeats[row].length; c++)
      {
      	 Passenger p = mySeats[row][c].getPassenger();
      	 if(p.getName().equals(""))
      	 {
      	 	count = 1;
      	 	if(count == seatsNeeded)
      	 	   return c;
	      	for(int i=c+1; i < mySeats[row].length; i++)
	      	{ 
	      	   p = mySeats[row][i].getPassenger();
	      	   if(!p.getName().equals(""))
      	       {
      	       	  return -1;
      	       }
      	       else
      	       {
      	       	  count++;
      	       	  if(count == seatsNeeded)
      	 	         return c;
      	       	  
      	       }
	      	   
	      	}
      	 }
      }
      return -1;
    
   }

   // part (c)
   // if possible, assigns the group.length passengers
   // from group to adjacent empty seats in a single row
   // and returns true;
   // otherwise, makes no changes and returns false
   public boolean assignGroup(Passenger[] group)
   {  
      int block = 0;
      for(int r=0; r < mySeats.length; r++)
      {
      	block = findBlock(r, group.length);
      	if(block != -1)
      	{
      		int cntr = 0;
      		for(int i=block; i < block + group.length; i++)
      		{
      			mySeats[r][i].setPassenger(group[cntr]);
      			cntr++;
      		}
      		return true;
      	}
      }
      
      return false;
   }


   public String toString()
   {
   	  String str = "";
   	  for(int r=0; r < mySeats.length; r++)
	  {
	      for(int c=0; c < mySeats[r].length; c++)
	      {
   	           str += mySeats[r][c].toString() + " ";
   	      }
   	      str += "\n";
   	  }
   	  return str;
   }

   // There may be fields, constructors, and methods that are not shown. 
}
