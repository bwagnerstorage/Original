class Passenger 
{ 
    private String name;
    
    // default constructor
    public Passenger()
    {
        name = "";
    }
    
    // second constructor
    public Passenger(String n)
    {
    	name = n;
    }
    
    // returns passenger's name
    public String getName()
    {
        return name;
    }
 
    // There may be fields, constructors, and methods that are not shown. 
}
	