public class Driver
{
	public static void main(String[] args)
	{
		Seat seats[][] = {{  new Seat(new Passenger("Kelly"), "window"),
		                     new Seat(new Passenger("Robin"), "middle"),
		                     new Seat(new Passenger(), "aisle"),
		                     new Seat(new Passenger("Sandy"), "aisle"),
		                     new Seat(new Passenger(), "middle"),
		                     new Seat(new Passenger("Fran"), "window")
		                   },
		                   {
		                   	 new Seat(new Passenger("Kris"), "window"),
		                   	 new Seat(new Passenger("Alex"), "middle"),
		                   	 new Seat(new Passenger(), "aisle"),
		                   	 new Seat(new Passenger(), "aisle"),
		                   	 new Seat(new Passenger("Pat"), "middle"),
		                   	 new Seat(new Passenger("Sam"), "window")
		                   }
		                  };
		                  
		Flight f179 = new Flight(seats);
		
		// test emptySeatCount method
		System.out.println("emptySeatCount(\"aisle\") = " + f179.emptySeatCount("aisle"));
        System.out.println("emptySeatCount(\"window\") = " + f179.emptySeatCount("window"));
        System.out.println("emptySeatCount(\"middle\") = " + f179.emptySeatCount("middle"));
        System.out.println("emptySeatCount(\"any\") = " + f179.emptySeatCount("any"));
        
        // test findBlock

        System.out.println();
		System.out.println("findBlock(0, 1) = " + f179.findBlock(0, 1));
        System.out.println("findBlock(0, 2) = " + f179.findBlock(0, 2));
        System.out.println("findBlock(1, 2) = " + f179.findBlock(1, 2));
        System.out.println();
        
        // test assignGroup
        
        Passenger[] adults = { new Passenger("Bill"), 
                               new Passenger("Mary"), 
                               new Passenger("John")
                             };
         
        System.out.println();                
        System.out.println("Before");
        System.out.println("------"); 
        System.out.println(f179);
        
        System.out.println("assignGroup(adults) = " + f179.assignGroup(adults));
        
        System.out.println();
        System.out.println("After");
        System.out.println("------"); 
        System.out.println(f179);
        
        Passenger[] kids = { new Passenger("Sam"), 
                             new Passenger("Fred"), 
                           };
                           
        System.out.println();
        System.out.println("Before");
        System.out.println("------"); 
        System.out.println(f179);
        
        System.out.println("assignGroup(kids) = " + f179.assignGroup(kids)); 
        
        System.out.println();
        System.out.println("After");
        System.out.println("------"); 
        System.out.println(f179);
        System.out.println();     

	}
}