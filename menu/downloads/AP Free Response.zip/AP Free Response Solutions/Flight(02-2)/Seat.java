class Seat 
{ 
    private Passenger passenger;
    private String seatType;        // "window", "aisle", "middle"
    
    // constructor
    public Seat(Passenger p, String type)
    {
    	passenger = p;
    	seatType = type;
    }
    
    // returns passenger in this seat 
    public Passenger getPassenger()
    {
        return passenger;
    } 
    
    // returns the type of this seat 
    public String getType()
    {
        return seatType;
    }
    
    // assigns p to this seat
    void setPassenger(Passenger p) 
    {
        passenger = p;
    }
    
    public String toString()
    {
    	return passenger.getName();
    }
    
    // There may be fields, constructors, and methods that are not shown.
} 