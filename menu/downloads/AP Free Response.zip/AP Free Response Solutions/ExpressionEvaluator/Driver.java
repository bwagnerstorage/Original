public class Driver
{
	public static void main(String[] args)
	{
		ExpressionEvaluator exp;
		
		exp = new ExpressionEvaluator("3+5");
		System.out.println("3+5 = " + exp.evaluate());
		
		exp = new ExpressionEvaluator("2+3*7");
		System.out.println("2+3*7 = " + exp.evaluate());
		
		exp = new ExpressionEvaluator("8/2+5");
		System.out.println("8/2+5 = " + exp.evaluate());
		
		exp = new ExpressionEvaluator("3^2+5");
		System.out.println("3^2+5 = " + exp.evaluate());
		
		exp = new ExpressionEvaluator("4+5^2*3");
		System.out.println("4+5^2*3 = " + exp.evaluate());
	}
}