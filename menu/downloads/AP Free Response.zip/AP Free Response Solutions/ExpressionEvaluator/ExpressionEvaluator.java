import java.util.*;

public class ExpressionEvaluator
{
	private String expression;
	
	public ExpressionEvaluator(String exp)
	{
		expression = exp;

	}
	
	private boolean isDigit(String digit)
	{  
		try
		{
			Integer.parseInt(digit);
			return true;
		}
		catch(NumberFormatException ex)
		{
			return false;
		}
	}
	
	private int getPrecedence(String operator)
	{
	   if(operator.equals("+") || operator.equals("-"))
	      return 1;
	   else if(operator.equals("*") || operator.equals("/"))
	      return 2;
	   else
	      return 3;
	}
	
	private int calculate(int operand1, int operand2, String operator)
	{
		if(operator.equals("+"))
		  return operand1 + operand2;
		else if(operator.equals("-"))
		  return operand1 - operand2;
		else if(operator.equals("*"))
		  return operand1 * operand2;
		else if(operator.equals("/"))
		  return operand1 / operand2;
		else
		  return (int)Math.pow(operand1, operand2);
		
	}
	
	public int evaluate()
	{
		Stack<Integer> numberStack = new Stack<Integer>();
		Stack<String> operatorStack = new Stack<String>();
		
		for(int i=0; i < expression.length(); i++)
		{
			String ch = expression.substring(i, i+1);
			if(isDigit(ch))
			{
				numberStack.push(Integer.parseInt(ch));
			}
			else
			{
			   while(!operatorStack.isEmpty() && getPrecedence(ch) < getPrecedence(operatorStack.peek()))
			   {
			   	  int operand1 = numberStack.pop();
			   	  int operand2 = numberStack.pop();
			   	  String operator = operatorStack.pop();
			   	  int result = calculate(operand2, operand1, operator);
			   	  numberStack.push(result); 	  
			   }
			   operatorStack.push(ch);
			}
		}		
		
		while(!operatorStack.isEmpty())
		{
		     int operand1 = numberStack.pop();
			 int operand2 = numberStack.pop();
			 String operator = operatorStack.pop();
			 int result = calculate(operand1, operand2, operator);
			 numberStack.push(result); 	 
		}
		return numberStack.pop();

	}
}