public class SoundDriver
{
	public static void main(String[] args)
	{
		int[] sample1 = {40,2532,17,-2300,-17,-4000,2000,1048, -420,33,15,-32,2030,3223};
		Sound sound1 = new Sound(sample1);
		
		System.out.println("Before : limitAmplitude");
		System.out.println("-----------------------\n");
		System.out.println(sound1);
		int numChanges = sound1.limitAmplitude(2000);  // limit = 2000
		System.out.println("\nAfter : limitAmplitude");
		System.out.println("-----------------------\n");
		System.out.println(sound1);
		System.out.println("NumChanges = " + numChanges);
		System.out.println();
		System.out.println();
		System.out.println();
		
		int[] sample2 = {0,0,0,0,-14,0,-35,-39,0,-7,16,32,37,29,0,0};
		Sound sound2 = new Sound(sample2);
			
		System.out.println("Before : trimSilenceFromBeginning");
		System.out.println("---------------------------------\n");
		System.out.println(sound2);
		sound2.trimSilenceFromBeginning();
		System.out.println("\nAfter : trimSilenceFromBeginning");
		System.out.println("----------------------------------\n");
		System.out.println(sound2);
		System.out.println();
		System.out.println();
		System.out.println();
		
	}
}