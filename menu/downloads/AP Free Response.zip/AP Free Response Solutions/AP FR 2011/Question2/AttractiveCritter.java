import info.gridworld.grid.*;
import info.gridworld.actor.*;

import java.util.*;

public class AttractiveCritter extends Critter
{
    public ArrayList<Actor> getActors()
    {
    	ArrayList<Actor> actors = new ArrayList<Actor>();
    	Grid gr = getGrid();
        for(int r = 0; r < gr.getNumRows(); r++)
        {
        	for(int c = 0; c < gr.getNumCols(); c++)
        	{
        		Location loc = new Location(r, c);
        		if(gr.get(loc) != null)
        		{
        			actors.add((Actor)gr.get(loc));	
        		}
        	}
        }
        
        return actors;
    }
    
    public void processActors(ArrayList<Actor> actors)
    {
    	Grid gr = getGrid();
		for(Actor a : actors)
		{
			Location loc = a.getLocation();
			int dir = loc.getDirectionToward(getLocation()); 
			Location newLoc = loc.getAdjacentLocation(dir);
			
			if(gr.isValid(newLoc) && gr.get(newLoc) == null)
			{
				a.moveTo(newLoc);
			}
		}
    }
}