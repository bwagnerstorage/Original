public class MyFuelRobot implements FuelRobot
{
	private int index;
	private boolean facingRight;
	
	public MyFuelRobot()
	{
	   index = 0;
	   facingRight = true;
	}
	
	public MyFuelRobot(int index)
	{
	   this.index = index;
	   facingRight = true;
	}
	
	/** @return the index of the current location of the robot */
	public int getCurrentIndex()
	{
		return index;
	}
	
	/** Determine whether the robot is currently facing to the right
	* @return true if the robot is facing to the right (toward tanks with larger indexes)
	* false if the robot is facing to the left (toward tanks with smaller indexes)
	*/
	public boolean isFacingRight()
	{
		return facingRight;
	}
	
	/** Changes the current direction of the robot */
	public void changeDirection()
	{
		facingRight = !facingRight;
	}
	
	/** Moves the robot in its current direction by the number of locations specified.
	* @param numLocs the number of locations to move. A value of 1 moves
	* the robot to the next location in the current direction.
	* Precondition: numLocs > 0
	*/
	public void moveForward(int numLocs)
	{
		if(isFacingRight())
		{
			index += numLocs;
		}
		else
		{
			index -= numLocs;
		}
	}
}