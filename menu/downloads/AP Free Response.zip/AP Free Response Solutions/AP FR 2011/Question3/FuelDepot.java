import java.util.*;

public class FuelDepot
{
	/** The robot used to move the filling mechanism */
	private FuelRobot filler;
	
	/** The list of fuel tanks */
	private List<FuelTank> tanks;
	
	public FuelDepot(List<FuelTank> t)
	{
		tanks = t;
		filler = new MyFuelRobot(2);
	}
	
	/** Determines and returns the index of the next tank to be filled.
	* @param threshold fuel tanks with a fuel level <= threshold may be filled
	* @return index of the location of the next tank to be filled
	* Postcondition: the state of the robot has not changed
	*/
	public int nextTankToFill(int threshold)
	{
		int index = filler.getCurrentIndex();
		int lowest = threshold + 1;
		
		int i = 0;
		for(FuelTank tank : tanks)
		{
			if(tank.getFuelLevel() <= threshold && tank.getFuelLevel() < lowest)
			{
				index = i;
				lowest = tank.getFuelLevel();
			}
			i++;
		}
		return index;

	}
	
	/** Moves the robot to location locIndex.
	* @param locIndex the index of the location of the tank to move to
	* Precondition: 0 <= locIndex < tanks.size()
	* Postcondition: the current location of the robot is locIndex
	*/
	public void moveToLocation(int locIndex)
	{ 
	    int currentIndex = filler.getCurrentIndex();
	    
	    if(locIndex > currentIndex)
	    {
	    	filler.moveForward(locIndex - currentIndex);
	    }
	    else
	    {
	    	filler.changeDirection();
	    	filler.moveForward(Math.abs(locIndex - currentIndex));
	    }
	}
	
	public String toString()
	{
		return "" + filler.getCurrentIndex();
	}

}