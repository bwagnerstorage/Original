import java.util.*;

public class FuelDepotDriver
{
	public static void main(String[] args)
	{
		List <FuelTank> tanks = new ArrayList<FuelTank>();
		tanks.add(new MyFuelTank(20));
		tanks.add(new MyFuelTank(30));
		tanks.add(new MyFuelTank(80));
		tanks.add(new MyFuelTank(55));
		tanks.add(new MyFuelTank(50));
		tanks.add(new MyFuelTank(75));
		tanks.add(new MyFuelTank(20));
		
		FuelDepot depot = new FuelDepot(tanks);
		
		System.out.println("nextTankToFill: threshold = 50,  result = 0 or 6");
		System.out.println("-----------------------------------------------");
		System.out.println(depot.nextTankToFill(50));
		
		System.out.println("nextTankToFill: threshold = 15,  result = 2");
		System.out.println("-----------------------------------------------");
		System.out.println(depot.nextTankToFill(15));
		
		System.out.println("\n\n\nBefore: moveToLocation");
		System.out.println("----------------------");
		System.out.println(depot);
		System.out.println("\nAfter: moveToLocation");
		System.out.println("---------------------");
		depot.moveToLocation(4);
		System.out.println(depot);
		
		System.out.println("\n\nBefore: moveToLocation");
		System.out.println("----------------------");
		System.out.println(depot);
		System.out.println("\nAfter: moveToLocation");
		System.out.println("---------------------");
		depot.moveToLocation(0);
		System.out.println(depot);
		System.out.println();
		System.out.println();
	
	}
}