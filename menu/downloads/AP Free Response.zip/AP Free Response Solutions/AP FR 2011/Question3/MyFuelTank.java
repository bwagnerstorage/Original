public class MyFuelTank implements FuelTank
{
	private int level;
	
	public MyFuelTank(int level)
	{
		this.level = level;
	}
	
	/** @return an integer value that ranges from 0 (empty) to 100 (full) */
	public int getFuelLevel()
	{
		return level;
	}
}