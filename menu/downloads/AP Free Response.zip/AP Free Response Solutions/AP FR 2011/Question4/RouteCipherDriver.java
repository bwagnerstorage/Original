public class RouteCipherDriver
{
	public static void main(String[] args)
	{
		RouteCipher demo1 = new RouteCipher(3, 5, "Meet at noon");

	    System.out.println("fillBlock");
		System.out.println("----------");
		System.out.println(demo1);

	    RouteCipher demo2= new RouteCipher(3, 5, "Meet at midnight");

	    System.out.println("fillBlock");
		System.out.println("----------");
		System.out.println(demo2);

		RouteCipher demo3= new RouteCipher(2, 3, "");

		System.out.println("encryptMessage");
		System.out.println("----------------------");
		String str = demo3.encryptMessage("Meet at midnight");
		System.out.println(str);
		System.out.println();
	}
}