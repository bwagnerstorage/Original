public class RouteCipher
{
	/** A two-dimensional array of single-character strings, instantiated in the constructor */
	private String[][] letterBlock;
	
	/** The number of rows of letterBlock, set by the constructor */
	private int numRows;
	
	/** The number of columns of letterBlock, set by the constructor */
	private int numCols;
	
	public RouteCipher(int r, int c, String s)
	{
	   numRows = r;
	   numCols = c;
	   letterBlock = new String[r][c];
	   fillBlock(s);
	}
	
	/************************/
	/* Part A */
	/************************/
	/** Places a string into letterBlock in row-major order.
	* @param str the string to be processed
	* Postcondition:
	* if str.length() < numRows * numCols, "A" is placed in each unfilled cell
	* if str.length() > numRows * numCols, trailing characters are ignored
	*/
	private void fillBlock(String str)
	{ 
	   int len = str.length();
	   
	   if(len < numRows * numCols)
	   {
	   	    int extra = (numRows * numCols) - len;
	   	    int r = 0;
	   	    int c = 0;
	   		for(int i = 0; i < numRows * numCols; i++)
	   		{
	   			 if(i < len)
	   			      letterBlock[r][c] = str.substring(i , i+1);
	   			 else
	   			      letterBlock[r][c] = "A";
	   			      
	   			 if(c > numCols-2)
	   			 {
	   			 	  c = 0;
	   			 	  r++;
	   			 }
	   			 else
	   			 	 c++;   			 
	   		}
	   	}
   		else
   		{
   			int r = 0;
	   	    int c = 0;
	   		for(int i = 0; i < len-1;  i++)
	   		{
	   			  letterBlock[r][c] = str.substring(i , i+1);

	   			 if(c > numCols-2)
	   			 {
	   			 	  c = 0;
	   			 	  r++;
	   			 }
	   			 else
	   			 {
	   			 	 c++;
	   			 }		 
	   		}
	   }
	}
	
	/** Extracts encrypted string from letterBlock in column-major order.
	* Precondition: letterBlock has been filled
	* @return the encrypted string from letterBlock
	*/
	private String encryptBlock()
	{ 
		String str = "";
		
		for(int c = 0; c < numCols; c++)
		{
			for(int r = 0; r < numRows; r++)
			{
				str += letterBlock[r][c] + " ";
			}
		}
		
		return str;
	}
	
	/************************/
	/* Part B */
	/************************/
	/** Encrypts a message.
	* @param message the string to be encrypted
	* @return the encrypted message;
	* if message is the empty string, returns the empty string
	*/
	public String encryptMessage(String message)
	{
		 String encrypt = "";
		 int len = message.length();
		 int sp = numRows * numCols;
		 
		 int i =0;
		 while(len - sp >= 0)
		 {
		 	  	 fillBlock(message.substring(i, i+sp+1));
		 	  	 len = len - sp;
		 	  	 i+= 6;
		 	  	 encrypt += encryptBlock();
	     }
	     
 	  	 fillBlock(message.substring(i));
         encrypt += encryptBlock();

		 return encrypt;
	}
	
	// toString
	public String toString()
	{
		String str = "";
		
		for(int r = 0; r < numRows; r++)
		{
			for(int c = 0; c < numCols; c++)
			{
				str += letterBlock[r][c] + " ";
			}
			str += "\n";
		}
		
		return str;
	}

}