public class Player
{
   private String name;   // name of this player
   
   public Player(String aName)
   {  name = aName; }
   
   public String getName()
   {  return name;  }
   
   /** This implementation chooses the first valid move.
    *  Override this method in subclasses to define players with other strategies.
    *  @param stat the current state of the game; its current player is this player
    *  @return a string representing the move choosen;
    *          "no move" is no valid moves fro the current player.
    */
   public String getNextMove(GameState state)
   {  /* implementation not shown  */  }
	
}