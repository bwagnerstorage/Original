public class Driver
{
	public static void main(String[] args)
	{
		BatteryCharger app = new BatteryCharger();
		
		System.out.println("--------------------");
		System.out.println("Test getChargingCost");
		System.out.println("--------------------");
		
		System.out.println(app.getChargingCost(12, 1));
		System.out.println(app.getChargingCost(0, 2));
		System.out.println(app.getChargingCost(22, 7));
		System.out.println(app.getChargingCost(22, 30));
		
		System.out.println();
		System.out.println("-----------------------");
		System.out.println("Test getChargeStartTime");
		System.out.println("-----------------------");
		
		System.out.println(app.getChargeStartTime(1));
		System.out.println(app.getChargeStartTime(2));
		System.out.println(app.getChargeStartTime(7));
		System.out.println(app.getChargeStartTime(30));
	}
}