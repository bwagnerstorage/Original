public class BatteryCharger
{
	
	int[] table = {50,60,160,60,80,100,100,120,150,150,150,200,40,240,220,220,200,200,180,180,140,100,80,60};
	
	/** rateTable has 24 entries representing the charging costs for hours 0 through 23. */
	private int[] rateTable;
	
	public BatteryCharger()
	{
		rateTable = table;
	}
	
	/** Determines the total cost to charge the battery starting at the beginning of startHour.
	* @param startHour the hour at which the charge period begins
	* Precondition: 0 <= startHour <= 23
	* @param chargeTime the number of hours the battery needs to be charged
	* Precondition: chargeTime > 0
	* @return the total cost to charge the battery
	*/
	public int getChargingCost(int startHour, int chargeTime)
	{  
	    int totalCost = 0;
	    int i = startHour;
	    int count = 0;
	    while(count < chargeTime)
	    {
	    	totalCost += rateTable[i];
	    	count++;
	    	if(i == 23)
	    	   i = 0;
	    	else 
	    	   i++;
	    }
	    
	    return totalCost;
	
	}
	
	/** Determines start time to charge the battery at the lowest cost for the given charge time.
	* @param chargeTime the number of hours the battery needs to be charged
	* Precondition: chargeTime > 0
	* @return an optimal start time, with 0 <= returned value <= 23
	*/
	public int getChargeStartTime(int chargeTime)
	{
		int lowestCost = getChargingCost(0, chargeTime);
		int optimalStartTime = 0;
		int cost = 0;
		int i = 0;
		while(i < 23)	
		{
			cost = getChargingCost(i, chargeTime);
			if(cost < lowestCost)
			{
				lowestCost = cost;
				optimalStartTime = i;
			}
			i++;
		}
		
		return optimalStartTime;
		 
	}
	
	// There may be instance variables, constructors, and methods that are not shown.
}