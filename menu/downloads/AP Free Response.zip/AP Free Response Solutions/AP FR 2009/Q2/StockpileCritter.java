import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

import java.awt.Color;
import java.util.ArrayList;


public class StockpileCritter extends Critter
{
	private ArrayList<Actor> pile;
	
    public StockpileCritter()
    {
        setColor(Color.RED);
        pile = new ArrayList<Actor>();
    }

    /**
     * Processes the elements of <code>actors</code>. New actors may be added
     * to empty locations. Implemented to "eat" (i.e. remove) selected actors
     * that are not rocks or critters. Override this method in subclasses to
     * process actors in a different way. <br />
     * Postcondition: (1) The state of all actors in the grid other than this
     * critter and the elements of <code>actors</code> is unchanged. (2) The
     * location of this critter is unchanged.
     * @param actors the actors to be processed
     */
    public void processActors(ArrayList<Actor> actors)
    {
        System.out.println("Energy Level = " + pile.size());
    	for(Actor a : actors)
    	{
    		pile.add(a);
    		a.removeSelfFromGrid();
    	}

        if (pile.isEmpty())
             removeSelfFromGrid();
        else   
            pile.remove(0);
    }   
}
