import java.util.*;

public class TileGame
{
	/** represents the game board; guaranteed never to be null */
	private ArrayList<NumberTile> board;

	public TileGame()
	{ 
	   board = new ArrayList<NumberTile>();
	   board.add(new NumberTile(4, 4, 3, 7));
	   board.add(new NumberTile(3, 6, 4, 3));
	   board.add(new NumberTile(4, 1, 2, 3));
	   board.add(new NumberTile(2, 3, 2, 5));
	   board.add(new NumberTile(2, 5, 9, 2));
	}
	
	/** Determines where to insert tile, in its current orientation, into game board
	* @param tile the tile to be placed on the game board
	* @return the position of tile where tile is to be inserted:
	* 0 if the board is empty;
	* -1 if tile does not fit in front, at end, or between any existing tiles;
	* otherwise, 0 . position returned . board.size()
	*/
	private int getIndexForFit(NumberTile tile)
	{ 
	   if(board.size() == 0)
	      return 0;
	   else
	   {
	   	   // test front
	   	   if(board.get(0).getLeft() == tile.getRight())
	          return 0;   	   
	   	   // test end
	   	   if(board.get(board.size()-1).getRight()  == tile.getLeft())
	   	      return board.size();
	   	   
	   	   // test middle
	   	   for(int i = 1; i < board.size() - 1; i++)
	   	   {
	   	   	  if(board.get(i).getRight() == tile.getLeft() && 
	   	   	     board.get(i+1).getLeft() == tile.getRight())
	   	   	     return i + 1;  	  
	   	   }
	   }
	   
	   return -1;
	
	}
	
	/** Places tile on the game board if it fits (checking all possible tile orientations if necessary).
	* If there are no tiles on the game board, the tile is placed at position 0.
	* The tile should be placed at most 1 time.
	* Precondition: board is not null
	* @param tile the tile to be placed on the game board
	* @return true if tile is placed successfully; false otherwise
	* Postcondition: the orientations of the other tiles on the board are not changed
	* Postcondition: the order of the other tiles on the board relative to each other is not changed
	*/
	public boolean insertTile(NumberTile tile)
	{
		int index = -1;
		
		for(int i = 0; i < 4; i++)
		{
			index = getIndexForFit(tile);
			if(index == -1)
			{
				tile.rotate();
			}
			else
			{
				board.add(index, tile);
				return true;
			}
		}
		
		return false;

	}
	
	public void printBoard()
	{
		for(NumberTile tile : board)
		{
			System.out.print(tile + " ");
		}
		System.out.println();
	}
	// There may be instance variables, constructors, and methods that are not shown.
}