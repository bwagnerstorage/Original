import java.util.*;

public class NumberTile
{
	private ArrayList<Integer> tile;
	
	public NumberTile(int a, int b, int c, int d)
	{
	   tile = new ArrayList<Integer>();
       tile.add(a);
       tile.add(b);
       tile.add(c);
       tile.add(d);
	}
	/** Rotates the tile 90 degrees clockwise
	*/
	public void rotate()
	{
		int n = tile.remove(3);
		tile.add(0, n);
	}
	
	/** @return value at left edge of tile
	*/
	public int getLeft()
	{ 
	   return tile.get(0);
	}
	
	/** @return value at right edge of tile
	*/
	public int getRight()
	{ 
	   return tile.get(2);
	}
	
	public String toString()
	{
		String str = "[";
		
		for(int i = 0; i < 4; i++)
		{
			str += tile.get(i) + " ";
		}
		
		str += "]";
		return str;
	}

}