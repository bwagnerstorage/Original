public class Driver
{
	public static void main(String[] args)
	{
		TileGame game = new TileGame();
		
		game.printBoard();
		
		System.out.println();
		System.out.println("\n--> Insert tile (Middle): [2,4,2,9]");
		game.insertTile(new NumberTile(2,4,2,9));
		
		game.printBoard();
		
		System.out.println("\n--> Insert tile (Beginning): [1,2,4,5]");
		game.insertTile(new NumberTile(1,2,4,5));
		
		game.printBoard();
		
		System.out.println("\n--> Insert tile (End): [9,1,2,7]");
		game.insertTile(new NumberTile(9,1,2,7));
		
		game.printBoard();
		
		System.out.println("\n--> Insert tile (Middle with Rotation): [8,3,4,3]");
		game.insertTile(new NumberTile(8,3,4,3));
		
		game.printBoard();
		
		System.out.println("\n--> Insert tile (End with Rotation): [3,2,5,4]");
		game.insertTile(new NumberTile(3,2,5,4));
		
		game.printBoard();
		
		System.out.println("\n--> Insert tile (Not Valid): [8,8,8,8]");
		game.insertTile(new NumberTile(8,8,8,8));
		
		game.printBoard();
		
	}
}