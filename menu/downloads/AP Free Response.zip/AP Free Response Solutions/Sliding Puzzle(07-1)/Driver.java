public class Driver
{
	public static void main(String[] args)
	{
		SlidingPuzzle puzzle1 = new SlidingPuzzle(4);
		
		System.out.println("Test - initialize method");
		System.out.println("------------------------");
		
		puzzle1.printPuzzle();
		
		int[] list = {1,2,3,4,5,6,0,7,8,9,10,11,12,13,14,15};
		SlidingPuzzle puzzle2 = new SlidingPuzzle(4, list);
		
		System.out.println();
		System.out.println("Test - isDone method");
		System.out.println("--------------------");
        
        puzzle1.printPuzzle();
        System.out.println("puzzle1.isDone() = "+ puzzle1.isDone());
        System.out.println();
        
        puzzle2.printPuzzle();
		System.out.println("puzzle2.isDone() = "+ puzzle2.isDone());
		System.out.println();
		
		System.out.println();
	    System.out.println();
	
	}
}