import java.util.*;

public class SlidingPuzzle
{
    private int side;          // the side length of the puzzle grid
    private int [][] values;   // the tile values with the hole represented by 0
    
    /** @param sideLength the side length of the square grid
     *         Precondition: sideLength>0
     */
    public SlidingPuzzle(int sideLength)
    {
        side = sideLength;
        values = new int[side][side];
        initialize();
    }
    
    public SlidingPuzzle(int sideLength, int[] template)
    {
        side = sideLength;
        values = new int[side][side];
        
       int counter = 0;
       for(int r=0; r < side; r++)
       {
       	  for(int c=0; c < side; c++)
       	  {
       	  	values[r][c] = template[counter];
       	  	counter++;
       	  }
       }
    }
    
    // part (a)
    /** Precondition: the puzzle grid contains the distinct values 0 through side^2 -1
     *  @ return true if the tiles in the puzzle are all arranged in increasing order
     *                (the hole value 0 may be in any position);
     *           false otherwise
     */
    public boolean isDone()
    {  
       for(int r=0; r < side; r++)
       {
       	  for(int c=0; c < side - 1; c++)
       	  {
       	  	  if(values[r][c] != 0 && values[r][c+1] != 0)
       	  	  {
       	  	  	if(values[r][c] > values[r][c+1])
	       	  	{
	       	  	  	return false;
	       	  	} 
	       	  }
       	  }
       }
       return true;
    }
    
    
    // part (b)
    /** Initializes the puzzle by placing numbers 0 through side^2 - 1 into random locations
     */
    public void initialize()
    {  
        ArrayList<Integer> temp = new ArrayList<Integer>();
        for(int j=0; j < side * side; j++)
           temp.add(new Integer(j));

        // Write you solution below.
       for(int r=0; r < side; r++)
       {
       	  for(int c=0; c < side; c++)
       	  {
              int n = (int)(Math.random() * temp.size());
              values[r][c] = temp.get(n);
              temp.remove(n);
          }
       }
        
     }
    
    
    // There may be fields, constructors, and methods that are not shown.
    
    public void printPuzzle()
    {
       for(int r=0; r < side; r++)
       {
       	  for(int c=0; c < side; c++)
       	  {
       	  	 System.out.printf("%4d",values[r][c]);
       	  }
       	  System.out.println();
       }
    }

}