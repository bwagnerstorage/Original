public interface Filter
{
    /** @param text  a string to consider for acceptance
     *  @return true if this Filter accepts text; false otherwise
     */
    boolean accept(String text);
}