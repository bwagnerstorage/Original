public class Driver
{
	public static void main(String[] args)
	{
		Filter veggieFilter = new SimpleFilter("vegetable");
        Filter noVeggie = new NotFilter(veggieFilter);
        
        System.out.println("veggieFilter.accept(\"vegetable soup\") = " + veggieFilter.accept("vegetable soup"));
        System.out.println("veggieFilter.accept(\"fruit salad\")    = " + veggieFilter.accept("fruit salad"));
        System.out.println("noVeggie.accept(\"vegetable soup\")     = " + noVeggie.accept("vegetable soup"));
        System.out.println("noVeggie.accept(\"fruit salad\")        = " + noVeggie.accept("fruit salad"));
        System.out.println();
        
        veggieFilter = new SimpleFilter("vegetable");
		Filter fruitFilter = new SimpleFilter("fruit");
		Filter noPoison = new NotFilter(new SimpleFilter("poison"));
		OrFilter healthyFood = new OrFilter(veggieFilter, fruitFilter);
		// healthyFood will accept strings containing "vegetable" or "fruit"
		healthyFood.add(noPoison);
		// healthyFood will accept strings containing "vegetable" or "fruit"
		// or strings without "poison"
		
		System.out.println("healthyFood.accept(\"vegetable soup is not poison\") = " + healthyFood.accept("vegetable soup is not poison"));
        System.out.println("healthyFood.accept(\"fruit salad\")                  = " + healthyFood.accept("fruit salad"));
        System.out.println("healthyFood.accept(\"a poisoned apple\")             = "+ healthyFood.accept("a poisoned apple"));
        System.out.println("healthyFood.accept(\"salad\")                        = " + healthyFood.accept("salad"));
        System.out.println();
        
		Filter appleFilter = new SimpleFilter("apple");
		Filter peachFilter = new SimpleFilter("peach");
		Filter fruits = new AndFilter(appleFilter, peachFilter);
		boolean b1 = fruits.accept("peach cobbler"); // b1 is set to false
		boolean b2 = fruits.accept("peaches and apples"); // b2 is set to true
				
		String[] primary = {"red", "blue", "yellow"};
		Filter primaryColors = buildFilter(primary, "green");  // buildFilter
		
		System.out.println("primaryColors.accept(\"Roses are red, violets are blue\") = " + primaryColors.accept("Roses are red, violets are blue"));
		System.out.println("primaryColors.accept(\"blue grass is really green\")      = " + primaryColors.accept("blue grass is really green"));
		System.out.println("primaryColors.accept(\"The rainbow has many colors\")     = " + primaryColors.accept("The rainbow has many colors"));
		System.out.println();
	}
	
	/////////////////
	// Part (b)
	////////////////
	/** @param desirable  contains strings that are allowed
	 *         Precondition: desirable.length > 1
	 *  @param notAllowed the string that is not allowed
	 *  @return a Filter that accepts strings that contain at least one string
	 *          in desirable and do not contain notAllowed.
	 */
	public static Filter buildFilter(String[] desirable, String notAllowed)
	{
		OrFilter orFilter;
		NotFilter notFilter;
		
		notFilter  = new NotFilter(new SimpleFilter(notAllowed));
		orFilter = new OrFilter(new SimpleFilter(desirable[0]), new SimpleFilter(desirable[1]));
		for(int i=2; i < desirable.length; i++)
		{
			orFilter.add(new SimpleFilter(desirable[i]));
		}
		
		return new AndFilter(orFilter, notFilter);
	
	}
}