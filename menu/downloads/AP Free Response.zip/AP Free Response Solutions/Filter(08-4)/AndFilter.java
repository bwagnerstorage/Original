import java.util.*;

public class AndFilter implements Filter
{
	private ArrayList<Filter> filters;
	
	public AndFilter(Filter f1, Filter f2)
	{
		filters = new ArrayList <Filter>();
		filters.add(f1);
		filters.add(f2);
	}
	
	public void add(Filter f)
	{
		filters.add(f);
	}
	
	public boolean accept(String text)
	{
		for(Filter f : filters)
		{
			if(!f.accept(text))
			{
				return false;
			}
		}
		return true;
	}
}