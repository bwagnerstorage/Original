public class NotFilter implements Filter
{
	private Filter filter;
	
	public NotFilter(Filter f)
	{
		filter = f;
	}
	public boolean accept(String text)
	{
		return !filter.accept(text);
	}
}