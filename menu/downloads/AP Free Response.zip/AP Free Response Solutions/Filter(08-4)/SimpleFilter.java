public class SimpleFilter implements Filter
{
	private String filter;
	
	public SimpleFilter(String f)
	{
		filter = f;
	}
	public boolean accept(String text)
	{
		return text.contains(filter);
	}
}