public class SubstringChecker implements Checker
{
	private String str;
	
	public SubstringChecker(String s)
	{
		str = s;
	}
	
	public boolean accept(String s)
	{
		return s.contains(str);
	}
}