public class AndChecker implements Checker
{
	private Checker check1;
	private Checker check2;
	
	public AndChecker(Checker c1, Checker c2)
	{
		check1 = c1;
		check2 = c2;
	}
	
	public boolean accept(String s)
	{
		return check1.accept(s) && check2.accept(s);
	}
}