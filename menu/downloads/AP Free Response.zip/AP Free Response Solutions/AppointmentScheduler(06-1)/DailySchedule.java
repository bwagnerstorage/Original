import java.util.*;

public class DailySchedule
{
      // contains Appointment objects, no two Appointments overlap
      private ArrayList<Appointment> apptList;

      public DailySchedule()
      { 
	      apptList = new ArrayList<Appointment>();
      }
	  
	  // part (b)
      // removes all appointments that overlap the given Appointment
      // postcondition: all appointments that have a time conflict with
      //appt have been removed from this DailySchedule
      public void clearConflicts(Appointment appt)
      { 
      
      	/*
	      int i = 0;
	
	      while (i < apptList.size())
	         if (appt.conflictsWith(apptList.get(i)))
	      apptList.remove(i);
	         else
	      i++;
	    
	    
	      int i = 0;
	
	      while (i < apptList.size())
	         if ((apptList.get(i)).conflictsWith(appt))
	      apptList.remove(i);
	         else
	      i++;
	    */
	     
	    
	    /*for(int ctr = 0; ctr < apptList.size(); ctr++)
        {
            if(appt.conflictsWith(apptList.get(ctr)))    //switching the order of this call What's the difference?
            {
                apptList.remove(ctr);
                ctr--;
            }
        }
        
        */
        for(int ctr = 0; ctr < apptList.size(); ctr++)
        {
            if(apptList.get(ctr).conflictsWith(appt))
            {
                apptList.remove(ctr);
                ctr--;
            }
        }
        

      }
	  
	  
	  // part (c)
      // if emergency is true, clears any overlapping appointments and adds
      // appt to this DailySchedule; otherwise, if there are no conflicting
      // appointments, adds appt to this DailySchedule;
      // returns true if the appointment was added;
      // otherwise, returns false
      public boolean addAppt(Appointment appt, boolean emergency)
      { 
        if (emergency)
	    {
	      clearConflicts(appt);
	      apptList.add(appt);
	      return true;
	    }
	
	    for (int i = 0; i < apptList.size(); i++)
	      if (((Appointment)apptList.get(i)).conflictsWith(appt))
	        return false;
	
	    apptList.add(appt);
	    
	    return true;

      }
      
      public String toString()
      {
      	 String str = "";
      	 
      	 for(Appointment appt : apptList)
      	 {
      	 	str += appt.getDescription() + "     " + appt.getTime().toString() + "\n";
      	 }
      	 
      	 return str;
      }

}