public class TreeNode<E extends Comparable>
{
    // Instance Variables
    private E value;
    private TreeNode left;
    private TreeNode right;
    
    // Constructors
    public TreeNode(E initValue)
    { 
        value = initValue; 
        left = null; 
        right = null; 
    }
    
    public TreeNode(E initValue, TreeNode initLeft, TreeNode initRight)
    { 
        value = initValue;
        left = initLeft;
        right = initRight;
    }
    
    // Accessor Methods
    public E getValue()
    {
        return value;
    }
    public TreeNode getLeft() 
    { 
        return left; 
    }
    public TreeNode getRight()
    { 
         return right; 
    }
    
    // Mutator Methods
    public void setValue(E theNewValue)
    { 
         value = theNewValue; 
    }
    public void setLeft(TreeNode theNewLeft)
    { 
         left = theNewLeft;
    }
    public void setRight(TreeNode theNewRight)
    { 
         right = theNewRight;
    }
}