public abstract class BinaryTree<E extends Comparable>
{
   private TreeNode<E> root;
   
   public BinaryTree()
   {
      root = null;
   }

   public TreeNode<E> getRoot()
   {
      return root;
   }

   public void setRoot(TreeNode<E> theNewNode)
   {
      root = theNewNode;
   }
 
   public boolean isEmpty()
   {
      return root == null;
   }
   
   public abstract void add(E item);
   public abstract TreeNode<E> contains(E key);
   public abstract TreeNode remove(E key);


}