import java.util.*;

public interface GenericSortedSet<E extends Comparable>
{
    // returns the number of items in set
    int size();
    
    // returns the first (lowest) element currently in this sorted set.
    E first();
    
    // returns the last (highest) element currently in this sorted set
    E last();
    
    // returns a portion of this sorted set whose elements 
    // range from fromElement, inclusive, to toElement, inclusive.
    GenericSortedSet subSet(E fromElement, E toElement);
    
    // returns an iterator on the set
    Iterator iterator();
}