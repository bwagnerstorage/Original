import java.util.*;

public class MapDemo
{
    public static void main(String[] args)
    {
       // constructor
       TreeMap<Integer, String> map = new TreeMap<Integer, String>();
       
       // put method
       map.put(1, "dog");
       map.put(2, "cat");
       map.put(3, "bird");
       
       // get method
       String ans1 = map.get(1);
       String ans2 = map.get(2);
       String ans3 = map.get(3);
       
       System.out.println(ans1);
       System.out.println(ans2);
       System.out.println(ans3);
       
       // remove method
       String ans4 = map.remove(2);
       System.out.println(ans4 + " has been removed");
       
       // size method
       System.out.println("Size = " + map.size());
       
       // containsKey method
       if(map.containsKey(1))
       {
          System.out.println("key is in map");
       }
       
       // Iterate over map using set of keys
       Iterator iterator = map.keySet().iterator();
       while(iterator.hasNext())
       {
          System.out.println(iterator.next());
       }
       
    }
}