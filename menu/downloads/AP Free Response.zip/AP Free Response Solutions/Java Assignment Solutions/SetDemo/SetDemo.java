import java.util.*;

public class SetDemo
{
	public static void main(String[] args)
	{
	   HashSet<String> set = new HashSet<String>();
	   set.add("dog");
	   set.add("cat");
	   set.add("bird");
	   
	   System.out.println("Size = " + set.size());
	   
	   if(set.contains("cat"))
	   {
	   	  System.out.println("Set contains: Cat");
	   }
	   
	   /*if(set.remove("bird"))
	   {
	   	  System.out.println("bird was removed");
	   }
	   else
	   {
	   	  System.out.println("bird was not in set");
	   }*/
	   
	   Iterator it = set.iterator();
	   while(it.hasNext())
	   {
	   	 System.out.println(it.next());
	   }
	   
	   for(String str : set)
	   {
	   	 System.out.println(str);
	   }	
	}
}