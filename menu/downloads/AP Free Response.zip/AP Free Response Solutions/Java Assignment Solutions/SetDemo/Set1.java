import java.util.*; // needed for Set and Map

public class MathSet
{
    String[] list1 = {"red","blue","green","yellow","orange","white","black"};
    String[] list2 = {"green", "orange", "white", "purple", "pink", "brown"};
        
    Set <String> A = new HashSet <String>();
    Set <String> B = new HashSet <String>();
    
    public Set1()
    {
        // Add elements to set A
        for(int i=0; i < list1.length; i++)
           A.add(list1[i]);
        
        // Add elements to set B
        for(int i=0; i < list2.length; i++)
           B.add(list2[i]);
           
        // Test intersection method
        Set <String> intersectSet = intersection(A,B);
        System.out.println("Intersection Test");
        System.out.println("----------------");
        print(intersectSet);
        System.out.println();
        
        // Test union method
        Set <String> unionSet = union(A,B);
        System.out.println("Union Test");
        System.out.println("----------------");
        print(unionSet);
        System.out.println();
        
        // Test difference method
        Set <String> differenceSet = difference(A,B);
        System.out.println("Difference Test");
        System.out.println("----------------");
        print(differenceSet);
        System.out.println();
        
        // Test subset method
        boolean isSubset = subset(A,B);
        System.out.println("Subset Test");
        System.out.println("----------------");
        if(isSubset == true)
          System.out.println("B is a subset of A");
        else
          System.out.println("B is not a subset of A");
        System.out.println();
        
        Set <String> C = new HashSet <String>();
        isSubset = subset(A,C);
        System.out.println("Subset Test");
        System.out.println("----------------");
        if(isSubset == true)
          System.out.println("C is a subset of A");
        else
          System.out.println("C is not a subset of A");
        System.out.println();
        
        // Test intersection method
        String[] array = toArray(A);
        System.out.println("toArray Test");
        System.out.println("----------------");
        for(int i=0; i < array.length; i++)
        {
            System.out.print(array[i] + " ");
        }
        System.out.println();
        System.out.println();
    }
    
    // prints the contents of a set
    public void print(Set <String> s)
    {
        Iterator iter = s.iterator();
        
        while(iter.hasNext())
        {
            System.out.print(iter.next() + " ");
        }
        System.out.println();
    }
    
    //Precondition: given two Sets: set A and set B
    //Postcondition: returns a set of items in A that are also items in B.
    public Set<String> intersection(Set<String> a, Set<String> b)
    {
        Set<String> result = new HashSet<String>();    // the return set
        Iterator<String> iter = a.iterator();  // get iterator on set a
        
        while(iter.hasNext())
        {
            String obj = iter.next();
            if(b.contains(obj))       // if set b contains object from set a
               result.add(obj);
        }
        
        return result;
    }
    
    //Precondition: given two Sets: set A and set B
    //Postcondition: returns a set that contains all of the items in A and all of the items in B.
    public Set<String> union(Set<String> a, Set<String> b)
    {

    }
    
    //Precondition: given two Sets: set A and set B
    //Postcondition: returns the set of items in A that are not also items in B.
    public Set<String> difference(Set a, Set b)
    {

    }
    
    //Precondition: given two Sets: set A and set B
    //Postcondition: returns true if b is a subset of a, othewise it returns false.
    public boolean subset(Set<String> a, Set<String> b)
    {

    }
    
    //Precondition: given Set s.
    //Postcondition: returns a array that contains all of the elements for Set s.
    public String[] toArray(Set <String>s)
    {
 
    }
    
    
    
    public static void main(String[] args)
    {
        Set1 app = new Set1();     
    }
}
