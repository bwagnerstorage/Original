import java.util.*;

public class BinarySearchTree
{
   private TreeNode root;
   
   public BinarySearchTree()
   {
      root = null;
   }
   
   public void add(Comparable item)
   {
   	  root = add(root, item);
   }
   
   private TreeNode add(TreeNode root, Comparable item)
   {
   	  if(root == null)
   	  {
   	  	 return new TreeNode(item, null, null);
   	  }
   	  if(item.compareTo(root.getValue()) < 0)
   	     root.setLeft(add(root.getLeft(), item));
   	  else 
   	     root.setRight(add(root.getRight(), item));
   	     
   	  return root;
   }
   
   public int numNodes()
   {
   	  return numNodes(root);
   }
   
   public int numNodes(TreeNode root)
   {
   	  if(root == null)
   	  {
   	  	 return 0;
   	  }
   	  else
   	  {
   	  	 return 1 + numNodes(root.getLeft()) + numNodes(root.getRight());
   	  }
   }
   
   public int numLeaves()
   {
   	  return numLeaves(root);
   }
   
   public int numLeaves(TreeNode root)
   {
   	  if(root == null)
   	  {
   	  	 return 0;
   	  }
   	  else if(root.getLeft() == null && root.getRight() == null)
   	  {
   	  	return 1 + numLeaves(root.getLeft()) + numLeaves(root.getRight());
   	  }
   	  else
   	  {
   	  	 return numLeaves(root.getLeft()) + numLeaves(root.getRight());
   	  }
   }
   
   public int numParents()
   {
   	  return numParents(root);
   }
   
   public int numParents(TreeNode root)
   {
   	  if(root == null)
   	  {
   	  	 return 0;
   	  }
   	  else if(root.getLeft() != null || root.getRight() != null)
   	  {
   	  	return 1 + numParents(root.getLeft()) + numParents(root.getRight());
   	  }
   	  else
   	  {
   	  	 return numParents(root.getLeft()) + numParents(root.getRight());
   	  }
   }
   
   // prints tree vertically so that tree structure
   // can be easily identified - uses reverse inorder
   // traversal: right-root-left
   public String toString()
   {
      return toString(root, 0);
   }
   
   // return string representation of tree's structure
   private String toString(TreeNode root, int level)
   {
      String str = "";
      if(root != null)
      {
        str += toString(root.getRight(), level + 1);
        for(int i = 1; i <= level; i++)
        {
            str = str + "  ";
        }
        str += root.getValue().toString() + "\n";
        str += toString(root.getLeft(), level + 1);
      }
      
      return str;
   }  
   
   public void inorderTraversal()
   {
   	  inorderTraversal(root);
   }
   
   private void inorderTraversal(TreeNode root)
   {
   	  Stack<TreeNode> stack = new Stack<TreeNode>();
   	  TreeNode temp = null;
   	  
   	  temp = root;
   	  
   	  do
   	  {
   	  	while(temp != null)
   	  	{
   	  		stack.push(temp);
   	  		temp = temp.getLeft();
   	  	}
   	  	
   	  	if(!stack.isEmpty())
   	  	{
   	  		temp = stack.pop();
   	  	}
   	  	
   	  	System.out.print(temp.getValue() + " ");
   	  	temp = temp.getRight();
   	  }
   	  while(!stack.isEmpty() || temp != null);
   	  System.out.println();
   }
}