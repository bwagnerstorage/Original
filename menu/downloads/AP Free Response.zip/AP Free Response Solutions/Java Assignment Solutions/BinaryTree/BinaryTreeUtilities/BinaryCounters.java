public class BinaryCounters
{
	public static void main(String[] args)
	{
		BinarySearchTree tree = new BinarySearchTree();
		
		tree.add("D");
        tree.add("B");
        tree.add("A");
        tree.add("C");
        tree.add("F");
        tree.add("E");
        tree.add("G");
        
        System.out.println("Tree Structure");
        System.out.println("==============");
        System.out.println();
        System.out.println(tree);
        
        System.out.println();
        System.out.println("Number of nodes = " + tree.numNodes());
        System.out.println("Number of leaves = " + tree.numLeaves());
        System.out.println("Number of parents = " + tree.numParents());
        System.out.println();
        
        tree.inorderTraversal();

        System.out.println();
	}
}