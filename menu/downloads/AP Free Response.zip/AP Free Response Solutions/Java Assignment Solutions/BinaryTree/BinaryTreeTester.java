import java.util.*;

public class BinaryTreeTester
{
    public static void main(String[] args)
    {
        BinarySearchTree tree = new BinarySearchTree();
        
        tree.add("D");
        tree.add("B");
        tree.add("A");
        tree.add("B");
        tree.add("C");
        tree.add("F");
        tree.add("E");
        tree.add("G");
        
        System.out.println("Tree Structure");
        System.out.println("==============");
        System.out.println();
        System.out.println(tree);
        
        System.out.println("Test contains method");
        System.out.println("====================");
        TreeNode node = tree.contains("A");
        if(node != null)
           System.out.println("Tree contains A");
        else
           System.out.println("Tree does not contain A");
           
        node = tree.contains("C");
        if(node != null)
           System.out.println("Tree contains C");
        else
           System.out.println("Tree does not contain C");
           
        node = tree.contains("Z");
        if(node != null)
           System.out.println("Tree contains Z");
        else
           System.out.println("Tree does not contain Z");
        System.out.println();
        
        System.out.println(tree); 
        
        System.out.println("Tree Traversals");
        System.out.println("===============");
        
        System.out.println("PreOrder Traversal");
        ArrayList<TreeNode> preOrderList = (ArrayList)tree.preOrderTraversal();
        for(TreeNode n : preOrderList)
          System.out.print(n.getValue() + " ");
        System.out.println(); System.out.println();
        
        System.out.println("InOrder Traversal");
        ArrayList<TreeNode> inOrderList = (ArrayList)tree.inOrderTraversal();
        for(TreeNode n : inOrderList)
          System.out.print(n.getValue() + " ");
        System.out.println(); System.out.println();
        
        System.out.println("PostOrder Traversal");
        ArrayList<TreeNode> postOrderList = (ArrayList)tree.postOrderTraversal();
        for(TreeNode n : postOrderList)
          System.out.print(n.getValue() + " ");
        System.out.println();System.out.println();
        
        System.out.println("LevelOrder Traversal");
        ArrayList<TreeNode> levelOrderList = (ArrayList)tree.levelOrderTraversal();
        for(TreeNode n : levelOrderList)
          System.out.print(n.getValue() + " ");
        System.out.println(); System.out.println();
                 
        System.out.println();
        System.out.println("Test remove method");
        System.out.println("==================");
        System.out.println();
         
        node = tree.remove("D");
        if(node != null)
           System.out.println("D has been removed from Tree");
        else
           System.out.println("Attempt to remove D from Tree has failed");
        
        System.out.println();
        System.out.println(tree);
        
        node = tree.remove("F");
        if(node != null)
           System.out.println("F has been removed from Tree");
        else
           System.out.println("Attempt to remove F from Tree has failed");

        System.out.println();
        System.out.println(tree);

        node = tree.remove("A");
        if(node != null)
           System.out.println("A has been removed from Tree");
        else
           System.out.println("Attempt to remove A from Tree has failed");

        System.out.println();
        System.out.println(tree);       
    }
}