import java.util.*;

public class BinarySearchTree extends BinaryTree
{
   public BinarySearchTree()
   {
      super();
   }
   
   /***********************************/
   /*           add Method            */
   /***********************************/ 
   public void add(Comparable item)
   {
      TreeNode newNode = new TreeNode(item);
      
      if(getRoot() == null)
      {
         setRoot(newNode);
      }
      else
      {
        TreeNode runner = getRoot();   // Start at the root.
        while (true) {
          if ( item.compareTo(runner.getValue()) < 0 ) 
          {
              // Since the new item is less than the item in runner,
              // it belongs in the left subtree of runner.  If there
              // is an open space at runner.left, add a node there.
              // Otherwise, advance runner down one level to the left.
             if ( runner.getLeft() == null ) 
             {
                runner.setLeft(newNode);
                return;  // New item has been added to the tree.
             }
             else
                runner = runner.getLeft();
          }
          else 
          {
               // Since the new item is greater than or equal to the 
               // item in runner, it belongs in the right subtree of
               // runner.  If there is an open space at runner.right, 
               // add a new node there.  Otherwise, advance runner
               // down one level to the right.
             if (runner.getRight() == null ) 
             {
                runner.setRight(newNode);
                return;  // New item has been added to the tree.
             }
             else
                runner = runner.getRight();
           }
       } // end while
    }  // end add
    
   }
   
   /***********************************/
   /*         contains Method         */
   /***********************************/ 
   public TreeNode contains(Comparable key)
   {
      return contains(getRoot(), key);
   }
   
   private TreeNode contains(TreeNode tree, Comparable key)
   {
      if(tree == null)
         return null;
      else
      {
         if(key.compareTo(tree.getValue()) == 0)
            return tree;
         else if(key.compareTo(tree.getValue()) < 0)
            return contains(tree.getLeft(), key);
         else
            return contains(tree.getRight(), key);
      }
   }
   
   /***********************************/
   /*          Remove Method          */
   /***********************************/ 
   public TreeNode remove(Comparable key)
   {
      return remove(key, getRoot());
   }
   
   private TreeNode remove(Comparable key, TreeNode tree) 
   {
        if (tree == null) 
             return null; // empty tree so nothing to remove
        else if(key.compareTo(tree.getValue()) < 0) 
        {           
           // search for key in left sub-tree. Set left-sub tree to 
           // result of recursive call to delete from left-subtree
           tree.setLeft(remove(key, tree.getLeft()));
        } 
        else if (key.compareTo(tree.getValue()) > 0) 
        { 
           // search for key in right sub-tree. Set right-sub tree to
           // result of recursive call to delete from right-subtree
           tree.setRight(remove(key, tree.getRight()));
        } 
        else if (tree.getLeft() != null && tree.getRight() != null) 
        {
           // tree refers to node to be deleted and it has no null children
           // find the in-order successor, disconnect it and return its
           // data value, setting this as the new data element of tree
           tree.setValue(disconnectSucc(tree));
        } 
        else if (tree.getLeft() == null) 
        {
           // tree refers to node to be deleted and its left child is 
           // null so set tree to refer to right child
           tree = tree.getRight();
        } 
        else 
        {
          // tree refers to node to be deleted and its left child 
          // is not null so set tree to refer to left child
          tree = tree.getLeft();
        }
        return tree;
  }
  
  // helper for remove method
  private Comparable disconnectSucc(TreeNode node) 
  {
     TreeNode succParent = node;
     TreeNode succ = node;
     TreeNode curr = node.getRight();
     
     // locate successor
     // The successor is leftmost node in the deleted nodes
     // right sub-tree
     while (curr != null) 
     {
       succParent = succ;
       succ = curr;
       curr = curr.getLeft();
     }
     
     // test if successor is right child of its parent node
     if (succ == succParent.getRight()) 
     {
       // set right child of parent to right child of successor
       succParent.setRight(succ.getRight());
     } 
     else 
     {
       // set left child of parent to right child of successor
       succParent.setLeft(succ.getRight());
     }
     return (Comparable)succ.getValue();
   }
   
   /***********************************/
   /*         Tree Traversals         */
   /***********************************/  
   
   // preOrder traversal : root-left-right
   public List<TreeNode> preOrderTraversal()
   {
      List<TreeNode> list = new ArrayList<TreeNode>();
      preOrderTraversal(getRoot(), list);
      return list;
   }
   
   private void preOrderTraversal(TreeNode tree, List<TreeNode> list)
   {
      if( tree!= null)
      {
         list.add(tree);
         preOrderTraversal(tree.getLeft(), list);
         preOrderTraversal(tree.getRight(), list);
      }
   }
   
   // inOrder traversal : left-root-right
   public List<TreeNode> inOrderTraversal()
   {
      List<TreeNode> list = new ArrayList<TreeNode>();
      inOrderTraversal(getRoot(), list);
      return list;
   }
   
   private void inOrderTraversal(TreeNode tree, List<TreeNode> list)
   {
      if( tree!= null)
      {
         inOrderTraversal(tree.getLeft(), list);
         list.add(tree);
         inOrderTraversal(tree.getRight(), list);
      }
   }
   
   // postOrder traversal : left-right-root
   public List<TreeNode> postOrderTraversal()
   {
      List<TreeNode> list = new ArrayList<TreeNode>();
      postOrderTraversal(getRoot(), list);
      return list;
   }
   
   private void postOrderTraversal(TreeNode tree, List<TreeNode> list)
   {
      if( tree!= null)
      {
         postOrderTraversal(tree.getLeft(), list);
         postOrderTraversal(tree.getRight(), list);
         list.add(tree);
      }
   }
   
   // levelOrder traversal : level-by-level
   public List<TreeNode> levelOrderTraversal()
   {
      List<TreeNode> list = new ArrayList<TreeNode>();  // list to accumlate nodes
      Queue <TreeNode> levelQueue = new LinkedList <TreeNode>();
      TreeNode tree = getRoot();

      if(!isEmpty())
      { 
        levelQueue.add(tree);
        levelOrderTraversal(levelQueue, list);
      }
      return list;
   }
   
   public void levelOrderTraversal(Queue<TreeNode>levelQueue, List<TreeNode> list)
   {   
      TreeNode node = null;
      if(!levelQueue.isEmpty())
      {
         node = levelQueue.remove(); // remove from queue
         list.add(node);             // and add to list
      
         if (node.getLeft() != null)
            levelQueue.add(node.getLeft());
      
         if (node.getRight() != null)
            levelQueue.add(node.getRight());
            
         levelOrderTraversal(levelQueue, list);     
      } 
   }
   
   /***********************************/
   /*            toString             */
   /***********************************/ 
   
   // prints tree vertically so that tree structure
   // can be easily identified - uses reverse inorder
   // traversal: right-root-left
   public String toString()
   {
      return toString(getRoot(), 0);
   }  
   
   private String toString(TreeNode tree, int level)
   {
      String str = "";
      if(tree != null)
      {
        str += toString(tree.getRight(), level + 1);
        for(int i = 1; i <= level; i++)
        {
            str = str + "  ";
        }
        str += tree.getValue().toString() + "\n";
        str += toString(tree.getLeft(), level + 1);
      }
      
      return str;
   }  
 }
 