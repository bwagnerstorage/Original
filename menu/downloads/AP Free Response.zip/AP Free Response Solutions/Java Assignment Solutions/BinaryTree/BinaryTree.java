public abstract class BinaryTree
{
   private TreeNode root;
   
   public BinaryTree()
   {
      root = null;
   } 

   public TreeNode getRoot()
   {
      return root;
   }

   public void setRoot(TreeNode theNewNode)
   {
      root = theNewNode;
   }
 
   public boolean isEmpty()
   {
      return root == null;
   }

   public abstract void add(Comparable item);
   public abstract TreeNode contains(Comparable key);
   public abstract TreeNode remove(Comparable key);
}