import java.util.*;

public class Tester
{
	public static void main(String[] args)
	{
		MyTreeSet set = new MyTreeSet();
		
		set.add("M");
		set.add("D");
		set.add("B");
		set.add("R");
		set.add("U");
		set.add("T");
		set.add("F");
		set.add("H");
		set.add("Y");
		set.add("X");
		set.add("Z");
		set.add("Q");
		
		// Tree Structure
		System.out.println();
		System.out.println("   Tree Structure");
		System.out.println("--------------------");
		System.out.println(set);
		
		// test size method
		System.out.println();
	    System.out.println("Test - size method");
		System.out.println("--------------------");
		System.out.println("Size = " + set.size());
		
		// test contains method
		System.out.println();
	    System.out.println("Test - contains method");
		System.out.println("----------------------");
		if(set.contains("B") != null)
		{
			System.out.println("Set contains B");
		}
		else
		{
			System.out.println("Set does not contain B");
		}
		if(set.contains("T") != null)
		{
			System.out.println("Set contains T");
		}
		else
		{
			System.out.println("Set does not contain T");
		}
		if(set.contains("S") != null)
		{
			System.out.println("Set contains S");
		}
		else
		{
			System.out.println("Set does not contain S");
		}
		
		// test remove method
		System.out.println();
	    System.out.println("Test - remove method");
		System.out.println("--------------------");
		if(set.remove("D") != null)
		{
			System.out.println("D was removed");
		}
		else
		{
			System.out.println("D was not removed");
		}
		
		if(set.remove("T") != null)
		{
			System.out.println("T was removed");
		}
		else
		{
			System.out.println("T was not removed");
		}
		
		System.out.println("Size = " + set.size());
		
		// test first method
		System.out.println();
	    System.out.println("Test - first method");
		System.out.println("--------------------");
		System.out.println("First item = " + set.first());
		
		// test last method
		System.out.println();
		System.out.println("Test - last method");
		System.out.println("--------------------");
		System.out.println("Last item = " + set.last());
		
		System.out.println();
		System.out.println("Test - subSet method (R to X)");
		System.out.println("--------------------");
		
		MyTreeSet subset = set.subSet("R", "X");
		
		System.out.println(subset);
		
		
		System.out.println();
		System.out.println("Test - iterator");
		System.out.println("---------------");
		
		Iterator iter = set.iterator();
		while(iter.hasNext())
		{
			System.out.print(iter.next() + " ");
		}
		System.out.println();
		
	}
}