// Contestant Number:
// 2-9-08

import java.util.*;

public class Menu
{
	public static void main(String[] args)
	{
	   Scanner keyboard = new Scanner(System.in);
	   String title = "Oklahoma State BPA Conference";
	   int ans = 0;
	   
	   do
	   {
	   	   System.out.println();
		   System.out.println("  " + title);
		   System.out.println();
		   System.out.println("1. Secondary Student");
		   System.out.println("2. Post Secondary Student");
		   System.out.println("3. Quit");
		   System.out.println();
		   System.out.print("Enter Choice(1-3):");
		   ans = keyboard.nextInt();
		   System.out.println();
	   }
	   while(ans < 1 || ans > 3);	   
	   
	   if(ans == 1)
	   {
	   	  System.out.println();
	   	  System.out.println(title);
	   	  System.out.println();
	   	  System.out.println("I am a Secondary Student.");
	   }
	   else if(ans == 2)
	   {
	   	  System.out.println();
	   	  System.out.println(title);
	   	  System.out.println();
	   	  System.out.println("I am a Post-Secondary Student.");
	   }
	   
	   System.out.println();
	   System.out.println();   	
	}
}
