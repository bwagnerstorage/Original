// Contestant Number:
// 2-7-08

#include <iostream>
#include <string>

using namespace std;

void main()
{
   string title = "Oklahoma State BPA Conference";
   int ans = 0;
	   
   do
   {
	   cout << endl;
	   cout << "   " << title;
	   cout << endl << endl;
	   cout << "1. Secondary Student" << endl;
	   cout << "2. Post Secondary Student" << endl;
	   cout << "3. Quit" << endl;
	   cout << endl;
	   cout << "Enter Choice(1-3):";
	   cin >> ans;
	   cout << endl;	   
	   
	   if(ans == 1)
	   {
	   	   cout << endl;
	   	   cout << title;
	   	   cout << endl << endl;
	   	   cout << "I am a Secondary Student." << endl;
	    }
		else if(ans == 2)
		{
	     	cout << endl;
	   		cout << title;
	   		cout << endl << endl;
	   		cout << "I am a Post-Secondary Student." << endl;
		}
	    cout << endl << endl; 
	}
	while(ans != 3);
}
