public interface MyMap
{
	// returns the number of key/value mappings in the map
	int size();
	
	// returns true if the map is empty; otherwise returns false
	boolean isEmpty();
	
	// returns true if the map contains a mapping for key, false otherwise
	boolean containsKey(Object key);
	
	// returns true if the map contains value, false otherwise
	boolean containsValue(Object value);
	
	// Associates key with value; returns the value formerly associated with key
	Object put(Object key, Object value);
	
	// returns the value associated with key or null if there is no associated value
	Object get(Object key);
	
	// removes and returns the value associated with key
	Object remove(Object key);
	
	// returns the set of keys contained in the map
	// MySet keySet();
}