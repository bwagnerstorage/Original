public class MyHashMap implements MyMap
{
	// constants
    public static final int DEFAULT_CAPACITY = 10;
    
	// instance variables
	private int capacity;     // size of table[]
	private HashNode table[]; // the hash table - with chaining
	private int size;         // number of entries in the map
	
	private HashNode current; // current node
	private HashNode prev;    // prev node
	private int index;        // index of current chain
	
	// constructor
	public MyHashMap()
	{
	   capacity = DEFAULT_CAPACITY;
	   size = 0;
	   table = new HashNode[capacity];	
	}
	public int size()
	{
	   return size;	
	}

	public boolean isEmpty()
	{
	   return size == 0;	
	}
	
	public boolean containsKey(Object key)
	{
	   index = Math.abs(key.hashCode()) % capacity;
	   prev = null;
	   current = table[index];
	   
	   while(current != null)
	   {
	   	  if(current.getKey().equals(key))
	   	  {
	   	  	return true;
	   	  }
	   	  else
	   	  {
	   	  	prev = current;
	   	  	current = current.getNext();
	   	  }
	   }
	   return false;	
	}

	public boolean containsValue(Object value)
	{
	   for(int i=0; i < table.length; i++)
	   {
	   	  for(HashNode node = table[i]; node != null; node = node.getNext())
	   	  {
	   	  	if(node.getValue().equals(value))
	   	  	{
	   	  		return true;
	   	  	}
	   	  }
	   }
	   return false;	
	}

	public Object put(Object key, Object value)
	{
	   if(!containsKey(key))
	   {
	   	  HashNode newNode = new HashNode(key, value, table[index]);
	   	  table[index] = newNode;
	   	  size++;
	   	  return null;
	   }
	   else
	   {
	   	  Object returnValue = current.getValue();
	   	  current.setValue(value);
	   	  return returnValue;
	   }	
	}
	
	
	public Object get(Object key)
	{
	   if(containsKey(key))
	   {
	   	  return current.getValue();
	   }
	   else
	      return null;	
	}
	
	
	public Object remove(Object key)
	{
		if(!containsKey(key))
		{
			return null;
		}
		else
		{
			if(prev == null)
			{
				table[index] = current.getNext();
			}
			else
			{
				prev.setNext(current.getNext());
			}
			size--;
			return current.getValue();
		}
	}
	
/*	public MySet keySet()
	{
		return null;
	} */
}