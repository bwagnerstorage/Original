public class MyHashMapTester
{
	public static void main(String[] args)
	{
		MyHashMap map = new MyHashMap();
		
		System.out.println("1) Test put method");
		System.out.println("==================");
		System.out.println("(1, John)");
		System.out.println("(2, Mary)");
		System.out.println("(3, Jose)");
		System.out.println("(4, Brittany)");
		System.out.println("(5, Alicia)");
		System.out.println("(6, Kendall)");
		System.out.println("(7, Michael)");
	    map.put(1, "John");
		map.put(2, "Mary");
		map.put(3, "Jose");
		map.put(4, "Brittany");
		map.put(5, "Alicia");
		map.put(6, "Kendall");
		map.put(7, "Michael");
		
		System.out.println();
		System.out.println("2) Test get method");
		System.out.println("==================");
		System.out.println(map.get(1));
		System.out.println(map.get(4));
		System.out.println(map.get(7));
		
		System.out.println();
		System.out.println("3) Test put (replace) method");
		System.out.println("============================");
		System.out.println(map.put(3, "Steve") + " was replaced with Steve");
		
		System.out.println();
		System.out.println("4) Test size method");
		System.out.println("===================");
		System.out.println();
		System.out.println("Size = " + map.size());
		
		System.out.println();
		System.out.println("5) Test remove method");
		System.out.println("=====================");
		System.out.println(map.remove(5) + " was removed");
		
		System.out.println();
		System.out.println("Size = " + map.size());
		
		System.out.println();
		System.out.println("6) Test containsKey method");
		System.out.println("==========================");
		if(map.containsKey(1))
		   System.out.println("Map contains key 1");
		else
		   System.out.println("Map does not contain key 1");
		if(map.containsKey(5))
		   System.out.println("Map contains key 5");
		else
		   System.out.println("Map does not contain key 5");
		if(map.containsValue(8))
		   System.out.println("Map contains key 8");
		else
		   System.out.println("Map does not contain key 8");
		
		System.out.println();
		System.out.println("7) Test containsValue method");
		System.out.println("============================");
		if(map.containsValue("John"))
		   System.out.println("Map contains John");
		else
		   System.out.println("Map does not contain John");
		if(map.containsValue("Kendall"))
		   System.out.println("Map contains Kendall");
		else
		   System.out.println("Map does not contain Kendall");
		if(map.containsValue("Bill"))
		   System.out.println("Map contains Bill");
		else
		   System.out.println("Map does not contain Bill");	
	}
}