public class HashNode
{
	// instance variables
	private Object key;
	private Object value;
	private HashNode next;
	
	// constructor
	public HashNode(Object key, Object value, HashNode next)
	{
		this.key = key;
		this.value = value;
		this.next = next;
	}
	
	// accessor methods
	public Object getKey()
	{
		return key;
	}
	
	public Object getValue()
	{
		return value;
	}
	
	public HashNode getNext()
	{
		return next;
	}
	
	// mutator methods
	public void setKey(Object key)
	{
		this.key = key;
	}
	
	public void setValue(Object value)
	{
		this.value = value;
	}
	
	public void setNext(HashNode next)
	{
		this.next = next;
	}
	
	// toString method
	public String toString()
	{
		return "(" + key + ", " + value + ")";
	}
}