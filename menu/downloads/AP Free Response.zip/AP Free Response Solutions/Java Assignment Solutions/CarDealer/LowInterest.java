public class LowInterest extends Incentive
{
	public String getType()
	{
		return "Low Interest Rate";
	}
	
	public double getDiscount()
	{
		return 1000;
	}
	
	public double getInterestRate()
	{
		return 0.0;
	}
}