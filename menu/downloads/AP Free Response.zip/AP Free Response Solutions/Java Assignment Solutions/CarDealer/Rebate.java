public class Rebate extends Incentive
{	
    public String getType()
    {
    	return "Rebate";
    }
	public double getDiscount()
	{
		return 5000;
	}
	
	public double getInterestRate()
	{
		return 0.06;
	}
}