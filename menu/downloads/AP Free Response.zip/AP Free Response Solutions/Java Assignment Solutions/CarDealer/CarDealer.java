public class CarDealer
{
	// instance varialbles
	private Car car1;
	private Car car2;
	
	public CarDealer()
	{
		car1 = new Car("RX12" , 40000, 3000, new Rebate());
		printSaleSummary(car1);
		
		car2 = new Car("RX12" , 40000, 3000, new LowInterest());
		printSaleSummary(car2);
	}
	
	public void printSaleSummary(Car car)
	{
		System.out.println();
		System.out.println("Sale Summary");
		System.out.println("============");
		System.out.println(car);
	}
	
	public static void main(String[] args)
	{
		CarDealer app = new CarDealer();
	}
}