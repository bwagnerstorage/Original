public class Car
{
	// Instance Variables
	private String model;
	private double MSRP;
	private double dealerDiscount;
	private Incentive incentive;
	
	public Car(String m, double msrp, double discount, Incentive in)
	{
	   model = m;	
	   MSRP = msrp;
	   dealerDiscount = discount;
	   incentive = in;
	}
	
	public double getSalePrice()
	{
		return MSRP - dealerDiscount - incentive.getDiscount();
	}
	
	public double getMonthlyPayment()
	{
		double principal = getSalePrice();
		double rate = incentive.getInterestRate();
		double time = 60;  // 5 years
		
		double interestAmount = principal * rate/12 * 60;
		
		return (principal + interestAmount) / time;
		
	}
	
	public String toString()
	{
		return "Model:              " + model + "\n" +
	           "MSRP:               " + MSRP  + "\n" +
	           "Dealer Discount:    " + dealerDiscount + "\n" +
	           "Incentive Type :    " + incentive.getType() + "\n" +
	           "Incentive Discount: " + incentive.getDiscount() + "\n" +
	           "Interest Rate:      " + incentive.getInterestRate() + "\n" +
	           "--------------------------------------\n" +
	           "Sale Price:         $" + getSalePrice() + "\n" + 
	           "Monthly Payment:    $" + getMonthlyPayment();
	}
}