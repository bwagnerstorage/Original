public abstract class Incentive
{
    // instance variables
	private String incentiveType;
	
	public abstract String getType();
	public abstract double getDiscount();
	public abstract double getInterestRate();

}