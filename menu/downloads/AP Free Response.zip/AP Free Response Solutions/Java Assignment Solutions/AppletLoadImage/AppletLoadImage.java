import java.awt.*;
import java.applet.*;

public class AppletLoadImage extends Applet 
{
	Image myImage;
	
	public void init() 
	{
	   myImage = getImage(getCodeBase(), "x.gif");
	}

	public void paint(Graphics page) 
	{
	   page.drawImage(myImage, 0, 0, this);
	}
}
