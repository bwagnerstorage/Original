import java.util.*;

public class LinkedStackTest
{
	private LinkedStack stack;
	private Scanner keyboard;
	
	public LinkedStackTest()
	{
	   stack = new LinkedStack();
	   keyboard = new Scanner(System.in);
	   
	   int ans;
	   do
	   {
	   	  ans = menu();
	   	  if(ans == 1)
	   	  {
	   	  	 stack.push((int)(Math.random() * 50));
	   	  }
	   	  if(ans == 2)
	   	  {
	   	  	 if(!stack.isEmpty())
	   	  	   stack.pop();
	   	  	 else
	   	  	   System.out.println("Stack is empty!");
	   	  }
	   	  System.out.println(stack);
	   }
	   while(ans != 3);
	}
	
	public int menu()
	{	
		int ans = 0;
		System.out.print("1)Push  2)Pop  3)Exit : ");
		ans = keyboard.nextInt();
		return ans;
	}
	
	public static void main(String[] args)
	{
	  LinkedStackTest app = new LinkedStackTest();	
	}
}