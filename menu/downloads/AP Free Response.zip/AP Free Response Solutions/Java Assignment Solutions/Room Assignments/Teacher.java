public class Teacher implements Comparable
{
    // instance variables
    private int roomNumber;
    private String lastName;
    private String firstName;
    
    
    // constructor
    public Teacher(int r, String l, String f)
    {
        roomNumber = r;
        lastName = l;
        firstName = f;  
    }
    
    // Accessor Methods
    public int getRoomNumber()
    {
        return roomNumber;
    }
    
    public String getLastName()
    {
        return lastName;
    }
    
    public String getFirstName()
    {
        return firstName;
    }
    
    // mutator methods
    public void setRoomNumber(int r)
    {
        roomNumber = r;
    }
    
    public void setLastName(String l)
    {
        lastName = l;
    }
    
    public void setFirstName(String f)
    {
        firstName = f;
    }
 
    public String toString()
    {
        return roomNumber + "   " + lastName + " " + firstName;
    }
    
    public int compareTo(Object otherTeacher)
    {
        if(roomNumber < ((Teacher)otherTeacher).roomNumber)
           return -1;
        else if(roomNumber > ((Teacher)otherTeacher).roomNumber)
           return 1;
        else
           return 0;
    }
}