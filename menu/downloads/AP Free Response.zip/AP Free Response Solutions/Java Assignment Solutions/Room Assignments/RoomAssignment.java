import java.util.*;
import java.io.*;

public class RoomAssignment
{
    // instance variables
    private ArrayList <Teacher> list;
    
    // constructor
    public RoomAssignment()
    {
        list = new ArrayList <Teacher> ();
        readFile();
        mainMenu();
    }
    
    public void readFile()
    {
        Scanner scan;
       
        try
        {
           scan = new Scanner(new File("rooms.dat"));   
           while(scan.hasNext())
           {
              int room = scan.nextInt();
              String lastName = scan.next();
              String firstName = scan.next();
              
              Teacher teacher = new Teacher(room, lastName, firstName);
              list.add(teacher);          
           }
        }
        catch(IOException e)
        {
            System.out.println("File not found!");
        }
          
    }
    
    public void mainMenu()
    {
        Scanner keyboard = new Scanner(System.in);
        int ans = 0;
        
        do
        {
            System.out.println("Main Menu");
            System.out.println("=========");
            System.out.println("1. Add");
            System.out.println("2. View");
            System.out.println("3. Edit");
            System.out.println("4. Remove");
            System.out.println("5. Exit");
            System.out.println();
            System.out.print("Select-->");
            ans = keyboard.nextInt();
            
            if(ans == 1)
            {
                Add();
            }
            if(ans == 2)
            {
                View();
            }
            if(ans == 3)
            {
                Edit();
            }
            if(ans == 4)
            {
                Remove();
            }
            
        }
        while(ans <= 4);
    }
    
    // Creates a teacher object and adds it to list
    // maintaining the lists sorted order
    public void Add()
    {
        Scanner keyboard = new Scanner(System.in);
        System.out.println();
        System.out.print("Enter room number -->");
        int room = keyboard.nextInt();
        System.out.print("Enter last name -->");
        String dummy = keyboard.nextLine();
        String last = keyboard.nextLine();
        System.out.print("Enter first name -->");
        String first = keyboard.nextLine();
        
        Teacher teacher = new Teacher(room, last, first);
        int i=0;
        boolean found=false;
        while(i < list.size() && !found)
        {
            if(teacher.compareTo(list.get(i)) > 0)
            {
               i++; 
            }
            else
                found = true;
        }   
        list.add(i, teacher);   
    }
    
    // Displays the list of teachers including each teacher's
    // room number, last name, and first name
    public void View()
    {
        System.out.println();
        System.out.println("Room  Teacher");
        System.out.println("==============");
        for(Teacher teacher : list)
        {
            System.out.println(teacher);
        }
        System.out.println();
    }
    
    // Searches the list by room number. If a match is found
    // the record's last name and first name is updated.
    public void Edit()
    {
        Scanner keyboard = new Scanner(System.in);
        System.out.print("Enter room number -->");
        int room = keyboard.nextInt();
        
        for(Teacher teacher : list)
        {
            if(room == teacher.getRoomNumber())
            {
               System.out.println();
               System.out.println(teacher);
               System.out.println();
               System.out.print("Enter Last Name -->");
               String dummy = keyboard.nextLine();
               String last = keyboard.nextLine();
               System.out.print("Enter First Name -->");
               String first = keyboard.nextLine();
               System.out.println();
               
               teacher.setLastName(last);
               teacher.setFirstName(first);
            }
        }
    }
    
    // Searches the list by room number. If a match is found
    // the record is removed from the list maintaining the
    // sorted order.
    public void Remove()
    {
        Scanner keyboard = new Scanner(System.in);
        System.out.print("Enter room number -->");
        int room = keyboard.nextInt();
        
        int i=0;
        while(i < list.size())
        {
            if(room == list.get(i).getRoomNumber())
            {
                list.remove(i);
            }
            else
              i++;
        }
    }
    
    public static void main(String[] args)
    {
        RoomAssignment app = new RoomAssignment();
    }
}