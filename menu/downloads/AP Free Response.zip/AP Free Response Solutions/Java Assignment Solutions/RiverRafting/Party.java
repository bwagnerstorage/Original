public class Party
{
	private String guideName;
	private int numPeople;      // number of people in party
	
	public Party(String p, int n)
	{
		guideName = p;
		numPeople = n;
	}
	
	public String getGuideName()
	{
		return guideName;
	}
	
	public int getNumPeople()
	{
		return numPeople;
	}
	
	public void addPeople(int n)
	{
		numPeople += n;
	}
	
	public void deletePeople(int n)
	{
		numPeople -= n;
	}
}