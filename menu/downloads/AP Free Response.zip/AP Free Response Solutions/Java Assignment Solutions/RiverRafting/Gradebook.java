public class Gradebook
{
    private StudentInfo[] students;
    private int numStudents;
    
    public Gradebook(int s)
    {
       students = new StudentInfo[s];   
       numStudents = 0;
    }
    
    public void addStudent(String name)
    {
        students[numStudents] = new StudentInfo(name);
        numStudents++;
    }
    
    public void calculateAvg(int student, int[] grades)
    {
        int sum = 0;
        double average = 0;
        for(int i=0; i < grades.length; i++)
        {
          sum += grades[i];
        }
        average = (double)sum / grades.length;
        students[student].setAverage(average);
    }
	
	public void display()
	{
		for(int i =0; i < numStudents; i++)
		{
			System.out.println(students[i].getName() +  " " + students[i].getAverage());
		}
	}

	public static void main(String[] arg)
	{
		Gradebook apps = new Gradebook(3);
		
		apps.addStudent("John");
		int[] grades = {100, 95, 78, 85};
		apps.calculateAvg(0, grades);
		apps.display();
		
	}
}

class StudentInfo
{
    private String name;
    private double average;
    
    public StudentInfo(String n)
    {
        name = n;
    }
    
    public void setAverage(double avg)
    {
        average = avg;
    }
    
    // accessor methods not shown
}