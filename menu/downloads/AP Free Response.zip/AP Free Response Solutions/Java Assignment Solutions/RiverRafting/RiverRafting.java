public class RiverRafting
{
	public final int MAX = 50;
	public final int ADD = 0;
	public final int SUB = 1;
	
	private Party[] rafters;
	private int numParties;
	 
	public RiverRafting()
	{
		rafters = new Party[MAX];
		numParties = 0;
		
		addParty("Crazy George", 6);
		addParty("Wild Billy", 8);
		addParty("Rad Man", 12);
		
		printRafters();
		
		changeParty("Wild Billy", ADD, 2);
		changeParty("Rad Man", SUB, 1);
		
		printRafters();
	}
	
	public void addParty(String guide, int numGuests)
	{
		rafters[numParties] = new Party(guide, numGuests);
		numParties++;
	}
	
	public void changeParty(String guide, int code, int numGuests)
	{
		boolean found = false;
		int i=0;
		while(!found && i < numParties)
		{
		   if(guide.equals(rafters[i].getGuideName()))
		   {
		   	    if(code == 0)  // add
				{
					rafters[i].addPeople(numGuests);
				}
				else
				{
					rafters[i].deletePeople(numGuests);
				}
				found = true;
		   }
		   i++;	
		}
	}
	
	public void printRafters()
	{
		for(int i=0; i < numParties; i++)
		{
			Party p = rafters[i];
			System.out.print(p.getGuideName() + " ");
			System.out.println(p.getNumPeople());
		}
		System.out.println();
	}
	
	public static void main(String[] args)
	{
		RiverRafting app = new RiverRafting();
	}
}