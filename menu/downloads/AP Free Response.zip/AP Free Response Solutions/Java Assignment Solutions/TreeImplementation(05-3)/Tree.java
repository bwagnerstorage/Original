public class Tree 
{ 
   private TreeNode root; 

   // constructs a new, empty tree 
   public Tree() 
   { 
      root = null; 
   }
   
   public void setRoot(TreeNode node)
   {
   	  root = node;
   }

   
   // returns the node containing the smallest value in the tree 
   // rooted at t when t is not null; otherwise, returns null; 
   // the method runs in time O(h), where h is the height 
   // of the tree rooted at t 
   private TreeNode minNode(TreeNode t) 
   { 
      TreeNode current = t;
      while(current.getLeft() != null)
      {
      	 current = current.getLeft();
      }
      return current;
   }

   // returns the node containing the largest value in the tree 
   // rooted at t when t is not null; otherwise, returns null; 
   // the method runs in time O(h), where h is the height 
   // of the tree rooted at t 
   private TreeNode maxNode(TreeNode t) 
   { 
      TreeNode current = t;
      while(current.getRight() != null)
      {
      	 current = current.getRight();
      }
      return current;
   }


   // returns true if all nodes in this tree have correct parent links; 
   // otherwise, returns false; 
   // each node should be the parent of its left and right children; 
   // the root node's parent should be null 
   public boolean verifyParentLinks() 
   { 
      return verifyParentLinks(root);
   }
   
   private boolean verifyParentLinks(TreeNode root)
   {
   	  if(root != null)
   	  {
   	  	  if(root.getLeft() != null && root.getLeft().getParent() != root)
   	  	     return false;
   	  	  if(root.getRight() != null && root.getRight().getParent() != root)
   	  	     return false;
   	  	  return verifyParentLinks(root.getLeft()) & verifyParentLinks(root.getRight());
   	  }
   	  return true;
   }


   // returns the node which is the successor of t in this tree; 
   // returns null if t contains the maximum value in this tree; 
   // the method runs in time O(h), where h is the height 
   // of the tree rooted at t 
   // precondition: t is a node in this tree; 
   // all nodes in this tree have correct parent links
   public TreeNode successor(TreeNode t) 
   { 
   	  TreeNode parent = t.getParent();
      if(parent == null && t.getRight() != null)
      	  return minNode(t.getRight());
      else if(t.getRight() != null)
          return t.getRight();
      else if(parent != null && parent.getLeft() == t)
          return parent;
      else
      {
      	 TreeNode max = t;
      	 while(parent != null)
      	 {
      	 	if(((Comparable)parent.getValue()).compareTo(max.getValue())> 0)
      	 		max = parent;
      	 	parent = parent.getParent();
      	 }
      	 if(max == t)
      	 	return null;
      	 return max;
      }

   }
   
   
   /***********************************/
   /*            toString             */
   /***********************************/ 
   
   // prints tree vertically so that tree structure
   // can be easily identified - uses reverse inorder
   // traversal: right-root-left
   public String toString()
   {
      return toString(root, 0);
   }  
   
   private String toString(TreeNode tree, int level)
   {
      String str = "";
      if(tree != null)
      {
        str += toString(tree.getRight(), level + 1);
        for(int i = 1; i <= level; i++)
        {
            str = str + "  ";
        }
        str += tree.getValue().toString() + "\n";
        str += toString(tree.getLeft(), level + 1);
      }
      
      return str;
   }  
}