public class Tester
{
	public static void main(String[] args)
	{
		Tree tree1 = new Tree();
		
		// tree 1
		TreeNode root = new TreeNode("M", null, null, null);
		TreeNode G = new TreeNode("G",null, null, root);
		root.setLeft(G);
		TreeNode D = new TreeNode("D",null,null,G);
		G.setLeft(D);
		TreeNode J = new TreeNode("J",null,null,G);
		G.setRight(J);
		TreeNode A = new TreeNode("A",null,null,D);
		D.setLeft(A);
		
		TreeNode T = new TreeNode("T",null,null,root);
		root.setRight(T);
		TreeNode P = new TreeNode("P",null,null,T);
		T.setLeft(P);
		TreeNode X = new TreeNode("X",null,null,T);
		T.setRight(X);
		
		tree1.setRoot(root);
		
		System.out.println();
		System.out.println(tree1);
		System.out.println();
		
		System.out.println("VerifyParentLinks");
		System.out.println("-----------------");
		System.out.println("Tree 1 = " + tree1.verifyParentLinks());
		
		
		
		Tree tree2 = new Tree();
		
		// tree 2
		TreeNode root2 = new TreeNode("M", null, null, null);
		TreeNode G2 = new TreeNode("G",null, null, root2);
		root2.setLeft(G2);
		TreeNode D2 = new TreeNode("D",null,null,G2);
		G2.setLeft(D2);
		TreeNode J2 = new TreeNode("J",null,null,null);
		G2.setRight(J2);
		TreeNode A2 = new TreeNode("A",null,null,D2);
		D2.setLeft(A2);
		
		TreeNode T2 = new TreeNode("T",null,null,root2);
		root2.setRight(T2);
		TreeNode P2 = new TreeNode("P",null,null,T2);
		T2.setLeft(P2);
		TreeNode X2 = new TreeNode("X",null,null,T2);
		T2.setRight(X2);
		
		tree2.setRoot(root2);
		
		System.out.println();
		System.out.println("VerifyParentLinks");
		System.out.println("-----------------");
		System.out.println("Tree 2 = " + tree2.verifyParentLinks());
		
		System.out.println();
	    System.out.println("Successor");
		System.out.println("---------");
		System.out.println();
		System.out.println();
		System.out.println(tree1);
		System.out.println();
		System.out.print("Successor of D = "); 
		TreeNode node = tree1.successor(D);
		if(node != null)
		   System.out.println(node.getValue());
		else
		   System.out.println("no successor");
		   
		System.out.println();
		System.out.print("Successor of J = "); 
		node = tree1.successor(J);
		if(node != null)
		   System.out.println(node.getValue());
		else
		   System.out.println("no successor");
		   
		System.out.println();
		System.out.print("Successor of X = "); 
		node = tree1.successor(X);
		if(node != null)
		   System.out.println(node.getValue());
		else
		   System.out.println("no successor");
		   
		System.out.println();
		System.out.print("Successor of T = "); 
		node = tree1.successor(T);
		if(node != null)
		   System.out.println(node.getValue());
		else
		   System.out.println("no successor");
		   
		System.out.println();
		System.out.println();
		
	}
}