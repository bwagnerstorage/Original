import java.util.*;

public class BinarySearchTree
{
   private TreeNode root;
   
   public BinarySearchTree()
   {
      root = null;
   }
   
   public void add(Comparable item)
   {
      TreeNode newNode = new TreeNode(item);
      
      if(root == null)
      {
         root = newNode;
      }
      else
      {
        TreeNode runner = root;   // Start at the root.
        while (true) {
          if ( item.compareTo(runner.getValue()) < 0 ) 
          {
              // Since the new item is less than the item in runner,
              // it belongs in the left subtree of runner.  If there
              // is an open space at runner.left, add a node there.
              // Otherwise, advance runner down one level to the left.
             if ( runner.getLeft() == null ) 
             {
                runner.setLeft(newNode);
                return;  // New item has been added to the tree.
             }
             else
                runner = runner.getLeft();
          }
          else 
          {
               // Since the new item is greater than or equal to the 
               // item in runner, it belongs in the right subtree of
               // runner.  If there is an open space at runner.right, 
               // add a new node there.  Otherwise, advance runner
               // down one level to the right.
             if (runner.getRight() == null ) 
             {
                runner.setRight(newNode);
                return;  // New item has been added to the tree.
             }
             else
                runner = runner.getRight();
           }
       } // end while
    }  // end add
   }
   
   // counts and returns the number of nodes in tree
   public int numNodes()
   {
   	  return numNodes(root);
   }
   
   public int numNodes(TreeNode root)
   {
   	  if(root == null)
   	  {
   	  	 return 0;
   	  }
   	  else
   	  {
   	  	 return 1 + numNodes(root.getLeft()) + numNodes(root.getRight());
   	  }
   }
   
   public int numLeaves()
   {
   	  return numLeaves(root);
   }
   
   public int numLeaves(TreeNode root)
   {
   	  if(root == null)
   	  {
   	  	 return 0;
   	  }
   	  else if(root.getLeft() == null && root.getRight() == null)
   	  {
   	  	return 1 + numLeaves(root.getLeft()) + numLeaves(root.getRight());
   	  }
   	  else
   	  {
   	  	 return numLeaves(root.getLeft()) + numLeaves(root.getRight());
   	  }
   }
   
   public int numParents()
   {
   	  return numParents(root);
   }
   
   public int numParents(TreeNode root)
   {
   	  if(root == null)
   	  {
   	  	 return 0;
   	  }
   	  else if(root.getLeft() != null || root.getRight() != null)
   	  {
   	  	return 1 + numParents(root.getLeft()) + numParents(root.getRight());
   	  }
   	  else
   	  {
   	  	 return numParents(root.getLeft()) + numParents(root.getRight());
   	  }
   }
   
   // prints tree vertically so that tree structure
   // can be easily identified - uses reverse inorder
   // traversal: right-root-left
   public String toString()
   {
      return toString(root, 0);
   }
   
   // return string representation of tree's structure
   private String toString(TreeNode root, int level)
   {
      String str = "";
      if(root != null)
      {
        str += toString(root.getRight(), level + 1);
        for(int i = 1; i <= level; i++)
        {
            str = str + "  ";
        }
        str += root.getValue().toString() + "\n";
        str += toString(root.getLeft(), level + 1);
      }
      
      return str;
   }  

}