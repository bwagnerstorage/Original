public interface Queue
{
    // adds item to queue and assigns priority
    // the smaller the priority number the higher the priority.
    // (1 = highest priority, 2 = next highest, ...)
    public void add(Object obj, int priority);
    
    // view item with highest priority
    public Object peek();
    
    // remove item with highest priority
    public Object remove();
    
    // returns number of items in queue
    public int size();
    
    // returns true if queue is empty;
    // otherwise returns false
    public boolean isEmpty();
    
}