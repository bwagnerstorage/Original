public class HeapNode
{
   // instance variables
   private Object data;
   private int priority;

   // constructor
   public HeapNode(Object d, int p)
   {
      data = d;
      priority = p;
   }
   
   // accessor methods
   public Object getData()
   {
      return data;
   }
   
   public int getPriority()
   {
     return priority;
   }
   
   // mutator methods
   public void setData(Object d)
   {
      data = d;
   }
   
   public void setPriority(int p)
   {
      priority = p;
   }
}