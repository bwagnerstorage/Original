public class HeapPriorityQueue implements Queue
{
   // constants
   public final int CAPACITY = 100;
   
   // instance variables
   private HeapNode[] heap;
   private int size;
   
   public HeapPriorityQueue()
   {
   	  heap = new HeapNode[CAPACITY];
   	  size = 0;
   }
	
   public void add(Object obj, int priority)
   {
   	  insert(new HeapNode(obj, priority));
   }
	
   public Object peek()
   {
   	  HeapNode top = heap[0];
   	  return top.getData();
   }
	
   public Object remove()
   {
   	  HeapNode max = removeMax();
   	  return max.getData();
   }
	
   public int size()
   {
   	  return size;
   }
	
   public boolean isEmpty()
   {
   	  return size() == 0;
   }
   
   // Helper Methods
    public void insert(HeapNode node)
    {
       heap[size] = node;
       reheapUpward();
       size++; 
    }
	
	private void reheapUpward()
	{
	   int i = size;
	   while(i > 0 && heap[i].getPriority() <= heap[(i-1)/2].getPriority())
	   {
	   	  if(heap[i].getPriority() <= heap[(i-1)/2].getPriority())
	   	  {
	   	  	 // swap
	   	  	 HeapNode temp = heap[(i-1)/2];
	   	     heap[(i-1)/2] = heap[i];
	   	     heap[i] = temp;
	   	     
	   	     i = (i-1)/2; 
	   	  }
	   	  else
	   	     i--;		  	
	   }
	}
	
	public HeapNode removeMax()
	{
		HeapNode max = heap[0];
		heap[0] = heap[size-1];
		reheapDownward();
		size--;
                   
		return max;
	}

	private void reheapDownward()
	{
		int i=0,j=0;
		do
		{
			i = j;
			if((i*2+1) < size-1 && heap[i*2+1].getPriority() < heap[j].getPriority())
			  j = i*2+1;
			if((i*2+1) < size-1 && heap[i*2+2].getPriority() < heap[j].getPriority())
			  j = i*2+2;
			  
			// swap
			HeapNode temp = heap[i];
	   	    heap[i] = heap[j];
	   	    heap[j] = temp; 
		}
		while(i != j);
	}
}

