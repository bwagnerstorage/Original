import java.util.*;

public class BinarySearchTree
{
   private TreeNode root;
   
   public BinarySearchTree()
   {
      root = null;
   }
   
   public void add(Comparable item)
   {
   	  root = add(root, item);
   }
   
   private TreeNode add(TreeNode root, Comparable item)
   {
   	  if(root == null)
   	  {
   	  	 return new TreeNode(item, null, null);
   	  }
   	  if(item.compareTo(root.getValue()) < 0)
   	     root.setLeft(add(root.getLeft(), item));
   	  else 
   	     root.setRight(add(root.getRight(), item));
   	     
   	  return root;
    }
    
    
	// returns true if root is null or if all values stored in
	// tree represented by root are less than key;
	// otherwise returns false
	public boolean valsLess(int key)
	{
	   return valsLess(root, key);
	}
	
	private boolean valsLess(TreeNode root, int key)
	{
	   if(root == null)
	      return true;
	   
	   int value = (Integer)root.getValue();
	   return value < key && valsLess(root.getLeft(), key) && valsLess(root.getRight(), key);
	}
	
    // part(a)
	// returns the minimum data value found in tree
	public Object minValue()
	{
		TreeNode current = root;
		Object data = null;
		while(current != null)
		{
			data = current.getValue();
			current = current.getLeft();
		}
	    return data;
	}
	
	public int treeHeight()
	{
		return treeHeight(root);
	}
	
	// part(b)
	// returns the number of nodes along the longest
	//   path from the root node down to the farthest
	//   leaf node
	private int treeHeight(TreeNode root)
	{
		if(root == null)
		{
			return 0;
		}
		if(treeHeight(root.getLeft()) > treeHeight(root.getRight()))
			return 1 + treeHeight(root.getLeft());
	    else
	    	return 1 + treeHeight(root.getRight());
	}
	
	public boolean hasPathSum(int sum)
	{	
		return hasPathSum(root, sum);
	}
	
	// part(c)
	// given a tree and a sum,
	// returns true if there is a path from the root
	//   down to a leaf, such that adding up all the 
	//   values along the path equals the given sum
	private boolean hasPathSum(TreeNode root, int sum)
	{
	   if(sum == 0)
	   	  return true;
	   if(root != null)
	   {
	   	  int value = (Integer)root.getValue();
	   	  sum -= value;
	   	  return hasPathSum(root.getLeft(), sum) || hasPathSum(root.getRight(), sum);
	   }
	   return false;
	   	  
	}
	
	public void mirror()
	{
	   mirror(root);	
	}
	
	// part(d)
	// changes a tree so that the roles of the left
	//   and right pointers are swapped at every node
	private void mirror(TreeNode root)
	{
	   if(root != null)
	   {
	   	  TreeNode temp = root.getLeft();
	   	  root.setLeft(root.getRight());
	   	  root.setRight(temp);
	   	  mirror(root.getLeft());
	   	  mirror(root.getRight());
	   }	
	}
	
   /***********************************/
   /*            toString             */
   /***********************************/ 
   
   // prints tree vertically so that tree structure
   // can be easily identified - uses reverse inorder
   // traversal: right-root-left
   public String toString()
   {
      return toString(root, 0);
   }  
   
   private String toString(TreeNode tree, int level)
   {
      String str = "";
      if(tree != null)
      {
        str += toString(tree.getRight(), level + 1);
        for(int i = 1; i <= level; i++)
        {
            str = str + "  ";
        }
        str += tree.getValue().toString() + "\n";
        str += toString(tree.getLeft(), level + 1);
      }
      
      return str;
   }  
}