import java.util.*;

public class Tester
{
	public static void main(String[] args)
	{
		MovieAdvice tree = new MovieAdvice();
		
		AdviceNode node1 = new AdviceNode("Do you want to see a romantic movie?");
		AdviceNode node21 = new AdviceNode("A classic movie?");
		node1.setYes(node21);
		AdviceNode node22 = new AdviceNode("Science Fiction?");
		node1.setNo(node22);
		
		AdviceNode node31 = new AdviceNode("Casablanca");
		node21.setYes(node31);
		AdviceNode node32 = new AdviceNode("Titanic");
		node21.setNo(node32);
		
		AdviceNode node33 = new AdviceNode("StarWars");
		node22.setYes(node33);
		AdviceNode node34 = new AdviceNode("Suspense?");
		node22.setNo(node34);
		
		AdviceNode node41 = new AdviceNode("Jaws");
		node34.setYes(node41);
		AdviceNode node42 = new AdviceNode("Citizen Kane");
		node34.setNo(node42);
		
		tree.setRoot(node1);
		
		System.out.println();
		System.out.println(tree);
		System.out.println();
		
		System.out.println("Give Advice");
		System.out.println("-----------");
		System.out.println();
		tree.giveAdvice();
		System.out.println();
		System.out.println();
		tree.giveAdvice();
		System.out.println(); 
		
		System.out.println("Trace Path");
		System.out.println("----------");
		System.out.println();
		Stack <String> pathStack = new Stack<String>();
		if(tree.tracePath("Casablanca", pathStack))
		{
			while(!pathStack.isEmpty())
			{
				System.out.println(pathStack.pop());
			}
		}
		else
			System.out.println("Movie not found!");
		System.out.println();
		pathStack = new Stack<String>();
		if(tree.tracePath("Jaws", pathStack))
		{
			while(!pathStack.isEmpty())
			{
				System.out.println(pathStack.pop());
			}
		}
		else
			System.out.println("Movie not found!");
		System.out.println();
		
		System.out.println();
		pathStack = new Stack<String>();
		if(tree.tracePath("Gone with the Wind", pathStack))
		{
			while(!pathStack.isEmpty())
			{
				System.out.println(pathStack.pop());
			}
		}
		else
			System.out.println("Movie not found!");
		System.out.println();		
		
	}
}