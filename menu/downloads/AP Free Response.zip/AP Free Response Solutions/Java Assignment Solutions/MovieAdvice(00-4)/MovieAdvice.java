import java.util.*;

public class MovieAdvice 
{ 
	private AdviceNode root;
	private Scanner keyboard;
	
    // constructor 
	public MovieAdvice()
	{
	    root = null;
	    keyboard = new Scanner(System.in);
	}
	
	public void setRoot(AdviceNode node)
	{
		root = node;
	}
	
	// precondition: T is not NULL 
	// postcondition: returns true if T points to a question node; 
	// otherwise, returns false	
	public boolean isQuestionNode(AdviceNode T)
	{
		return (T.getYes() != null && T.getNo() != null);
	}
	
	// precondition: T is not NULL 
	public void giveAdvice()
	{
	  giveAdviceHelper(root);	
	}
	
	public void giveAdviceHelper(AdviceNode T)
	{
		if(T != null)
		{
			if(isQuestionNode(T))
			{
				System.out.print(T.getQorA());
				String ans = keyboard.nextLine();
				if(ans.equalsIgnoreCase("y"))
					giveAdviceHelper(T.getYes());
				else
					giveAdviceHelper(T.getNo());
			}
			else
			{
				System.out.println(T.getQorA());
			}
			  
		}
	}
	
	// precondition: T is not NULL 
	public boolean tracePath(String movie, Stack <String> pathStack)
	{
		return tracePathHelper(root, movie, pathStack);
	}
	
	public boolean tracePathHelper(AdviceNode T, String movie, Stack<String> pathStack)
	{
		boolean found;
		
		if(isQuestionNode(T))
		{
		    found = tracePathHelper(T.getYes(), movie, pathStack);
		    if(found)
		    {
		        pathStack.push((T.getQorA()) + " Yes");
		        return true;
		    }
		    found = tracePathHelper(T.getNo(), movie, pathStack);
		    if(found)
		    {
		        pathStack.push(T.getQorA()+ " No");
		        return true;
		    }
		    return false;
		  }
		  if(T.getQorA().equals(movie))
		  {
		    pathStack.push(movie);
		    return true;
		  }
		  return false;
	}
	
	
	
   /***********************************/
   /*            toString             */
   /***********************************/ 
   
   // prints tree vertically so that tree structure
   // can be easily identified - uses reverse inorder
   // traversal: right-root-left
   public String toString()
   {
      return toString(root, 0);
   }  
   
   private String toString(AdviceNode tree, int level)
   {
      String str = "";
      if(tree != null)
      {
        str += toString(tree.getNo(), level + 1);
        for(int i = 1; i <= level; i++)
        {
            str = str + "          ";
        }
        str += tree.getQorA().toString() + "\n";
        str += toString(tree.getYes(), level + 1);
      }
      
      return str;
   }  
}