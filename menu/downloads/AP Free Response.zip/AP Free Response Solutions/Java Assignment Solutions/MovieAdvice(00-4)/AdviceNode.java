public class AdviceNode 
{ 
	private String QorA;         // a question or an answer
	private AdviceNode yes;      // yes branch
	private AdviceNode no;       // no branch
	
    // constructor 
	public AdviceNode(String s)
	{
	    QorA = s;
	    yes = null;
	    no = null;	
	}
	
	public String getQorA()
	{
		return QorA;
	}
	
	public AdviceNode getYes()
	{
		return yes;
	}
	
	public AdviceNode getNo()
	{
	    return no;
	}
	
	public void setQorA(String s)
	{
		QorA = s;
	}
	
	public void setYes(AdviceNode node)
	{
		yes = node;
	}
	
	public void setNo(AdviceNode node)
	{
		no = node;
	}

}