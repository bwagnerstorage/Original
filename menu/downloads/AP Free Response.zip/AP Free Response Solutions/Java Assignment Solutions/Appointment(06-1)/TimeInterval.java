public class TimeInterval
{
    // returns true if interval overlaps with this TimeInterval; 
    // otherwise, returns false 
    public boolean overlapsWith(TimeInterval interval) 
    { /* implementation not shown */ }


    // There may be fields, constructors, and methods that are not shown.
 }