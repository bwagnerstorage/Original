public class Appointment 
{ 
    // returns the time interval of this Appointment 
    public TimeInterval getTime() 
    { /* implementation not shown */ } 

    // part(a)
    // returns true if the time interval of this Appointment 
    // overlaps with the time interval of other; 
    // otherwise, returns false public 
    boolean conflictsWith(Appointment other)
    { 
       return getTime().overlapsWith(other.getTime());
    } 

    // There may be fields, constructors, and methods that are not shown. 
} 