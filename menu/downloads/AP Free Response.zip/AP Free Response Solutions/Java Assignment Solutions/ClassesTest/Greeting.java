public class Greeting
{
	private Message message;
	private int reps;
	
	public Greeting()
	{
		message = new Message("Hello There");
		reps = 1;
	}
	
	public Greeting(String m, int r)
	{
		message = new Message(m);
		reps = r;
	}
	
	public void print()
	{
		for(int i=0; i < reps; i++)
		{
			System.out.println(message.getMessage());
		}
	}
}