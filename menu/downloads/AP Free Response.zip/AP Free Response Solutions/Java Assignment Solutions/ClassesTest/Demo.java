public class Demo
{
	public static void main(String[] args)
	{
		Greeting greeting1 = new Greeting("Have a Nice Day", 5);
		greeting1.print();
		
		Greeting greeting2 = new Greeting();
		greeting2.print();
	}
}