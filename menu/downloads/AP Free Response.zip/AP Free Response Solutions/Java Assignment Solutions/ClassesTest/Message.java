public class Message
{
	private String text;
	
	public Message(String t)
	{
		text = t;
	}
	
	public String getMessage()
	{
		return "<<<" + text + ">>>";
	}
}