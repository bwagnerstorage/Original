import java.util.*;

public class Bank
{
    private ArrayList <Account> accounts;
    private Scanner keyboard;
    
    public Bank()
    {
        accounts = new ArrayList<Account> ();
        keyboard = new Scanner(System.in);
        mainMenu();
    }
    
    public void mainMenu()
    {
        int sel=0;
        
        do
        {
            System.out.println();
            System.out.println("=================");
            System.out.println("    Main Menu");
            System.out.println("=================");
            System.out.println("1. Create Account");
            System.out.println("2. Make Deposit");
            System.out.println("3. Make Withdraw");
            System.out.println("4. Check Balance");
            System.out.println("5. Apply Interest to Savings Accounts");
            System.out.println("6. Apply Interest to Credit Accounts");
            System.out.println("7. Show Accounts List");
            System.out.println("8. Quit");
            System.out.print("Selection: ");
            sel = keyboard.nextInt();
            System.out.println();
            
            if(sel == 1)
            {
                CreateAccount();
            }
            if(sel == 2)
            {
                MakeDeposit();
            }
            if(sel == 3)
            {
                MakeWithdraw();
            }
            if(sel == 4)
            {
                CheckBalance();
            }
            if(sel == 5)
            {
                InterestToSavings();
            }
            if(sel == 6)
            {
                InterestToCredit();
            }
            if(sel == 7)
            {
                ShowAccountsList();
            }
        }
        while(sel < 8);
        
    }
    
    public Account getAccount()
    {
        int num = 0;
        
        System.out.println();
        System.out.print("Enter Account Number --> ");
        num = keyboard.nextInt();
        
        for(Account act : accounts)
        {
            if(act.getAccountNumber() == num)
            {
                return act;
            }
        }

        return null;    
        
    }
    
    public void CreateAccount()
    {

        int type = 0;
        
        System.out.println();
        System.out.println("Select Account Type");
        System.out.println("1. Checking");
        System.out.println("2. Savings");
        System.out.println("3. Credit");
        System.out.print("Selection: ");
        type = keyboard.nextInt();
        
        double beginBalance=0;
        System.out.print("Enter beginning balance -->$");
        beginBalance = keyboard.nextDouble();
        
        if(type == 1)
        { 
           accounts.add(new CheckingAccount("Checking" , beginBalance));    
        }
        if(type == 2)
        {
            System.out.print("Enter Interest Rate -->");
            double rate = keyboard.nextDouble();
            
            accounts.add(new SavingsAccount("Savings", beginBalance, rate));
        }
        if(type == 3)
        {
            System.out.print("Enter Interest Rate -->");
            double rate = keyboard.nextDouble();
            System.out.print("Enter Credit Limit --> ");
            double limit = keyboard.nextDouble();
            accounts.add(new CreditAccount("Credit", beginBalance, rate, limit));
        }   
    }
    
    public void MakeDeposit()
    {
        Account account = getAccount();
        if(account != null)
        {
            System.out.print("Enter deposit amount -->$");
            double amount = keyboard.nextDouble();
            account.deposit(amount);
        }
        else
        {           
           System.out.println("Account Not Found!");
        }
    }
    
    public void MakeWithdraw()
    {
        Account account = getAccount();
        if(account != null)
        {
            System.out.print("Enter withdraw amount -->$");
            double amount = keyboard.nextDouble();
            account.withdraw(amount);
        }
        else
        {           
           System.out.println("Account Not Found!");
        }
    }
    
    public void CheckBalance()
    {
        Account account = getAccount();
        if(account != null)
        {
            System.out.println("Balance = $" + account.getBalance());
        }
        else
        {           
           System.out.println("Account Not Found!");
        }
    }
    
    public void InterestToSavings()
    {
        for(Account act : accounts)
        {
            if(act instanceof SavingsAccount)
            {
                ((SavingsAccount)act).applyInterest();
            }
        }
    }
    
    public void InterestToCredit()
    {
        for(Account act : accounts)
        {
            if(act instanceof CreditAccount)
            {
                ((CreditAccount)act).applyInterest();
            }
        }
    }
    
    public void ShowAccountsList()
    {
       for(Account act : accounts)
       {
          System.out.println(act);
          System.out.println();
       }
    }
    
    public static void main(String[] args)
    {
        Bank bank = new Bank();
    }
}