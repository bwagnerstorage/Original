public interface Account
{
    // increases the accounts balance by the value of amount
    void deposit(double amount);
    
    // decreases the accounts balance by the value of amount
    // the transaction will only occur if funds are available
    void withdraw(double amount);
    
    // returns the current account balance
    double getBalance();
    
    // sets the account balance to amount
    void setBalance(double amount);
    
    // returns the account type: "Checking", "Savings", "Credit"
    String getAccountType();
    
    // returns the account's id number
    int getAccountNumber();
    
    // used for displaying the account info
    String toString();
}