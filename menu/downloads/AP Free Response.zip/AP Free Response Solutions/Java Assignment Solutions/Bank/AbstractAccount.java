public class AbstractAccount implements Account
{
    // instance variables
    private double accountBalance;
    private int accountNumber;
    private String accountType;
    
    public static int increment=1; // used to increase account number
    
    public AbstractAccount(String type)
    {
        accountType = type;
        accountBalance = 0;
        accountNumber = increment;
        increment++;
    }
    
    public AbstractAccount(String type, double beginBalance)
    {
        accountType = type;
        accountBalance += beginBalance;
        accountNumber = increment;
        increment++;
    }
    
    public void deposit(double amount)
    {
        accountBalance += amount;
    }
    
    public void withdraw(double amount)
    {
        if(amount <= accountBalance)
        {
            accountBalance -= amount;
        }
    }
    
    public double getBalance()
    {
        return accountBalance;
    }
    
    public void setBalance(double amount)
    {
        accountBalance = amount;
    }
    
    public String getAccountType()
    {
        return accountType;
    }
    
    public int getAccountNumber()
    {
        return accountNumber;
    }
    
    public String toString()
    {
        return "Account Type:     " + accountType + "\n" +
               "Account Number:   " + accountNumber + "\n" +
               "Account Balance: $" + accountBalance + "\n";
    }
}