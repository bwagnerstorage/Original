public class SavingsAccount extends AbstractAccount
{
	private double interestRate;
	
	public SavingsAccount(String type, double rate)
	{
		super(type);
		interestRate = rate;
	}
	
	public SavingsAccount(String type, double beginBalance, double rate)
	{
		super(type, beginBalance);
		interestRate = rate;
	}
	
	public void applyInterest()
	{
		setBalance(getBalance() + getBalance() * interestRate);
	}
	
	public void setRate(double rate)
	{
		interestRate = rate;
	}
	
	public double getRate()
	{
		return interestRate;
	}
	
	public String toString()
	{
		return super.toString() +
		       "Interest Rate:    " + interestRate + "\n";
	}
}