public class CreditAccount extends SavingsAccount
{
	private double creditLimit;
	
	public CreditAccount(String type, double rate, double limit)
	{
		super(type, rate);
		creditLimit = limit;
	}
	
	public CreditAccount(String type, double beginBalance, double rate, double limit)
	{
		super(type, beginBalance, rate);
		creditLimit = limit;
	}
	
	public void withdraw(double amount)
	{
		if(amount <= creditLimit - getBalance())
		{
			withdraw(amount);
		}
	}
	
	public String toString()
	{
		return super.toString() + 
		       "Credit Limit:    $" + creditLimit + "\n";
	}
}