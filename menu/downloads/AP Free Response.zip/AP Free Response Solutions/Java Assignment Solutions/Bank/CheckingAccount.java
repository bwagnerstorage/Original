public class CheckingAccount extends AbstractAccount
{
	public CheckingAccount(String type)
	{
	   super(type);
	}
	
	public CheckingAccount(String type, double beginBalance)
	{
	   super(type, beginBalance);	
	}
}