public class DoubleNode
{  
   // Instance Variables
   private Object value;
   private DoubleNode prev;
   private DoubleNode next;

   // Constructor
   public DoubleNode(Object initValue, DoubleNode initPrev, DoubleNode initNext)
   { 
      value = initValue; 
      prev = initPrev; 
      next = initNext;
   }

   // Accessor Methods
   public Object getValue() 
   { 
      return value; 
   }
  
   public DoubleNode getPrev() 
   { 
      return prev; 
   }

   public DoubleNode getNext() 
   { 
      return next; 
   }

   // Mutator Methods
   public void setValue(Object theNewValue)
   { 
      value = theNewValue; 
   }
  
   public void setPrev(DoubleNode theNewPrev)
   { 
      prev = theNewPrev;
   }

   public void setNext(DoubleNode theNewNext)
   { 
      next = theNewNext;
   }
   
   public String toString()
   {
      return value.toString();
   }
}
