public class DoubleListADT implements DoubleList
{
    private DoubleNode head;  // start of list
    private DoubleNode last;  // end of list
    private DoubleNode cur;   // current position in list
    
    public DoubleListADT()
    {
        head = new DoubleNode("", null, null);
        last = new DoubleNode("", null, null);
        head.setNext(last);
        last.setPrev(head);
        cur = null;
    }
    
	public void addFirst(Object item)
	{
		DoubleNode temp = new DoubleNode(item, head, head.getNext());
		head.getNext().setPrev(temp);
		head.setNext(temp);
		cur = temp;
	}
	
	public void addLast(Object item)
	{
   		DoubleNode temp = new DoubleNode(item, last.getPrev(), last);
   		last.getPrev().setNext(temp);
   		last.setPrev(temp);
   		cur = temp;
	}
	
	public boolean hasNext()
	{
	   if(cur != last)
	      return true;
	   else
	      return false;
	}
	
	public boolean hasPrev()
	{
	   if(cur != head)
	     return true;
	   else
	     return false;
	}
	
	public DoubleNode next()
	{
	   DoubleNode temp = cur;
	   cur = cur.getNext();
	   return temp;
	}
	
	public DoubleNode prev()
	{
	   DoubleNode temp = cur;
	   cur = cur.getPrev();
	   return temp;
	}
	
	public DoubleNode getFirst()
	{
		cur = head.getNext();
		return cur;
	}
	
	public DoubleNode getLast()
	{
		cur = last.getPrev();
		return cur;
	}
	
	public DoubleNode removeFirst()
	{
	   DoubleNode temp;
	   temp = head.getNext();
	   cur = head.getNext().getNext();
	   head.setNext(head.getNext().getNext());
	   if(head.getNext().getNext() != null)
	       head.getNext().getNext().setPrev(head);
	   else
	   	   head.setNext(last);
	   return temp;
	}
	
	public DoubleNode removeLast()
	{
		DoubleNode temp;
		temp = last.getPrev();
		cur = last.getPrev().getPrev();
		last.getPrev().getPrev().setNext(last);
		if(last.getPrev().getPrev() != null)
		   last.setPrev(last.getPrev().getPrev());
		else
		   last.setPrev(head);
		return temp;
	}
}