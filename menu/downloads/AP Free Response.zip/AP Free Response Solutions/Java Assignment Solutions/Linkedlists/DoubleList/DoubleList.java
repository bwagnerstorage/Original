public interface DoubleList
{
    public void addFirst(Object item);
    
    public void addLast(Object item);
    
    public DoubleNode getFirst();
    
    public DoubleNode getLast();
    
    public DoubleNode next();
    
    public DoubleNode prev();
    
    public boolean hasNext();
    
    public boolean hasPrev();
    
    public DoubleNode removeFirst();
    
    public DoubleNode removeLast();
}