public class DoubleListTester
{
    private DoubleListADT list;
    
    public DoubleListTester()
    {
        list = new DoubleListADT();
        
        System.out.println("Test: addLast, hasNext, next");
        list.addLast("a");
        list.addLast("b");
        list.addLast("c");
        printForward();
        System.out.println("Test: addFirst");
        list.addFirst("d");
        list.addFirst("e");
        printForward(); 
        System.out.println("Test: getFirst");
        System.out.println(list.getFirst());
        System.out.println("Test: getLast");
        System.out.println(list.getLast());
        System.out.println("Test: hasPrev, prev");
        printBackward();
        System.out.println();
        System.out.println("List before calls to remove methods");
        printForward();
        System.out.println();
        System.out.println("Test: removeFirst");
        list.removeFirst();
        printForward();
        System.out.println("Test: removeLast");
        list.removeLast();
        printForward();
        System.out.println("Test: consecutive removeFirst's");
        list.getFirst();
        while(list.hasNext())
        {
            System.out.print(list.removeFirst() + " ");
        }
        System.out.println();
        printForward();
        System.out.println();
    }
    
    public void printForward()
    {
        list.getFirst();
        if(list.hasNext() == false)
        {
            System.out.println("List is empty!");
        }
        else
        {
            while(list.hasNext())
            {
                DoubleNode node = list.next();
                System.out.print(node + " ");
            }
            System.out.println();   
        }

    }
    
    public void printBackward()
    {
        list.getLast();
        if(list.hasPrev() == false)
        {
            System.out.println("List is empty!");
        }
        else
        {
            while(list.hasPrev())
            {
                DoubleNode node = list.prev();
                System.out.print(node + " ");
            }
            System.out.println();
        }   
    }
    public static void main(String[] args)
    {
        DoubleListTester app = new DoubleListTester();
    }
}