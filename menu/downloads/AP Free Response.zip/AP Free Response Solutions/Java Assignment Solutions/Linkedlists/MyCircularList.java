public class MyCircularList implements CircularList
{
	private ListNode last;
	private ListNode cur;
	
	public MyCircularList(int numSoldiers)
	{
		for(int i=1; i <= numSoldiers; i++)
		{
			insert(i);
		}
	}
	
	// insert an element into the list
	public void insert(int item)
	{
		if(last == null)
		{
			last = new ListNode(item, null);
       	    last.setNext(last);
       	    cur = last;
		}
		else
		{
			ListNode newNode = new ListNode(item, cur);
			last.setNext(newNode);
			cur = newNode;
		}
	}
	
	// find the node with the given key
	public ListNode find(int key)
	{
       ListNode ptr = last.getNext();
       while(ptr != last)
       {
       	  if((Integer)ptr.getValue() == key)
       	    return ptr;
       	  ptr = ptr.getNext();
       }
       return last;
	}
	
	// precondition:  n > 1
	// postcondition: deletes the nth link starting from the node start
	//      prints the value of the node deleted
	//      returns the node that follows the deleted node
	public ListNode delete(ListNode start, int n)
	{
	   ListNode ptr = start;
	   ListNode prev = ptr;
	   int i=1;
	   for(i=1; i < n; i++)
	   {
	   	  prev = ptr;
	   	  ptr = ptr.getNext();
	   }
	   if(i != 1)
	      System.out.println("Remove soldier at position  " + ptr.getValue());
	   if(ptr == last)
	   {
	   	  prev.setNext(last.getNext());
	   	  last = prev;
	   }
	   else
	      prev.setNext(ptr.getNext());
	   return ptr.getNext();
	}
	
	// return a string representation of a Circular List
	public String toString()
	{
		String str = "Circular List - "; 
    	ListNode ptr = last.getNext();
		str += ptr.getValue()+ " ";
	    ptr = ptr.getNext();
    	while(ptr != last.getNext())
        {
	        str += ptr.getValue()+ " ";
	        ptr = ptr.getNext();	
    	}
    		
    	return str;
	}
}