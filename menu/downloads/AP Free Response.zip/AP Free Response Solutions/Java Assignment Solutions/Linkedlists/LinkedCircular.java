import java.util.*;

public class LinkedCircular
{
    private ListNode last;
    private ListNode cur;
    private ListNode prev; 
    private ListNode temp; 
    
    public void addNode(String s)
    {
       if(last == null)
       {
       	  last = new ListNode(s, null);
       	  last.setNext(last);
       	  cur = last;
       	  temp = last;
       	  System.out.println(last.getValue());
       	  System.out.println(last.getNext().getValue());
       }
       else
       {
       	  ListNode newNode = new ListNode(s,cur);
       	  last.setNext(newNode);
       	  cur = newNode;
       }
    }
    
    public void deleteNode()
    {
    	
    }
    public void viewCurrent()
    {
    	System.out.println("Current Node  - " + temp.getValue());
    }
    
    public void advance()
    {
    	temp = temp.getNext();
    }  
    
    public void printList()
    {
    	System.out.print("Circular List - ");
    	ListNode ptr = last.getNext();
    	System.out.print(ptr.getValue()+ " ");
    	ptr = ptr.getNext();
    	while(ptr != last.getNext())
        {
	        System.out.print(ptr.getValue()+ " ");
	        ptr = ptr.getNext();	
    	}
    	System.out.println();
    	System.out.println();

    }
    
    public static void main(String[] args)
    {
    	LinkedCircular app = new LinkedCircular();
    	Scanner keyboard = new Scanner(System.in);
    	int n = 97;
    	int ans = 0;
    	
    	for(;;)
    	{
    		System.out.print("1) Add 2) Delete 3) Advance  >>");
    		ans = keyboard.nextInt();
    		System.out.println();
    		
    		if(ans == 1)
    		{
    			char c = (char)n;
    			n++;
    			if(n > 97 + 26)
    			   n = 97;
    			char[] ch = {c};
    			app.addNode(new String(ch));
    		}
    		if(ans == 2)
    		{
    			app.deleteNode();
    		}
    		if(ans == 3)
    		{
    			app.advance();
    		}
    		app.viewCurrent();
    		app.printList();
    		
    	}
    }
 }