public interface CircularList
{
   // postcondition: inserts an item into the list maitaining the lists
   //     circular orientation
   public void insert(int item);

   // precondition:  key is a valid item within the list
   // postcondition: finds the node with the given key
   public ListNode find(int key);

   // precondition:  n > 1
   // postcondition: deletes the nth link starting from the node start;
   // returns the node that follows the deleted node
   public ListNode delete(ListNode start, int n);
}