import java.util.*;

public class Josephus
{
	private CircularList list;
	private Scanner keyboard;
	
	public Josephus()
	{
	   keyboard = new Scanner(System.in);
	   
	   System.out.print("Enter number of soldiers -->");
	   int 	numSoldiers = keyboard.nextInt();
	   
	   System.out.print("Enter elimination number (n) -->");
	   int 	n = keyboard.nextInt();
	   
	   System.out.print("Enter number of soldier who will start the counting-->");
	   int 	startSoldier = keyboard.nextInt();
	   System.out.println();
	   
	   list = new MyCircularList(numSoldiers);
	   System.out.println(list);
	   
	   ListNode soldier = list.find(startSoldier);
	   for(int i=0; i < numSoldiers; i++)
	   {
	   	  soldier = list.delete(soldier, n);
	   	  if(i == (numSoldiers - 1))
	   	  {
	   	  	System.out.println();
	   	  	System.out.println("Soldier " + soldier.getValue() + " goes for help!");
	   	  	System.out.println();
	   	  }
	   	  	 
	   	  else
	   	     System.out.println(list);
	   }
	   
	}
	
	public static void main(String[] args)
	{
		Josephus app = new Josephus();
	}
}