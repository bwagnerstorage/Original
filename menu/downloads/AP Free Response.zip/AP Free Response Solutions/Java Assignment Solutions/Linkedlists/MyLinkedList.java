public class MyLinkedList
{
    private ListNode head;
    private ListNode cur;
    private ListNode prev;
    
    public void insertFirst(String data)
    {
        ListNode newNode = new ListNode(data, null);
        if(head == null)
        {
            head = newNode;
        }
        else
        {
            newNode.setNext(head);
            head = newNode;
        }
        
    }
    
    public void insertLast(String data)
    {
        ListNode newNode = new ListNode(data, null);
        cur = head;
        while(cur != null)
        {
            prev = cur;
            cur = cur.getNext();
        }
        prev.setNext(newNode);
        
    }
    
    public void deleteFirst()
    {
        head = head.getNext();
    }
    
    public void deleteLast()
    {
        cur = head;
        while(cur.getNext() != null)
        {
            prev = cur;
            cur = cur.getNext();
        }
        prev.setNext(null);
    }
    
    public void deleteInside(String key)
    {
       cur = head;
       while(cur != null && !cur.getValue().equals(key))
       {
          prev = cur;
          cur = cur.getNext();
       }    
       if(cur == head && cur.getValue().equals(key))
       {
          System.out.println("test");
          head = head.getNext();
       }
       else if(cur != null)
          prev.setNext(cur.getNext());
    }
    
    public boolean search(String key)
    {
       cur = head;
       while(cur != null)
       {
          if(cur.getValue().equals(key))
             return true;
          cur = cur.getNext();
       }    
       return false;
    }
	
	public void printList()
	{
		cur = head;
		while(cur != null)
		{
			System.out.print(cur.getValue()+ " ");
			cur = cur.getNext();
		}
		System.out.println();
	}
	
	public static void main(String[] args)
	{
		MyLinkedList app = new MyLinkedList();
		app.insertFirst("a");
		app.printList();
		app.insertFirst("b");
		app.printList();
		app.insertFirst("c");
		app.printList();
		app.insertLast("d");
		app.printList();
		app.insertLast("e");
		app.printList();
		//app.deleteFirst();
		//app.printList();
	    //app.deleteFirst();
		//app.printList();
		app.deleteInside("a");
		app.printList();	    
		app.deleteInside("e");
		app.printList();
		app.deleteInside("b");
		app.printList();
		app.deleteInside("d");
		app.printList();
		app.deleteInside("c");
		app.printList();
		System.out.println("Test2");
		app.printList();
	/*	if(app.search("f"))
		{
			System.out.println("f was found");
		}*/
	}
}