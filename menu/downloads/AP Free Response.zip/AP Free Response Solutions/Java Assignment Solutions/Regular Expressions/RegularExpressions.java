import java.util.*;

public class RegularExpressions
{
	public static void main(String[] args)
	{
		// Regular Expressions
		
		// String matches method
		String s1 = "123-12-1234";
		String s2 = "343-45-9999";
		String regX1 = "[0-9]{3}\\-[0-9]{2}\\-[0-9]{4}";
		boolean ans = s1.matches(regX1);
		System.out.println("s1 = " + ans);
		ans = s2.matches(regX1);
		System.out.println("s2 = " + ans);
		System.out.println();
		
		// String split method
		String s3 = "To ere is human, to forgive, divine.";
		String regX2 = "\\s";
		String[] array1 = s3.split(regX2);
		for(String s : array1)
		  System.out.print(s + " ");
		System.out.println();
		System.out.println("Array length = " + array1.length);
		System.out.println();
		
		// String split method
		String s4 = "ham+can--putt*=cut";
		String regX3 = "\\W";
		String[] array2 = s4.split(regX3);
		for(String s : array2)
		  System.out.print(s + " ");
		System.out.println();
		System.out.println("Array length = " + array2.length);
		System.out.println();
		
		System.out.println();
	}
}