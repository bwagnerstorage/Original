// APSubset ListNode class

public class ListNode<E>
{  
   // Instance Variables
   private E value;
   private ListNode next;
  
   // Constructor
   public ListNode(E initValue, ListNode initNext)
   { 
      value = initValue; 
      next = initNext; 
   }

   // Accessor Methods
   public E getValue() 
   { 
      return value; 
   }
  
   public ListNode getNext() 
   { 
      return next; 
   }

   // Mutator Methods
   public void setValue(E theNewValue)
   { 
      value = theNewValue; 
   }
  
   public void setNext(ListNode theNewNext)
   { 
      next = theNewNext;
   }
}