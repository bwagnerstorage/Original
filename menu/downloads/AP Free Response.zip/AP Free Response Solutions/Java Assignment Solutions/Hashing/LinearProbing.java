import java.util.*;

public class LinearProbing
{
	private Scanner keyboard;
	int[] table;
	int count = 0;
	
	public LinearProbing()
	{
		keyboard = new Scanner(System.in);
		table = new int[12];
		int num = 0;
		int index = 0;
		int count = 0;
		
		while(count < table.length)
		{
			num = (int)(Math.random() * 89 + 10);
			index = hash(num);
			if(table[index] == 0)
			{
				table[index] = num;
				System.out.println("Insert " + num + " at index " + index);
			}
			else
			{
				System.out.print("Collision at index "+index);
				while(table[index] > 0)
				{
				   index = (index + 1) % table.length;
				}
				table[index] = num;
				System.out.println(" - insert " + num + " at index " + index);
			}
			printArray();
			count++;
			keyboard.nextLine();  // pause
			
		}
		
		while(true)
		{
			System.out.print("Enter search key -->");
			int key = keyboard.nextInt();
			index = hash(key);
			if(table[index] == key)
			{
				System.out.println(key + " found at index " + index);
			}
			else
			{
				count = 0;
				while(table[index] != key && count < table.length)
				{
				   index = (index + 1) % table.length;
				   count++;
				}
				if(table[index] == key)
				  System.out.println(key + " found at index " + index);
				else
				  System.out.println(key + " not in list");
							
			}
		}
	}
	
	public int hash(int data)
	{
	   return data % table.length;
	}
	
	public void printArray()
	{
		for(int i=0; i < table.length; i++)
		{
			if(i < 10)
			  System.out.println("["+i+"] =  " + table[i]);
			else
			  System.out.println("["+i+"] = " + table[i]);
		}
		System.out.println();
	}
	
	public static void main(String[] args)
	{
	   LinearProbing app = new LinearProbing();	
	}
}