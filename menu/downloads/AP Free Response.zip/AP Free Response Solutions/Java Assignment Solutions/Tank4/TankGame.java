public class TankGame
{
	public static void main(String[] args)
	{
		// configure display mode (FULLSCREEN or WINDOW)
		DisplayConfiguration dc = new DisplayConfiguration(DisplayConfiguration.WINDOW);
		Game tankGame = new Game(dc);
		
		// Create and add screen to game
		MainScreen mainScreen = new MainScreen();
		tankGame.addScreen(mainScreen);
		
		tankGame.start();
	}
}