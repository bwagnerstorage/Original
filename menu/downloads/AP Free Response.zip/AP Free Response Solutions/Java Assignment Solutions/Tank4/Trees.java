import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import javax.swing.*;

public class Trees
{
	// constants
	public final int NUM_TREES = 30;
	
	// instance variables
	private Sprite[] trees;
	private int size;
	
	// constructor
	public Trees()
	{
		trees = new Sprite[NUM_TREES];
		size = 0; 
	}
	
	public void add(Sprite s)
	{
	   trees[size] = s;
	   size++;
	}
	
	public void render(Graphics g)
	{
		for(int i=0; i < size; i++)
		{
			if(trees[i] != null)
			{
				trees[i].render(g);
			}
		}
	}
	
	public boolean willCollide(Point p, Sprite sprite)
	{
		for(int i=0; i < size; i++)
		{
			if(sprite.willCollide(p, trees[i]) == true)
			{
			    return true;	
			}
		}
		return false;
	}
	
   public boolean collision(Sprite sprite)
   {
   	  for(int i=0; i < trees.length; i++)
   	  {
   	  	 if(sprite.collision(trees[i])==true)
   	  	   return true;
   	  }
   	  return false; 
   }
}