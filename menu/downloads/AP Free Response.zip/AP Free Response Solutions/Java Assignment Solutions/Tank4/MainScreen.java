import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import javax.swing.*;

public class MainScreen extends Screen
{
	// instance variables
	private Tank tank1;
	private Tank tank2;
	private Trees trees;
	private Sprite wall1;
	private Sprite wall2;

	
	// constructor
	public MainScreen()
	{
		super("background.gif");  // load background image
		
		// tank1
		tank1 = new Tank("tanksheet1.gif", 700, 278, 2, 2, 8, 32, 32);
		tank1.setKeys(KeyEvent.VK_LEFT, KeyEvent.VK_RIGHT, KeyEvent.VK_UP, KeyEvent.VK_DOWN, KeyEvent.VK_CONTROL);
        tank1.turnWest();
        tank1.setFrame(6);
		
		// tank2
		tank2 = new Tank("tanksheet2.gif", 100, 278, 2, 2, 8, 32, 32);
		tank2.setKeys(KeyEvent.VK_A, KeyEvent.VK_D, KeyEvent.VK_W, KeyEvent.VK_S, KeyEvent.VK_SPACE);
		setCursor(true);
		tank2.turnEast();
        tank2.setFrame(2);
        
        // trees
        trees = new Trees();
        trees.add(new Sprite("tree1.gif", 70, 70));
        trees.add(new Sprite("tree1.gif", 120, 425));
        trees.add(new Sprite("tree1.gif", 500, 200));
        trees.add(new Sprite("tree1.gif", 640, 430));
        trees.add(new Sprite("tree1.gif", 460, 375));
        trees.add(new Sprite("tree1.gif", 300, 100));
        
        // small trees
        trees.add(new Sprite("tree2.gif", 710, 50));
        trees.add(new Sprite("tree2.gif", 680, 70));
        trees.add(new Sprite("tree2.gif", 682, 35));
        trees.add(new Sprite("tree2.gif", 150, 150));
        trees.add(new Sprite("tree2.gif", 300, 340));
        trees.add(new Sprite("tree2.gif", 680, 350));
        trees.add(new Sprite("tree2.gif", 20, 300));
        trees.add(new Sprite("tree2.gif", 480, 60));
        
        // walls
        wall1 = new Sprite("wall.gif", 400,50);
        wall2 = new Sprite("wall.gif", 400,326);



	}
	
	public void render(Graphics g)
	{
	   super.render(g);  // draw background image
	   
	   // tanks
	   tank1.render(g);
	   tank2.render(g);
	   
	   // trees
	   trees.render(g);

       // walls
	   wall1.render(g);
	   wall2.render(g);
	}
	
	public void process()
	{
	   tank1.process(tank2, trees, wall1, wall2);
	   tank2.process(tank1, trees, wall1, wall2);
	}
}