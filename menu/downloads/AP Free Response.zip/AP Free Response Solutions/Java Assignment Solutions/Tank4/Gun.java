import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import javax.swing.*;

public class Gun
{
	private Sprite[] bullets;
	private boolean delay;
	private long timeDelay;
	private int shootSound;
	
	public Gun()
	{
	   bullets = new Sprite[12];
	   delay = false;
	   timeDelay = 0;
	   shootSound = Game.addSound("shoot.au");
	}
	
	public void render(Graphics g)
	{
		for(int i=0; i < bullets.length; i++)
        {  
           if(bullets[i] != null)
             bullets[i].render(g);
        }
	}
	
	public void process(Trees trees)
	{
		for(int i=0; i < bullets.length; i++)
        {  
           if(bullets[i] != null)
           {
           	  if(trees.collision(bullets[i]) == true)
           	  {
           	  	 bullets[i] = null;
           	  }
           	  else
           	  {
                  bullets[i].move();
              }
           }
        }
	}
	
	public void fire(Tank tank)
	{
		if(delay == true)
   	    {
   	       if(System.currentTimeMillis()  > timeDelay)
   	       {
   	          delay = false;
   	       }
   	    }
   	    if(delay == false)
   	    {
   	    	Game.playSound(shootSound);
   	    	delay = true;
   	    	timeDelay = System.currentTimeMillis() + 500;
	   	    for(int i=0; i < bullets.length; i++)
	        {   
	            // destory bullet if it goes out of viewing range
	            if(bullets[i] != null)
	            {
	                if(Game.outOfBounds(bullets[i].getX(), bullets[i].getY()))
	                  bullets[i] = null;  // remove Bullet object
	            }
	            // create new bullet
	            if(bullets[i] == null)
	            {
	               int direction = tank.getDirection();
	               Point p = tank.getQuadrant(direction);
	               bullets[i] = new Sprite("bullet.gif", (int)p.getX(), (int)p.getY(), 4, 4);
	               bullets[i].setDirection(direction);
	               return;  // exit fire method if new bullet is created
	            }
	        }
	    }
	 }
	 
	 public Sprite[] getBullets()
	 {
	 	return bullets;
	 }	 
	 
	 public void killBullets()
	 {
	    for(int i=0; i < bullets.length; i++)
	    {   
	       if(bullets[i] != null)
	       {
	       	  bullets[i] = null;
	       }
	    }
	 }
}