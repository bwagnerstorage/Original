import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

public class Tank extends AnimatedSprite
{
	// instance variables
	private int leftKey;
	private int rightKey;
	private int upKey;
	private int downKey;
	private int fireKey;
	
	private Gun gun;
	private AnimatedSprite explosion;  // added explosion
    private int explosionSound;        // added explosion sound
	
	// constructor
	public Tank(String filename, int x, int y, int vx, int vy, int nf, int fw, int fh)
	{
	   super(filename, x, y, vx, vy, nf, fw, fh); 
	   gun = new Gun();  
	   // create explosion sound
	   
	   
	}
	
	public void render(Graphics g)
	{
	   super.render(g);	  // draw tank
       gun.render(g);
       
       // render explosion



	}
	
	public void process(Tank otherTank, Trees trees, Sprite wall1, Sprite wall2)
	{
	   if(Game.keyTest(upKey)==true && Game.keyTest(rightKey))  // northeast
	   {
	   	  if(Game.outOfBounds(lookNorthEast())==false && trees.willCollide(lookNorthEast(),this) == false
	   	     && willCollide(lookNorthEast(), wall1) == false && willCollide(lookNorthEast(), wall2) == false)
	   	  {
	   	     setFrame(1);
	   	     moveNorthEast();
	   	  }
	   }
	   else if(Game.keyTest(upKey) == true && Game.keyTest(leftKey))  // northwest
	   {
	   	  if(Game.outOfBounds(lookNorthWest())==false && trees.willCollide(lookNorthWest(),this) == false
	   	  && willCollide(lookNorthWest(), wall1) == false && willCollide(lookNorthWest(), wall2) == false)
	   	  {
	   	     setFrame(7);
	   	     moveNorthWest();
	   	  }
	   }
	   else if(Game.keyTest(downKey) == true && Game.keyTest(rightKey))  // southeast
	   {
	   	  if(Game.outOfBounds(lookSouthEast())==false && trees.willCollide(lookSouthEast(),this) == false
	   	  && willCollide(lookSouthEast(), wall1) == false && willCollide(lookSouthEast(), wall2) == false)
	   	  {
	   	  	 setFrame(3);
	   	     moveSouthEast();
	   	  }

	   }
	   else if(Game.keyTest(downKey) == true && Game.keyTest(leftKey))  // southwest
	   {
	   	  if(Game.outOfBounds(lookSouthWest())==false && trees.willCollide(lookSouthWest(),this) == false
	   	  && willCollide(lookSouthWest(), wall1) == false && willCollide(lookSouthWest(), wall2) == false)
	   	  {
	   	     setFrame(5);
	   	     moveSouthWest();
	   	  }
	   }  
	   else if(Game.keyTest(upKey)==true)  // north
	   {
	   	  if(Game.outOfBounds(lookNorth())==false && trees.willCollide(lookNorth(),this) == false
	   	  && willCollide(lookNorth(), wall1) == false && willCollide(lookNorth(), wall2) == false)
	   	  {
	   	  	setFrame(0);
	   	    moveNorth();
	   	  }  
	   }
	   else if(Game.keyTest(rightKey))     // east
	   {
	   	  if(Game.outOfBounds(lookEast())==false && trees.willCollide(lookEast(),this) == false
	   	  && willCollide(lookEast(), wall1) == false && willCollide(lookEast(), wall2) == false)
	   	  {
	   	     setFrame(2);
	   	     moveEast();
	   	  }  	  
	   }
	   else if(Game.keyTest(downKey))      // south
	   {
	   	  if(Game.outOfBounds(lookSouth())==false && trees.willCollide(lookSouth(),this) == false
	   	  && willCollide(lookSouth(), wall1) == false && willCollide(lookSouth(), wall2) == false)
	   	  {
	   	     setFrame(4);
	   	     moveSouth();
	   	  }
	   }
	   else if(Game.keyTest(leftKey))      // west
	   {
	   	  if(Game.outOfBounds(lookWest())==false && trees.willCollide(lookWest(),this) == false
	   	  && willCollide(lookWest(), wall1) == false && willCollide(lookWest(), wall2) == false)
	   	  {
	   	  	 setFrame(6);
	   	     moveWest();
	   	  }
	   }
	    
	   // Shoot
	   if(Game.keyboard.keyState[fireKey] == true)  // fire gun
       { 
           if(this.amIAlive() == true)
           {
              gun.fire(this);
           }
       }
	   
	   gun.process(trees);
	   
	   collision(otherTank);	   
    } 
    
    public void setKeys(int l, int r, int u, int d, int f)
	{
	   leftKey = l;
	   rightKey = r;
	   upKey = u;
	   downKey = d;
	   fireKey = f;
	}
	
	public void collision(Tank otherTank)
	{


	}
		
}