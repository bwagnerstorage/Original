
public class Stack2050 {

    public Stack2050() {
    }

    public void push(int val) {
    }

    public int pop() {
    }

    public boolean isEmpty() {
    }

}
