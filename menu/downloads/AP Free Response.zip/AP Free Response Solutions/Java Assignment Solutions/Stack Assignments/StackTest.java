
public class StackTest {

    public static void main(String argv[]) {
        Stack2050 myStack = new Stack2050();
        int val = 624876987;

        do {
            myStack.push(val % 10);
            val = val / 10;
        } while (val > 0);

        while (!myStack.isEmpty()) {
            System.out.print(myStack.pop());
        }

        System.out.println();
    }

}
