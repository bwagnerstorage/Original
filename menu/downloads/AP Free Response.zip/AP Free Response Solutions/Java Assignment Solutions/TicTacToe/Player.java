public class Player
{
	private String name;
	String id;
	
	public Player(String n, String i)
	{
		name = n;
		id = i;
	}
	
	public String getName()
	{
		return name;
	}
	
	public String getID()
	{
		return id;
	}
	
	public boolean equals(Object o)
	{
		if(id.equals(((Player)o).getID()))
		   return true;
		else
		   return false;
	}
	
}