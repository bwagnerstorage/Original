import java.util.*;

public class Game
{
	private Scanner keyboard;
	private Player playerX;
	private Player playerO;
	private Player currentPlayer;
	
	public Game()
	{
		String playAgain = "n";
		keyboard = new Scanner(System.in);
		inputPlayers();
		
		do
		{
		   Board board = new Board();
		   playGame(board);
		   
		   System.out.println();
		   System.out.print("Play again[y/n]?");
		   playAgain = keyboard.nextLine();
		}
		while(playAgain.equalsIgnoreCase("y"));
	}
	
	public void inputPlayers()
	{
	   String name="";
	   
	   System.out.print("Enter player X name -->");
	   name = keyboard.nextLine();
	   playerX = new Player(name, "X");
	  
	   System.out.print("Enter player O name -->");
	   name = keyboard.nextLine();
	   playerO = new Player(name, "O");
	}
	
	public void playGame(Board board)
	{
		currentPlayer = playerX;
		String loc;
		do
		{
			board.display();
			do
			{
				System.out.println(currentPlayer.getName() + "'s turn.");
				System.out.print("Enter location -->");
				loc = keyboard.nextLine();	
			}
			while(board.add(loc, currentPlayer.getID()) == false);
			
			if(currentPlayer.equals(playerX))
			   currentPlayer = playerO;
			else
			   currentPlayer = playerX;

		}
		while(!board.isWinner() && !board.isDraw());
		
		// flip currentPlayer so winner can be announced correctly
		if(currentPlayer.equals(playerX))
			currentPlayer = playerO;
		else
			currentPlayer = playerX;
			
	    board.display();
		
		if(board.isWinner())
		{
			System.out.println();
			System.out.println(currentPlayer.getName() + " is the winner!");
			System.out.println();
		}
		if(board.isDraw())
		{
			System.out.println();
			System.out.println("It's a draw!");
			System.out.println();
		}
	}
	
	public static void main(String[] args)
	{
       Game game = new Game();
	}
}