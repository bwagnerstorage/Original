public class Board
{
	private String[][] board;
	private int moves;
	
	public Board()
	{
		board = new String[3][3];
		int n=1;
		for(int r=0; r<3; r++)
		{
			for(int c=0; c<3; c++)
			{
				board[r][c] = (new Integer(n)).toString();
				n++; 
			}
		}
		moves = 0;
	}
	
	public boolean add(String loc, String id)
	{
		int r=0, c=0;
		
		
		if(loc.equals("1"))
		{
			r=0;
			c=0;
		}
		else if(loc.equals("2"))
		{
			r=0;
			c=1;
		}
		else if(loc.equals("3"))
		{
			r=0;
			c=2;
		}
		else if(loc.equals("4"))
		{
			r=1;
			c=0;
		}
		else if(loc.equals("5"))
		{
			r=1;
			c=1;
		}
		else if(loc.equals("6"))
		{
			r=1;
			c=2;
		}
		else if(loc.equals("7"))
		{
			r=2;
			c=0;
		}
		else if(loc.equals("8"))
		{
			r=2;
			c=1;
		}
		else if(loc.equals("9"))
		{
			r=2;
			c=2;
		}
		
		if(board[r][c].equals("X") || board[r][c].equals("O"))
		   return false;
		   
		board[r][c] = id;
		moves++;
		return true;
	}
	
	public boolean isWinner()
	{
		if(board[0][0].equals("X") && board[0][1].equals("X") && board[0][2].equals("X") ||
	       board[0][0].equals("O") && board[0][1].equals("O") && board[0][2].equals("O"))
	         return true;
	    if(board[1][0].equals("X") && board[1][1].equals("X") && board[1][2].equals("X") ||
	       board[1][0].equals("O") && board[1][1].equals("O") && board[1][2].equals("O"))
	         return true;
	    if(board[2][0].equals("X") && board[2][1].equals("X") && board[2][2].equals("X") ||
	       board[2][0].equals("O") && board[2][1].equals("O") && board[2][2].equals("O"))
	         return true;
	         
	    if(board[0][0].equals("X") && board[1][0].equals("X") && board[2][0].equals("X") ||
	       board[0][0].equals("O") && board[1][0].equals("O") && board[2][0].equals("O"))
	         return true;
	    if(board[0][1].equals("X") && board[1][1].equals("X") && board[2][1].equals("X") ||
	       board[0][1].equals("O") && board[1][1].equals("O") && board[2][1].equals("O"))
	         return true;
	    if(board[0][2].equals("X") && board[1][2].equals("X") && board[2][2].equals("X") ||
	       board[0][2].equals("O") && board[1][2].equals("O") && board[2][2].equals("O"))
	         return true;
	         
	    if(board[0][0].equals("X") && board[1][1].equals("X") && board[2][2].equals("X") ||
	       board[0][0].equals("O") && board[1][1].equals("O") && board[2][2].equals("O"))
	         return true;
	    if(board[2][0].equals("X") && board[1][1].equals("X") && board[0][2].equals("X") ||
	       board[2][0].equals("O") && board[1][1].equals("O") && board[0][2].equals("O"))
	         return true;
	         
	    return false;  // no winner
	}
	
	public boolean isDraw()
	{
		if(!isWinner() && moves == 9)
		  return true;
		else
		  return false;
	}
	
	public void display()
	{
	   System.out.println();
	   System.out.println(board[0][0] + "|" + board[0][1] + "|" + board[0][2]);
	   System.out.println("-|-|-");
	   System.out.println(board[1][0] + "|" + board[1][1] + "|" + board[1][2]);
	   System.out.println("-|-|-");
	   System.out.println(board[2][0] + "|" + board[2][1] + "|" + board[2][2]);
	   System.out.println();
	}
}