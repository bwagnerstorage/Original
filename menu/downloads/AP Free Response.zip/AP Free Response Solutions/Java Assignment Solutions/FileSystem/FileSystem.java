public class FileSystem
{
	private FilingCabinet cabinet;
	
	public FileSystem()
	{
	   cabinet = new FilingCabinet();
	   printCabinet();
	   System.out.println("Test: FindDrawer");
	   System.out.println("----------------");
	   DrawerNode dNode = cabinet.FindDrawer(500);
	   System.out.println("Drawer ID = 500: should return --> " + dNode.getDrawerMaxID());	
	   dNode = cabinet.FindDrawer(221);
	   System.out.println("Drawer ID = 221: should return --> " + dNode.getDrawerMaxID());
	   System.out.println();
	   System.out.println("Test: RemoveStudent");
	   System.out.println("-------------------");
	   cabinet.RemoveStudent(178);
	   printCabinet();
	   System.out.println("--->id 178 should be removed");
	   System.out.println();
	   cabinet.RemoveStudent(987);
	   printCabinet(); 
	   System.out.println("--->id 987 should be removed");
	   System.out.println();
	   cabinet.RemoveStudent(834);
	   printCabinet(); 
	   System.out.println("--->id 834 should be removed");
	   System.out.println();
	}
	
	public void printCabinet()
	{
		DrawerNode drawerCur = cabinet.getDrawerList();
		while(drawerCur != null)
		{
			StudentNode studentCur = drawerCur.getStudentList();
			System.out.print("Drawer Max = " + drawerCur.getDrawerMaxID() + " : ");
			while(studentCur != null)
			{
				System.out.print(studentCur.getIDNum() + " ");
				studentCur = studentCur.getNext();
			}
			System.out.println();
			drawerCur = drawerCur.getNext();
		}
		System.out.println();
	}
	
	public static void main(String[] args)
	{
		FileSystem app = new FileSystem();
	}
}