public class StudentNode 
{ 
   private int idNum; 
   private StudentNode next;

   public StudentNode(int id, StudentNode initNext)
   {
      idNum = id;
	  next = initNext;
   }
   
   public int getIDNum()
   {
       return idNum;
   }
   
   public StudentNode getNext()
   {
       return next;
   }
   
   public void setNext(StudentNode initNext)
   {
   	   next = initNext;
   }
};
