public class DrawerNode 
{ 
   private int drawerMaxID; 
   private StudentNode studentList;   // if drawer is empty, studentList is NULL 
   private DrawerNode next; 
   
   public DrawerNode(int maxID, StudentNode list, DrawerNode initNext)
   {
   	  drawerMaxID = maxID;
	  studentList = list;
	  next = initNext;
   }
   
   public int getDrawerMaxID()
   {
      return drawerMaxID;
   }
   
   public StudentNode getStudentList()
   {
   	  return studentList;
   }
   
   public DrawerNode getNext()
   {
   	  return next;
   }
   
   // sets the header node for this list to newHeader
   public void setStudentList(StudentNode newHeader)
   {
   	  studentList = newHeader;
   }
};