class FilingCabinet 
{ 
   private DrawerNode drawerList;
   
   public FilingCabinet()
   {
   	  StudentNode current;
   	  StudentNode temp;
   	  
   	  current = new StudentNode(250, null);
   	  temp = new StudentNode(178, current);
   	  current = temp;
   	  temp = new StudentNode(123, current);
   	  current = temp;
   	  StudentNode studentList1 = current;	  
   	  
   	  StudentNode studentList2 = new StudentNode(542, null);
   	  
   	  current = new StudentNode(834, null);
   	  temp = new StudentNode(888, current);
   	  current = temp;
   	  temp = new StudentNode(987, current);
   	  current = temp;
   	  StudentNode studentList3 = current;
   	  	
   	  DrawerNode current2;
   	  DrawerNode temp2;
   	  current2 = new DrawerNode(999, studentList3, null);
   	  temp2 = new DrawerNode(850, null, current2);
   	  current2 = temp2;
   	  temp2 = new DrawerNode(637, studentList2, current2);
   	  current2 = temp2;
   	  temp2 = new DrawerNode(428, null, current2);
   	  current2 = temp2;
   	  temp2 = new DrawerNode(250, studentList1, current2);
   	  current2 = temp2;
   	  
   	  drawerList = current2;
   }
  
    // precondition:  this FilingCabinet has at least one drawer; 
    //     studentID is less than or equal to drawerMaxID
    //     of the last drawer in the cabinet
    // postcondition: returns the first DrawerNode d such that
    //     studentID is less than or equal to d.getDrawerMaxID()
    public DrawerNode FindDrawer(int studentID)
    { 
    	DrawerNode drawerCur = drawerList;
    	while(drawerCur != null && studentID > drawerCur.getDrawerMaxID())
    	{
    	   drawerCur = drawerCur.getNext();
    	}
    	return drawerCur;
    } 

    // precondition:   this FilingCabinet has at least one drawer;
    //     studentID is less than or equal to drawerMaxID
    //     of the last drawer
    // postcondition: if there is a node containing studentID in this
    //     FilingCabinet, that node has been removed from its
    //     drawer; otherwise this FilingCabinet is unchanged
    public void RemoveStudent(int studentID)
    { 
    	DrawerNode drawerCur = getDrawerList();
		while(drawerCur != null)
		{
			StudentNode studentList = drawerCur.getStudentList();
			StudentNode studentCur = studentList;
			StudentNode prev = studentCur;
			while(studentCur != null)
			{
				if(studentCur.getIDNum() == studentID)
				{
					if(studentCur == studentList)
					{
					   drawerCur.setStudentList(studentList.getNext());	
					}
					else
				   	   prev.setNext(studentCur.getNext());
				}
				else
				{
					prev = studentCur;
				}
				studentCur = studentCur.getNext();
			}
			drawerCur = drawerCur.getNext();
		}
    } 
    	
    public DrawerNode getDrawerList()
    {
    	return drawerList;
    }
};