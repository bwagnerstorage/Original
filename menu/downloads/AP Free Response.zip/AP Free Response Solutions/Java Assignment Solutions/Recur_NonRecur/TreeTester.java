public class TreeTester
{
	public static void main(String[] args)
	{
		BinarySearchTree tree = new BinarySearchTree();
		
		tree.add("D");
        tree.add("B");
        tree.add("A");
        tree.add("C");
        tree.add("F");
        tree.add("E");
        tree.add("G");
        
        System.out.println("Tree Structure");
        System.out.println("==============");
        System.out.println();
        System.out.println(tree);
        System.out.println();
        System.out.println("Inorder Traversal");
        System.out.println("=================");
        
        tree.inorderTraversal();

        System.out.println();
	}
}