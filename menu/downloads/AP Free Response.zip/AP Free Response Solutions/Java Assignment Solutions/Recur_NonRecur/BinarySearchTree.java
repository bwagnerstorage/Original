import java.util.*;

public class BinarySearchTree
{
   private TreeNode root;
   
   public BinarySearchTree()
   {
      root = null;
   }
   
   // adds a new node to the tree using the ordering property
   // items less than the root go down left subtree and items greater
   // than or equal to the root go down the right subtree
   public void add(Comparable item)
   {
   	  root = add(root, item);
   }
   
   // helper method for add
   private TreeNode add(TreeNode root, Comparable item)
   {
   	  if(root == null)
   	  {
   	  	 return new TreeNode(item, null, null);
   	  }
   	  
   	  if(item.compareTo(root.getValue()) < 0)
   	     root.setLeft(add(root.getLeft(), item));
   	  else 
   	     root.setRight(add(root.getRight(), item));
   	     
   	  return root;
   }
   
   // traverses and prints the tree inorder: left, root, right
   public void inorderTraversal()
   {
   	  inorderTraversal(root);
   }
   
   // helper method for inorderTraversal
   private void inorderTraversal(TreeNode root)
   {
   	  Stack<TreeNode> stack = new Stack<TreeNode>();
   	  TreeNode temp = null;
   	  
   	  temp = root;
   	  
   	  do
   	  {
   	  	while(temp != null)
   	  	{
   	  		stack.push(temp);
   	  		temp = temp.getLeft();
   	  	}
   	  	
   	  	if(!stack.isEmpty())
   	  	{
   	  		temp = stack.pop();
   	  	}
   	  	
   	  	System.out.print(temp.getValue() + " ");
   	  	temp = temp.getRight();
   	  }
   	  while(!stack.isEmpty() || temp != null);
   	  System.out.println();
   }
   
   // prints tree vertically so that tree structure
   // can be easily identified - uses reverse inorder
   // traversal: right-root-left
   public String toString()
   {
      return toString(root, 0);
   }
   
   // return string representation of tree's structure
   private String toString(TreeNode root, int level)
   {
      String str = "";
      if(root != null)
      {
        str += toString(root.getRight(), level + 1);
        for(int i = 1; i <= level; i++)
        {
            str = str + "  ";
        }
        str += root.getValue().toString() + "\n";
        str += toString(root.getLeft(), level + 1);
      }
      
      return str;
   }  
}