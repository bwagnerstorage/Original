public interface MySet
{
	// returns number of items in set
	int size();
	
	// returns true if set is empty
	// otherwise, returns false
	boolean isEmpty();
	
	// returns true if obj is in the set 
	// otherwise, returns false
	boolean contains(Object obj);
	
	// if obj is not present in this set, adds obj and returns true
    // otherwise, returns false
	boolean add(Object obj);
	
	// if obj is present in this set, removes obj and returns true
	// otherwise, returns false
	boolean remove(Object obj);
}