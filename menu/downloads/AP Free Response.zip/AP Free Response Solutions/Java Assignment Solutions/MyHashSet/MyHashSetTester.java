import java.util.*;

public class MyHashSetTester
{
	public static void main(String[] args)
	{
		MyHashSet set = new MyHashSet();
		
		set.add("Texas");
		set.add("Oklahoma");
		set.add("Florida");
		set.add("Colorado");
		set.add("New York");
		set.add("California");
		set.add("Washington");
		set.add("Maine");
		set.add("Alabama");
		set.add("Iowa");
		
		if(set.contains("Texas"))
			System.out.println("Set contains Texas");
		else
			System.out.println("Set does not contain Texas");
			
	    if(set.contains("Colorado"))
			System.out.println("Set contains Colorado");
		else
			System.out.println("Set does not contain Colorado");
			
	    if(set.contains("Maine"))
			System.out.println("Set contains Maine");
		else
			System.out.println("Set does not contain Maine");
			
	    if(set.contains("Mississippi"))
			System.out.println("Set contains Mississippi");
		else
			System.out.println("Set does not contain Mississippi");
			
		set.print();
			
	    if(set.remove("Oklahoma"))
	       System.out.println("Oklahoma was removed");
	       
	    set.print();
	       
	    if(set.remove("Texas"))
	       System.out.println("Texas was removed");
	       
	    set.print();
	       
	    set.remove("Florida");
	    
	    set.print();
	    
	    set.remove("Iowa");
	    
	    set.print();
	    
	    Iterator iterator = set.iterator();
	    while(iterator.hasNext())
	    {
	    	System.out.println(iterator.next());
	    }
	}	
	
}