import java.util.Iterator;
import java.util.NoSuchElementException;

public class MyHashSet implements MySet
{
	// constants
	public static int DEFAULT_CAPACITY = 5;
	
	// instance variables
	private ListNode[] table; // hash table
	private int capacity;     // size of table[]
	private int size;         // number of items in the set
	
	private ListNode current; // current node
	private ListNode prev;    // prev node
	private int index;        // index of current chain
	
	// constructor
	public MyHashSet()
	{
	   capacity = DEFAULT_CAPACITY;
	   table = new ListNode[capacity];
	   size = 0;
	}
	
	public int size()
	{
	   return size;
	}
	
	public boolean isEmpty()
	{
	   return size == 0;	
	}
	
	public boolean contains(Object obj)
	{
	   for(int i=0; i < table.length; i++)
	   {
	   	  for(ListNode node = table[i]; node != null; node = node.getNext())
	   	  {
	   	  	 if(node.getValue().equals(obj))
	   	  	 {
	   	  	 	return true;
	   	  	 }
	   	  } 
	   }
	   return false;	
	}
	
	public boolean add(Object obj)
	{
	   if(!contains(obj))
	   {
	   	  index = Math.abs(obj.hashCode() % capacity);
	   	  current = table[index];
	   	  prev = null;
	   	  while(current != null)
	   	  {
	   	  	 prev = current;
	   	  	 current = current.getNext();
	   	  }
	   	  ListNode newNode = new ListNode(obj, null);
	   	  if(prev == null)
	   	  {
	   	  	table[index] = newNode;
	   	  }
	   	  else
	   	  {
	   	  	prev.setNext(newNode);
	   	  }
	   	  return true;	  
	   }
	   return false;	
	}
	
	public boolean remove(Object obj)
	{
	   if(!contains(obj))
	   {
	   	  return false;
	   }
	   index = Math.abs(obj.hashCode() % capacity);
	   current = table[index];
	   prev = null;
	   while(!current.getValue().equals(obj))
	   {
	   	  prev = current;
	   	  current = current.getNext();
	   }
	   if(prev == null)
	   {
	   	  table[index] = current.getNext();
	   }
	   else
	   {
	   	  prev.setNext(current.getNext());
	   }
	      
	   return true;	   	
	}
	
	public void print()
	{
		for(int i=0; i < table.length; i++)
		{
		   ListNode temp = table[i];
		   System.out.print("[" + i + "] ");
		   if(temp == null)
		   {
		   	  System.out.println("null");
		   }
		   else
		   {
			   while(temp != null)
			   {
			   	  System.out.print(temp.getValue() + "-->");
			   	  temp = temp.getNext();
			   }	
			   System.out.println("null");
		   }
		}
		System.out.println();System.out.println();
		
	}
	
	/******************************************/
	/*             Iterator Methods           */
	/******************************************/
	
	public Iterator iterator()
	{
		return new MyIterator();
	}
	
	// private inner class
	private class MyIterator implements Iterator
	{
		// instance variables
		private ListNode iterCurrent; // current node during iteration
	    private ListNode iterPrev;    // previous node during iteration
	    private int iterIndex;        // current index in chain
	    
	    public MyIterator()
	    {
	       iterIndex = 0;
	       iterCurrent = table[iterIndex];
	       iterPrev = null;	
	    }
		
		// Iterator methods
		
		// Returns true if the iteration has more elements. 
		public boolean hasNext()
		{
		   while(iterIndex < table.length)
		   {
		   	  if(iterCurrent == null)
		   	  {
		   	  	  iterIndex++;
		   	  	  if(iterIndex < table.length)
		   	         iterCurrent = table[iterIndex]; 
		   	  }
		   	  else
		   	  {
		   	  	return true;
		   	  }
		   }
		   return false;
		}
		
		// Returns the next element in the iteration
		public Object next()
		{
		   if(iterCurrent == null)
		   	  throw new NoSuchElementException();
		   Object obj = iterCurrent.getValue();
		   iterPrev = iterCurrent;
		   iterCurrent = iterCurrent.getNext();
		   return obj;
		}
		
		// not implemented
		public void remove()
		{
			throw new UnsupportedOperationException();
		}
	}
}