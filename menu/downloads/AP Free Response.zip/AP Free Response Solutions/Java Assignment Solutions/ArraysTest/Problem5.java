public class Problem5
{
	public static void main(String[] args)
	{
		System.out.println(Mystery(10));
	}
	
    public static int Mystery(int n)
    {
        int[] list = new int[100];
        list[0] = 1;
        list[1] = 1;
        for(int i = 2; i <= n; i++)
        {
            list[i] = list[i-1] + list[i-2];
        }
        return list[n];
    }
}