public class Problem7
{
	public static void main(String[] args)
	{
		
	}
}

public class Ticket
{
    private String row;
    private int seat;
    private double price;
    
    // constructor
    public Ticket(String r, int s, double p)
    {
        row = r;
        seat = s;
        price = p;
    }
    
    // accessor methods getRow(), getSeat(), getPrice();
}

public class Transaction
{
    private Ticket[] ticketList;
    private int numTickets;
    
    // constructor
    public Transaction(int tickets)
    {
        numTickets = tickets;
        ticketList = new Ticket[numTickets];
        String row;
        int seat;
        double price;
        for(int i=0; i < numTickets; i++)
        {
           // <read user input for row, seat, and price>
           ticketList[i] = new Ticket(row, seat, price);    
        }
    }
    
    // returns the total amount paid for this transaction
    public double totalPaid()
    {
       double total = 0.0;
       //<code to calculate amount>
       for(int i=0; i < numTickets; i++)
       {
          total += ticketList[i].getPrice();
       }
       return total;    
    }
}