import java.util.*;

public class Problem8
{
	public static void main(String[] args)
	{
	   BiggestLoser app = new BiggestLoser();	
	}
}

class Contestant
{
	private String name;
	private int startWeight;
	private int currentWeight;	
	
	public Contestant(String n, int w)
	{
		name = n;
		startWeight = w;
		currentWeight = w;
	}
	
	public String getName()
	{
		return name;
	}
	
	public int getStartWeight()
	{
		return startWeight;
	}
	
	public int getWeightLoss()
	{
		return startWeight - currentWeight;
	}
	
	public void setCurrentWeight(int w)
	{
		currentWeight = w;
	}
}

class BiggestLoser
{
	public int MAX = 50;
	private Contestant[] list;
	private int numContestants;
	
	public BiggestLoser()
	{
		list = new Contestant[MAX];
		numContestants = 0;
	}
	
	public void addContestant(String name, int startWeight)
	{
		list[numContestants] = new Contestant(name, startWeight);
		numContestants++;
	}
	
	public void updateCurrentWeight(int index, int weight)
	{
		list[index].setCurrentWeight(weight);
	}
	
	public void printList()
	{
		for(int i=0; i < numContestants; i++)
		{
			System.out.print(list[i].getName() + " ");
			System.out.print(list[i].getStartWeight() + " ");
			System.out.println(list[i].getWeightLoss());
		}
	}
}

