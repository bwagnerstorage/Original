public class Problem4
{
	public static void main(String[] args)
	{
        final int MAX = 10;
        int[] list = new int[MAX];
        int X = list[0];
        
        for(int i=0; i < MAX; i++)
        {
           list[i] = (int)(Math.random() * 20);     
        }
        
        for(int i=0; i < MAX; i++)
        {
           System.out.print(list[i]+ " ");  
        }
        System.out.println();
        
        for(int i=0; i < MAX-1; i++)
        {
            if(list[i] > X)
              X = list[i];
            
        }
        System.out.print(X);
	}
}