public class Problem3
{
	public static void main(String[] args)
	{
        int[] list = <code>;
        for(int i=0; i < 20; i++)
        {
            list[i] = i;
        }
	}
}

Which of the following statements can be inserted for <code>
so that the array list will be initialized with a size of 20.

A) int[20]
B) new int[20]
C) array[20]
D) new array[20]