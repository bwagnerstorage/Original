public class Problem1
{
	public static void main(String[] args)
	{
        int[] array = new int[5];
        for(int i=0; i <= array.length; i++)
        {
            System.out.print(array[i] + " ");
        }
	}
}

// ArrayIndexOutOfBoundsExeception

What is the output of the following code segment

A) 1 2 3 4 5
B) 0 1 2 3 4
C) error - ArrayIndexOutOfBoundsException
D) 0 0 0 0 0