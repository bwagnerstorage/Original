public class Problem2
{
	public static void main(String[] args)
	{
        int[] array = {5, 10, 15, 20, 25};
        for(int i=0; i < 5; i++)
        {
            System.out.print(array[i] + " ");
        }
	}
}

// 5 10 15 20 25

A) error - ArrayIndexOutOfBoundsException
B) 0 1 2 3 4
C) 0 0 0 0 0
D) 5 10 15 20 25