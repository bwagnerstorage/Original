public class MinHeap
{
    private TreeNode root;
    
    public MinHeap()
    {
        root = null;
    }
    
    public void setRoot(TreeNode node)
    {
        root = node;
    }

    // part (a)
    public TreeNode smallerChild(TreeNode T)
    {
        if(T == null)
            return null;
        else if(T.getLeft() == null)
            return T.getRight();
        else if(T.getRight() == null)
            return T.getLeft();
        else if(T.getLeft().getValue() < T.getRight().getValue())
            return T.getLeft();
        else
            return T.getRight();
    }
    
    
    // part (b)
    public boolean isHeapOrdered(TreeNode T)
    {
        TreeNode minNode = smallerChild(T);
        if(minNode == null)
           return true;
        else
           return T.getValue() < minNode.getValue() &&
               isHeapOrdered(T.getLeft()) &&
               isHeapOrdered(T.getRight());
    }
    
    // part (c)
    // precondition: T is not null
	private TreeNode removeMinHelper(TreeNode T)
	{
	   TreeNode smaller = smallerChild(T);
	   
	   if(smaller == null)
	     return null;
	     
	   T.setValue(smaller.getValue());
	   if(smaller == T.getLeft())
	     T.setLeft(removeMinHelper(T.getLeft()));
	   else
	     T.setRight(removeMinHelper(T.getRight()));
	     
	   return T;
	}
	
	public Object removeMin()
	{
	   if(root == null)
	      return null;
	   else
	   {
	      Object result = root.getValue();
		  root = removeMinHelper(root);
		  return result;
	   }
	}
    
    
   /***********************************/
   /*            toString             */
   /***********************************/ 
   
   // prints tree vertically so that tree structure
   // can be easily identified - uses reverse inorder
   // traversal: right-root-left
   public String toString()
   {
      return toString(root, 0);
   }  
   
   private String toString(TreeNode tree, int level)
   {
      String str = "";
      if(tree != null)
      {
        str += toString(tree.getRight(), level + 1);
        for(int i = 1; i <= level; i++)
        {
            str = str + "  ";
        }
        str += tree.getValue() + "\n";
        str += toString(tree.getLeft(), level + 1);
      }
      
      return str;
   }

}