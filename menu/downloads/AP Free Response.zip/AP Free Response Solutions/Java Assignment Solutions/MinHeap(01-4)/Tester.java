public class Tester
{
	public static void main(String[] args)
	{
		// Heap T1
		MinHeap T1 = new MinHeap();
		
		TreeNode n1 = new TreeNode(1, null, null);
		TreeNode n2 = new TreeNode(2, null, null);
		TreeNode n3 = new TreeNode(3, null, null);
		TreeNode n4 = new TreeNode(4, null, null);
		TreeNode n5 = new TreeNode(5, null, null);
		TreeNode n8 = new TreeNode(8, null, null);
		TreeNode n11 = new TreeNode(11, null, null);
		TreeNode n14 = new TreeNode(14, null, null);
		TreeNode n17 = new TreeNode(17, null, null);
		TreeNode n20 = new TreeNode(20, null, null);
		
		n1.setLeft(n2);
		n1.setRight(n3);
		
		n2.setLeft(n4);
		n2.setRight(n5);
		
		n5.setLeft(n14);
		n5.setRight(n17);
		
		n3.setLeft(n8);
		n3.setRight(n11);
		
		n8.setLeft(n20);
		
		T1.setRoot(n1);
		
		System.out.println("Heap - T1");
		System.out.println("---------");
		System.out.println(T1);
		System.out.println();
		
		System.out.println("Test - smallerChild");
		System.out.println("-------------------");
		if(T1.smallerChild(n1) != null)
		   System.out.println("smallerChild of 1 = " + T1.smallerChild(n1).getValue());
		else
		   System.out.println("smallerChild of 1 = " + T1.smallerChild(n1));
		if(T1.smallerChild(n8) != null)
		   System.out.println("smallerChild of 8 = " + T1.smallerChild(n8).getValue());
		else
		   System.out.println("smallerChild of 8 = " + T1.smallerChild(n8));
		if(T1.smallerChild(n11) != null)
		   System.out.println("smallerChild of 11 = " + T1.smallerChild(n11).getValue());
		else
		   System.out.println("smallerChild of 11 = " + T1.smallerChild(n11));
		  
		System.out.println(); 
		System.out.println("Test - isHeapOrdered");
		System.out.println("--------------------");
		System.out.println(T1.isHeapOrdered(n1));
		System.out.println(T1.isHeapOrdered(n5));
		System.out.println(T1.isHeapOrdered(n8));
		System.out.println();
				
		// Heap T2
		MinHeap T2 = new MinHeap();
		
		TreeNode n6 = new TreeNode(6, null, null);
		TreeNode n7 = new TreeNode(7, null, null);
		TreeNode n9 = new TreeNode(9, null, null);
		TreeNode n12 = new TreeNode(12, null, null);
		TreeNode n15 = new TreeNode(15, null, null);
		
		n2.setLeft(n4);
		n2.setRight(n3);
		
		n4.setLeft(n7);
		n4.setRight(n5);
		
		n7.setLeft(n9);
		n7.setRight(n15);
		
		n5.setLeft(n6);
		n5.setRight(null);
		
		n3.setLeft(n8);
		n3.setRight(n11);
		
		n8.setLeft(n12);

		T2.setRoot(n2);
		
		System.out.println();
		System.out.println("Heap - T2");
		System.out.println("---------");
		System.out.println(T2);
		System.out.println();
		
		System.out.println("Test - smallerChild");
		System.out.println("-------------------");
		if(T1.smallerChild(n4) != null)
		   System.out.println("smallerChild of 4 = " + T1.smallerChild(n4).getValue());
		else
		   System.out.println("smallerChild of 4 = " + T1.smallerChild(n4));
		if(T1.smallerChild(n3) != null)
		   System.out.println("smallerChild of 3 = " + T1.smallerChild(n3).getValue());
		else
		   System.out.println("smallerChild of 3 = " + T1.smallerChild(n3));
		if(T1.smallerChild(n15) != null)
		   System.out.println("smallerChild of 15 = " + T1.smallerChild(n15).getValue());
		else
		   System.out.println("smallerChild of 15 = " + T1.smallerChild(n15));
		
		System.out.println(); 
		System.out.println("Test - isHeapOrdered");
		System.out.println("--------------------");
		System.out.println(T2.isHeapOrdered(n2));
		System.out.println();
		
		// Heap T3
		MinHeap T3 = new MinHeap();
		
		n2.setLeft(n4);
		n2.setRight(n3);
		
		n4.setLeft(n9);
		n4.setRight(n5);
		
		n9.setLeft(n7);
		n9.setRight(n15);
		n7.setLeft(null);
	    n7.setRight(null);
		
		n5.setLeft(n6);
	    n6.setLeft(null);
	    n6.setRight(null);
		
		n3.setLeft(n8);
		n3.setRight(n11);
		
		n8.setLeft(n12);
		
		T3.setRoot(n2);
		
		System.out.println();
		System.out.println("Heap - T3");
		System.out.println("---------");
		System.out.println(T3);
		System.out.println();
		
		System.out.println("Test - smallerChild");
		System.out.println("-------------------");
		if(T1.smallerChild(n1) != null)
		   System.out.println("smallerChild of 5 = " + T1.smallerChild(n5).getValue());
		else
		   System.out.println("smallerChild of 5 = " + T1.smallerChild(n5));
		if(T1.smallerChild(n8) != null)
		   System.out.println("smallerChild of 8 = " + T1.smallerChild(n8).getValue());
		else
		   System.out.println("smallerChild of 8 = " + T1.smallerChild(n8));
		if(T1.smallerChild(n11) != null)
		   System.out.println("smallerChild of 11 = " + T1.smallerChild(n11).getValue());
		else
		   System.out.println("smallerChild of 11 = " + T1.smallerChild(n11));
		
		System.out.println(); 
		System.out.println("Test - isHeapOrdered");
		System.out.println("--------------------");
		System.out.println(T3.isHeapOrdered(n2));
		System.out.println();
		
		System.out.println(); 
		System.out.println("Test - removeMin");
		System.out.println("--------------------");
		System.out.println("Min value = " + T3.removeMin());
		System.out.println();
		System.out.println(T3);
		System.out.println();

	}
}