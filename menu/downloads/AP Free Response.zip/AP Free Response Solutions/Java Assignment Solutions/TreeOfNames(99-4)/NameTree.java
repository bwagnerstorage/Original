public class NameTree
{
	private TreeNode root;
	
	public NameTree()
	{
		root = null;
	}
	
	public void setRoot(TreeNode node)
	{
		root = node;
	}
	
	// postcondition: returns the maximum of x and y 
	public int max(int x, int y)
	{
		return Math.max(x, y);
	}
	
	public int pathLength(String someName, int level)
	{
		 return pathLengthHelper(root, someName, level);
	}
	
    private int pathLengthHelper(TreeNode T, String someName, int level)
	{
		 int m = 0;
		 if(T == null)
		 {
		 	 return 0;
		 }
		 m =  max(pathLengthHelper(T.getLeft(), someName, level+1),
		 	 	        pathLengthHelper(T.getRight(), someName, level+1));
		 if(m > 0)
		 	return m;
		 
		 if(someName.equals(T.getValue()))
		 	return level;
		 	
		 return 0;
		 
	}
	
	public int rootPath(TreeNode T)
	{
		if(T == null)
		   return 0;
		else
		   return pathLengthHelper(T, (String)T.getValue(), 1);
	}
	
   /***********************************/
   /*            toString             */
   /***********************************/ 
   
   // prints tree vertically so that tree structure
   // can be easily identified - uses reverse inorder
   // traversal: right-root-left
   public String toString()
   {
      return toString(root, 0);
   }  
   
   private String toString(TreeNode tree, int level)
   {
      String str = "";
      if(tree != null)
      {
        str += toString(tree.getRight(), level + 1);
        for(int i = 1; i <= level; i++)
        {
            str = str + "     ";
        }
        str += tree.getValue().toString() + "\n";
        str += toString(tree.getLeft(), level + 1);
      }
      
      return str;
   }  
}