public class Tester
{
	public static void main(String[] args)
	{
		NameTree tree = new NameTree();
		
		TreeNode node1 = new TreeNode("Susan", null, null);
		TreeNode node21 = new TreeNode("Theresa", null, null);
		TreeNode node22 = new TreeNode("Chris", null, null);
		node1.setLeft(node21);
		node1.setRight(node22);
		
		TreeNode node31 = new TreeNode("Fran",null, null);
		TreeNode node32 = new TreeNode("Susan",null, null);
		TreeNode node33 = new TreeNode("Don",null, null);
		TreeNode node34 = new TreeNode("Ken",null, null);
		node21.setLeft(node31);
		node21.setRight(node32);
		node22.setLeft(node33);
		node22.setRight(node34);
		
		TreeNode node41 = new TreeNode("Gail",null, null);
		TreeNode node42 = new TreeNode("Susan",null, null);
		TreeNode node43 = new TreeNode("Fran",null, null);
		node32.setLeft(node41);
		node33.setLeft(node42);
		node33.setRight(node43);
		
		TreeNode node51 = new TreeNode("Don",null, null);
		TreeNode node52 = new TreeNode("Mark",null, null);
		TreeNode node53 = new TreeNode("Theresa",null, null);
		node42.setLeft(node51);
		node43.setLeft(node52);
		node43.setRight(node53);
		
		TreeNode node61 = new TreeNode("Chris",null, null);
		node53.setRight(node61);
		
		tree.setRoot(node1);
		
		System.out.println();
		System.out.println(tree);
		System.out.println();
		
		System.out.println("Path Length");
		System.out.println("-----------");
		System.out.println();
		System.out.println("Susan = " + tree.pathLength("Susan", 1));
		System.out.println();
		System.out.println("Fran = " + tree.pathLength("Fran", 1));
		System.out.println();
		System.out.println("Chris = " + tree.pathLength("Chris", 1));
		System.out.println();
		System.out.println();
		
		System.out.println("Root Path");
		System.out.println("---------");
		System.out.println();
		System.out.println("Susan = " + tree.rootPath(node1));
		System.out.println();
		System.out.println("Fran = " + tree.rootPath(node31));
		System.out.println();
		System.out.println("Don = " + tree.rootPath(node33));
	}
}