import java.util.*;

public class Thesaurus
{
    // stores (word, synonym set) pairs as (String, Set of Strings) 
    private Map<String, Set<String>> wordMap;
    
    public Thesaurus()
    { 
    	wordMap = new HashMap<String, Set<String>>();
    	
    	addSynonym("excellent", "brillant");
    	addSynonym("excellent", "great");
    	addSynonym("excellent", "outstanding");
    	addSynonym("excellent", "tremendous");
    	addSynonym("super", "excellent");
    	addSynonym("super", "fantastic");
    	addSynonym("super", "great");
    	addSynonym("super", "wonderful");
    	addSynonym("wonderful", "amazing");
    	addSynonym("wonderful", "brilliant");
    	addSynonym("wonderful", "fantastic");
    	addSynonym("wonderful", "great");
    	addSynonym("wonderful", "magnificent");
    	addSynonym("awesome", "wonderful");
    	
    	printMap();
    	
    	Set<String> set = removeSynonym("great");
    	
    	Iterator<String> iter = set.iterator();
    	System.out.println();
    	
    	while(iter.hasNext())
    	{
    		System.out.println(iter.next());
    	}
    	System.out.println();
    	System.out.println();
    	
    	printMap();
    } 
     
    // adds syn to the set of synonyms associated with word 
    // in this Thesaurus; 
    // if word is not a key in this Thesaurus, adds an 
    // entry with word as key and a set containing syn 
    // as the associated value
    public void addSynonym(String word, String syn)
    { 
       	if(wordMap.containsKey(word))
       	{
       		Set<String> set = wordMap.get(word);
       		set.add(syn);
       	}
       	else
       	{
       		Set<String> set = new HashSet<String>();
       		set.add(syn);
       		
       		wordMap.put(word, set);
       	}
    }
      
    // removes the word syn from each synonym set in this Thesaurus; 
    // returns a set of the words (keys) whose associated
    // synonym sets originally contained the word syn;
    // if syn was not contained in any synonym set, returns an empty set  
    public Set<String> removeSynonym(String syn)
    { 
    	Set<String> keys = wordMap.keySet();
    	Iterator<String> iter = keys.iterator();
    	Set<String> affectedWords = new HashSet<String>();
    	while(iter.hasNext())
    	{
    		String key = iter.next();
    		Set<String> set = wordMap.get(key);
    		if(set.contains(syn))
    		{
    			affectedWords.add(key);
    			set.remove(syn);
    		}
    		
    	}
    	return affectedWords;
    }
    
    public void printMap()
    {
        Set<String> keys = wordMap.keySet();
    	Iterator<String> iter = keys.iterator();
    	while(iter.hasNext())
    	{
    	    String key = iter.next();
    	    System.out.print(key + " {");
    		Set<String> set = wordMap.get(key);	
    		Iterator<String> iter2 = set.iterator();
    		while(iter2.hasNext())
    		{
    			String word = iter2.next();
    			if(iter2.hasNext())
    			   System.out.print(word + ",");
    			else
    			   System.out.println(word + "}");
    		}
    		System.out.println();
    	}	
    }
    
    public static void main(String[] args)
    {
    	Thesaurus app = new Thesaurus();
    }

}