import java.util.*;

public class Compete
{
    private Deck deck;
    private Queue<Card> player1Pile;
    private Queue<Card> player2Pile;
    private Queue<Card> discardPile;
    
    public Compete()
    {
       deck = new Deck();
       player1Pile = new LinkedList<Card>();
       player2Pile = new LinkedList<Card>();
       discardPile = new LinkedList<Card>();
       
       dealCards();
       playGame();
    }
    
    // postcondition: all cards have been removed from source 
    //                and added to destination in the same order
    void AppendQueue(Queue<Card> destination, Queue<Card> source)
    {
       while(!source.isEmpty())
       {
          destination.add(source.remove());
       }    
    }
    
    // precondition: pile1.length() > 0; pile2.length() > 0
    // postcondition: pile1 and pile2 have been updated according to the
    //                rules of the game
    void OneRound(Queue<Card> pile1, Queue<Card> pile2)
    {
        boolean roundOver = false;
        
        while(!roundOver)
        {
           if(pile1.isEmpty() && pile2.isEmpty())
	   	   {
	   	   	  roundOver = true;
	   	   }
	   	   else if(pile1.isEmpty())
	   	   {
	   	   	  AppendQueue(pile2, discardPile);
	   	   	  roundOver = true;
	   	   }
	   	   else if(pile2.isEmpty())
	   	   {
	   	   	  AppendQueue(pile1, discardPile);
	   	   	  roundOver = true;
	   	   }
	   	   else
	   	   {
	   	   
	   	   	  Card player1Card = pile1.remove();
	   	   	  Card player2Card = pile2.remove();
	   	   	  
	   	   	  if(player1Card.getValue() == player2Card.getValue())
	   	   	  {
	   	   	  	 discardPile.add(player1Card);
	   	   	  	 discardPile.add(player2Card);
	   	   	  }
	   	   	  else if(player1Card.getValue() > player2Card.getValue())
	   	   	  {
	   	   	  	  AppendQueue(pile1, discardPile);
	   	   	  	  pile1.add(player1Card);
	   	   	  	  pile1.add(player2Card);
	   	   	  	  roundOver = true;
	   	   	  }
	   	   	  else if(player2Card.getValue() > player1Card.getValue())
	   	   	  {
	   	   	  	  AppendQueue(pile2, discardPile);
	   	   	  	  pile2.add(player1Card);
	   	   	  	  pile2.add(player2Card);
	   	   	  	  roundOver = true;
	   	   	  }
	   	   }	
	   	}
	}
	
	public void dealCards()
	{
		HashSet<Card> cards = deck.getCards();
		int n = 0;
		Iterator iter = cards.iterator();
		while(iter.hasNext())
		{
			Card card = (Card)iter.next();
			if(n % 2 == 0)
			    player1Pile.add(card);
			else
			    player2Pile.add(card);
			n++;
		}
	}
	
	public void displayPile(Queue<Card> pile)
	{
	   for(Card card : pile)
	   {
	   	  System.out.print(card.getValue() + " ");
	   }
	   System.out.println();
	}
	
	public void displayRound()
	{
		System.out.println("Player 1");
	    displayPile(player1Pile);
	    System.out.println("Player 2");
	    displayPile(player2Pile);
	    System.out.println();
	}
	
	public void playGame()
	{
		int round = 1;
		displayRound();
	    while(round <= 25)
	    {
		    OneRound(player1Pile, player2Pile);
			System.out.println("Round " + round);
			System.out.println("==========");
			displayRound();   
			round++;  
	    }   
	}
	
	public static void main(String[] args)
	{
		Compete game = new Compete();
	}
}