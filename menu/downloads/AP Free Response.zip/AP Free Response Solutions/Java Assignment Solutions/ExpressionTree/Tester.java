import java.util.*;

public class Tester
{
	public static void main(String[] args)
	{
		Scanner keyboard = new Scanner(System.in);
		String expression;
		System.out.println("Enter infix expression (fully parenthesized)");
		System.out.print("infix-->");
		expression = keyboard.nextLine(); // get infix expression
		System.out.println();
	
		ExpressionTree tree = new ExpressionTree(expression);  // instantiate ExpressionTree object
	
		System.out.println("Postfix Notation");
		tree.postfix();
		
	    System.out.println(); System.out.println();
		System.out.println("Prefix Notation");
		tree.prefix();
		
	    System.out.println(); System.out.println();
		System.out.println("Infix Notation (not parenthesized)");
		tree.infix();
		
	    System.out.println(); System.out.println();
	}
}