import java.util.*;

class ExpressionTree
{
	// instance variables
	private String expression;          
	private Stack <TreeNode> operand;
	private Stack <TreeNode> operator;
	private TreeNode root;
	
	// constructors
	public ExpressionTree()
	{
	   operand = new Stack<TreeNode>  ();
	   operator = new Stack<TreeNode> ();
	   root = null;	
	}
	
	public ExpressionTree(String ex)
	{
	   operand = new Stack<TreeNode>  ();
	   operator = new Stack<TreeNode> ();
	   root = null;
	   expression = ex;
	   
	   makeExpressionTree();	
	}
	
	// creates Expression Tree from an infix form algebraic expression
    public void makeExpressionTree()
    {
    	int i=0;
	    while(i < expression.length())
	    {
	       TreeNode T;
	       if (expression.substring(i,i+1).equals("("))
	       {
			  T = new TreeNode("(", null, null);
			  operator.push(T);
	       }
	       else if (expression.substring(i,i+1).equals(")"))
	       {
		      while(!operator.peek().getValue().equals("("))
			      buildTree();

		      if(!operator.isEmpty())
		           operator.pop();
	       }
	       else if (expression.substring(i,i+1).equals("+") || 
	                expression.substring(i,i+1).equals("-") ||
	                expression.substring(i,i+1).equals("*") || 
	                expression.substring(i,i+1).equals("/"))
	       {
		      if(!operator.isEmpty())
		      {
		      	while(!operator.isEmpty() && getPrecedence((String)operator.peek().getValue()) >= getPrecedence(expression.substring(i,i+1)))
		            buildTree();
		      }
		         

		      T = new TreeNode(expression.substring(i,i+1), null, null);
		      operator.push(T);
	       }
	       else if(expression.substring(i,i+1).compareTo("A") >= 0 && expression.substring(i,i+1).compareTo("Z") <= 0 || 
	               expression.substring(i,i+1).compareTo("a") >= 0 && expression.substring(i,i+1).compareTo("z") <= 0 )
	       {
		      T = new TreeNode(expression.substring(i,i+1), null, null);
		      operand.push(T);
	       }
	       else if(expression.substring(i,i+1).equals(" "))
	       {
		      // do nothing
	       }  
	       else
		      System.out.println("Invalid Expression");

	     i++;
	  }

	  while(!operator.isEmpty())
		 buildTree();

	  if(!operand.isEmpty())
	     root = operand.pop();   // set tree root
    }
    
    // inserts an infix algebraic expression into the Expression Tree
    public void setExpression(String ex)  
    {
       expression = ex;	
    }
    // prints an algebraic expression in postfix form
    public void postfix()
    {
    	postOrderTraversal(root);
    }  
    
    // prints an algebraic expression in prefix form      
    public void prefix()
    {
    	preOrderTraversal(root);
    }    
    
    // prints an algebraic expression in infix form (not parethesized)     
    public void infix()
    {
    	inOrderTraversal(root);
    }          
	
	// helper methods
	private int getPrecedence(String oper)
	{
		if(oper.equals("("))
		   return 0;
	    else if (oper.equals("+") || oper.equals("-"))
		   return 1;
	    else if (oper.equals("*") || oper.equals("/"))
		   return 2;
	    else
		   return -1;  // error
	}
	
	private void buildTree()
	{
		TreeNode R = null, L = null, O = null;

		if(!operand.isEmpty())
		   R = operand.pop();
		if(!operand.isEmpty())
		   L = operand.pop();
		if(!operator.isEmpty())
		   O = operator.pop();
		O.setLeft(L);
		O.setRight(R);
		operand.push(O);
	}
	
	private void postOrderTraversal(TreeNode root)
	{
	    if(root != null)
		{
	       postOrderTraversal(root.getLeft());
		   postOrderTraversal(root.getRight());
		   System.out.print(root.getValue());
		}
	}
	
    private void preOrderTraversal(TreeNode root)
    {
    	if(root != null)
		{
	       System.out.print(root.getValue());
	       preOrderTraversal(root.getLeft());
		   preOrderTraversal(root.getRight());   
		}	
    }
    
    private void inOrderTraversal(TreeNode root)
    {
    	if(root != null)
		{
	       inOrderTraversal(root.getLeft());
	       System.out.print(root.getValue());
		   inOrderTraversal(root.getRight()); 
		}	
    }
}