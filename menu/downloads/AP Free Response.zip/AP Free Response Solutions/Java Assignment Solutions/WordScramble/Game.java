import java.util.*;

// This class is the driver program for the game.
// It displays the scrambled word and asks the
// user to make a guess as to what the word is
// suppose to be. If the user guesses correctly 
// it displays the message "Correct". If the user
// guesses incorrectly it displays the message 
// "Incorrect" and then displays the word unscrambled.
// The user is given the opportunity to play again or
// quit. If the user quits the class displays
// how many words the user got correct using the
// following form: 
// (number correct) out of (number attempted)

public class Game
{
   public static void main(String[] args)
   {
   	  Scrambler scrambler = new Scrambler();
   	  Scanner keyboard = new Scanner(System.in);
   	  String ans="y";
   	  int count = 0;
   	  int correct =0;
     
      System.out.println("Word Scrambler");
      System.out.println("==============");
      System.out.println();
   	  while(ans.equals("y"))
   	  {
   	  	 scrambler.selectWord();
   	  	 System.out.println("Scrambled word: " + scrambler.getScrambledWord());
   	  	 System.out.print("Guess-->");
   	  	 String guess = keyboard.nextLine();
   	  	 if(scrambler.makeGuess(guess) == true)
   	  	 {
   	  	 	System.out.println("Correct!");
   	  	 	correct++;
   	  	 }
   	  	 	
   	  	 else
            System.out.println("Wrong, The word is " + scrambler.getWord());
   	  	 
   	  	 
   	  	 System.out.println();
   	     System.out.print("Play again[Y/N]?");
   	     ans = keyboard.nextLine();
   	     System.out.println();
   	     count++;
   	   }
   	   System.out.println("You got " + correct + " out of " + count + " correct");
       System.out.println();  
   }	
}