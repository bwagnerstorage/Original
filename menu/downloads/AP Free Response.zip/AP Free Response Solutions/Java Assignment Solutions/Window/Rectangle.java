public class Rectangle
{
	// instance variables
	private int ULrow;     // row position of upper left corner of rectangle
	private int ULcol;     // column position of upper left corner of rectangle
	private int numRows;   // number of rows in rectangle (height) 
	private int numCols;   // number of columns in rectangle (width) 

	// constructor
	public Rectangle(int row, int col, int height, int width)
	{
		ULrow = row;
		ULcol = col;
		numRows = height;
		numCols = width;
	}
	
	// accessor methods
	public int getRow()
	{
		return ULrow;
	}
	
	public int getCol()
	{
		return ULcol;
	}
	
	public int getHeight()
	{
		return numRows;
	}
	
	public int getWidth()
	{
		return numCols;
	}
	
	// mutator methods
	public void setRow(int row)
	{
		ULrow = row;
	}
	
	public void setCol(int col)
	{
		ULcol = col;
	}
	
	public void setHeight(int height)
	{
		numRows = height;
	}
	
	public void setWidth(int width)
	{
		numCols = width;
	}
}