class Window 
{ 
    // instance variables
	private int myNumRows; 
	private int myNumCols; 
	private int [][]myMat;
	
    // constructor
    public Window(int r, int c)
    {
   	   myNumRows = r;
   	   myNumCols = c;
   	   myMat = new int[r][c];
   	   
   	   for(int r1=0;  r1 < myNumRows; r1++)
   	   {
   	   	   for(int c1=0; c1 < myNumCols; c1++)
   	   	   {
   	   	   	  myMat[r1][c1] = 10;
   	   	   }
   	   }
    } 
   
   	// postcondition: returns true if the point (row, col) is 
	//	 in this window; otherwise, returns false 	
	public boolean isInBounds(int row, int col)
	{
		if(row < myNumRows && col < myNumCols)
			return true;
	    else
	    	return false;
	}

	// postcondition: all points in this window that are also in the
	//	 N-by-N square with upper left corner
	//	 (ULrow, ULcol) have been set to val;
	//	 points in the square that are not in this
	//	 window are ignored
	public void colorSquare(int ULrow, int ULcol, int N, int val)
	{
		for(int r = ULrow; r < ULrow + N; r++)
		{
			for(int c = ULcol; c < ULcol + N; c++)
			{
				if(isInBounds(r, c))
					myMat[r][c] = val;
			}
		}
	}
	
	// precondition:   factor > 0 
	public void enlarge(Rectangle rect, int factor)
	{
	   int [][]rectMat = new int[rect.getHeight()][rect.getWidth()];
	   for(int r=0; r < rect.getHeight(); r++)
	   {
	   	  for(int c=0; c < rect.getWidth(); c++)
	   	  {
	   	  	 if(isInBounds(rect.getRow() + r, rect.getCol() + c))
	   	  	    rectMat[r][c] = myMat[rect.getRow() + r][rect.getCol() + c];
	   	  }
	   }
	   
	   int r1 = 0;
	   int c1 = 0;
	   for(int r=rect.getRow(); r < rect.getRow() + rect.getHeight() * factor; r+=factor)
	   {
	   	  c1 = 0;
	   	  for(int c=rect.getCol(); c < rect.getCol() + rect.getWidth() * factor; c+=factor)
	   	  {
	   	  	  colorSquare(r, c, factor, rectMat[r1][c1]);
	   	  	  c1++;
	   	  }
	   	  r1++;
	   }	   
	
	}
	
	// postcondition: returns color value at position row, col 
	//	 in this window
	public int valAt(int row, int col)
	{
		return myMat[row][col];
	}
	
	public void display()
	{
		for(int r=0; r < myNumRows; r++)
		{
			for(int c=0; c < myNumCols; c++)
			{
				System.out.print(myMat[r][c] + " ");
			}
			System.out.println();
		}
		System.out.println();
	}

    public static void main(String[] args)
    {
    	Window app = new Window(8,8);
    	
    	app.display();
    	
    	System.out.println("Test colorSquare method");
    	System.out.println("=======================");
    	app.colorSquare(2, 2, 3, 20);
    	app.colorSquare(5, 5, 4, 30);
    	app.colorSquare(3, 1, 2, 40);
    	app.colorSquare(5, 0, 3, 50);
    	app.colorSquare(2, 1, 1, 60);
    	app.display();
    	
    	System.out.println("  Test enlarge method");
    	System.out.println("=======================");
    	app.enlarge(new Rectangle(2, 0, 2, 4), 2);
    	app.display();
    }

};
