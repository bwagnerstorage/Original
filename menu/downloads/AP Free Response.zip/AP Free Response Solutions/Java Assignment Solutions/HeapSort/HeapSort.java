public class HeapSort
{
	private static int size=0;
	
	public static void sort(int[] heap)
	{
		for(int i=0; i < heap.length; i++)
		{
			insert(heap, heap[i]);
			size++;
		}
			
		size--;
		for(int i=heap.length-1; i>=0; i--)
		{
			heap[i] = removeMax(heap);
		}
	}
	
	// adds an item to the heap
	// it first adds the item to the end of the heap then
	// calls the method reheapUpward to place the new item
	// at its correct position in the heap
	// maintaining the maxheap property
	public static void insert(int [] heap, int item)
	{
		 heap[size] = item;
		 reheapUpward(heap);
	}
	
	/*******************************
	 *  parent = (i-1) / 2         *
	 *  left   = i-1               *
	 *  right  = i+1               *
	 *  left child = i*2 + 1       *
	 *  right child = i*2 + 2      *
	 *******************************/
	// part (a)
	// moves the newly added item to its correct location in the heap
	// it advances the new item up the tree by swapping it with its
	// parent until an acceptable location has be found
	private static void reheapUpward(int[] heap)
	{
	   int i = size;
	   while(i > 0 && heap[i] >= heap[(i-1)/2])
	   {
	   	  if(heap[i] >= heap[(i-1)/2])
	   	  {
	   	  	 // swap
	   	  	 int temp = heap[(i-1)/2];
	   	     heap[(i-1)/2] = heap[i];
	   	     heap[i] = temp;
	   	     
	   	     i = (i-1)/2; 
	   	  }
	   	  else
	   	     i--;		  	
	   }
	}
	
	// removes the largest item from the heap then
	// transfers the last item to the newly vacated
	// root position and calls the method reheapDownward
	// to re-establish the maxheap property
	private static int removeMax(int[] heap)
	{
		int max = heap[0];
		heap[0] = heap[size];
		reheapDownward(heap);
		size--;
                   
		return max;
	}
	
	// part (b)
	// moves the new root to its correct location in the heap
	// it advances the new root down the tree by swapping it with its
	// largest child until an acceptable location has be found
	private static void reheapDownward(int[] heap)
	{
		int i=0,j=0;
		do
		{
			i = j;
			if((i*2+1) < size && heap[i*2+1]>heap[j])
			  j = i*2+1;
			if((i*2+1) < size && heap[i*2+2]>heap[j])
			  j = i*2+2;
			  
			// swap
			int temp = heap[i];
	   	    heap[i] = heap[j];
	   	    heap[j] = temp; 
		}
		while(i != j);
	}
}