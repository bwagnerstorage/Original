import java.util.*;

public class EmailAddresses
{
   // Map addressBook is structured such that each key is a String 
   // representing an alias and the corresponding value is a Set
   // containing Strings that represent e-mail addresses and aliases
   private Map<String, Set<String>> addressBook;
   
   public EmailAddresses()
   {
   	  addressBook = new HashMap<String, Set<String>>();
   	  
   	  Set<String> set1 = new HashSet<String>();
   	  set1.add("pat@ez.edu");
   	  set1.add("chris@ez.edu");
   	  addressBook.put("techstaff", set1);
   	  
   	  Set<String> set2 = new HashSet<String>();
   	  set2.add("bobby");
   	  set2.add("ana");
   	  set2.add("sam@ez.edu");
   	  addressBook.put("faculty", set2);
   	  
   	  Set<String> set3 = new HashSet<String>();
   	  set3.add("bob@cs.org");
   	  addressBook.put("bobby", set3);
   	  
   	  Set<String> set4 = new HashSet<String>();
   	  set4.add("ana@ez.edu");
   	  addressBook.put("ana", set4);
   	  
   	  Set<String> set5 = new HashSet<String>();
   	  set5.add("phil@ez.edu");
   	  set5.add("faculty");
   	  set5.add("techstaff");
   	  addressBook.put("all", set5);
   	  
   	  // expand
   	  print(expandAlias("bobby"));
   	  print(expandAlias("faculty"));
   	  print(expandAlias("all"));
   	  
   }
   
   // adds all elements of the Set items to the Queue q 
   // postcondition: the Set items is not modified;
   //    q contains its original elements followed
   //    by the elements from items
   private void appendSetToQueue(Set<String> items, Queue<String> q)
   { 
   	   Iterator<String> iter = items.iterator();
       while(iter.hasNext())
       {
      	  q.add(iter.next());
       }   	
   }

   // returns a Set consisting of the e-mail addresses associated with 
   // the parameter alias, such that all intermediate resulting aliases 
   // have been expanded;
   // precondition: alias is a key in addressBook 
   public Set<String> expandAlias(String alias)
   { 
   	  Set<String> expandSet = new HashSet<String>();
   	  Queue<String> expandQ = new LinkedList<String>();
   	  Set<String> aliasSet = addressBook.get(alias);
   	  
   	  Iterator<String> iter = aliasSet.iterator();
   	  while(iter.hasNext())
   	  {
   	  	expandQ.add(iter.next());
   	 	while(!expandQ.isEmpty())
   	  	{
   	  		String expandAlias = expandQ.remove();
   	  		if(addressBook.containsKey(expandAlias))
   	  		{
   	  		    Set<String> set = addressBook.get(expandAlias);
                appendSetToQueue(set, expandQ);
   	  		}
   	  		else
   	  		{
   	  			expandSet.add(expandAlias);
   	  		} 
   	  	}
   	  }
   	  
   	  return expandSet;
   	   
   }
   
   public void print(Set<String> set)
   {
   	  Iterator<String> iter = set.iterator();
   	  System.out.print("{");
   	  while(iter.hasNext())
   	  {
   	  	 String str = iter.next();
   	  	 if(iter.hasNext())
   	  	    System.out.print(str + ",");
   	  	 else
   	  	 	System.out.println(str + "}");
   	  }
   	  System.out.println();
   }
   
   public static void main(String[] args)
   {
   	  EmailAddresses app = new EmailAddresses();
   }
        
}