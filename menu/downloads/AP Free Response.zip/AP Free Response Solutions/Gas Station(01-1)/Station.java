// Topic: Array
// Reference: AP A 2001 Question 1

public class Station
{
	// instance variables
	private double myBasePrice;     // current price per gallon of gas
	                                // for self-service pumps
	private Pump[] myPumps;         // the gas pumps; myPumps.length > 1
	                                // and is the number of pumps in this
	                                // station
	                             
	public Station(Pump[] p)
	{
		myPumps = p;
		myBasePrice = 2.00;
	}
	
	// Part (a)
	// postcondition: for every Pump p in this station
	//                p.GallonsSold() is 0.0
	public void resetAll()
	{
        for(int i=0; i < myPumps.length; i++)
        {
        	Pump p = myPumps[i];
        	p.resetGallonsSold();
        }

	}
	
	// Part (b)
	// postcondition: returns the total cash value of
	//                sales for all pumps
	public double totalSales()
	{
       double total=0;
       
       for(int i=0; i < myPumps.length; i++)
       {
       	  if(i == 0 || i == 1)
       	     total += myPumps[i].gallonsSold() * (myBasePrice + .25);
       	  else
       	     total += myPumps[i].gallonsSold() * myBasePrice;
       }
       
       return total;

	}
	
    // Part (c)
	// postcondition: creates a String containing the total 
	//                cash value of all gas sold for the day;
	//                for every Pump p in this station
	//                p.gallonsSold() is 0.0
	public String toString()
	{
       return "Total Value of Gallons Sold = " + totalSales();

	}
	
	
	public void print()
	{
		for(int i=0; i < myPumps.length; i++)
		{
			System.out.println("Pump " + i + " = " + myPumps[i].gallonsSold());
		}
		System.out.println();
	}
}