public class Pump
{
	// instance variable
	private double sold;
	
	/****** Constructors ******/
	
	public Pump()
	{
		sold = 0.0;
	}
	
	public Pump(double s)
	{
		sold = s;
	}
	
	/******* Methods ********/
	
	// postcondition: returns the number of gallons sold at
	//                this pump
	public double gallonsSold()
	{
	   return sold;
	}
	
	// postcondition: resets number of gallons sold at this
	//                pump to 0.0
	void resetGallonsSold()
	{
	    sold = 0.0;	
	}
}