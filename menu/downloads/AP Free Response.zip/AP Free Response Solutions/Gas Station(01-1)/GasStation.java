public class GasStation
{
	public static void main(String[] args)
	{
		Pump[] pumps = {new Pump(500),new Pump(600),new Pump(1200),new Pump(1400)};
		
		Station station1 = new Station(pumps);
		
		System.out.println("Station 1");
		System.out.println("---------");
		System.out.println();
		
		station1.print();
		
		// Test totalSales and toString method
		System.out.println("Test totalSales and toString method");
		System.out.println("===================================");
		System.out.println(station1);
		System.out.println();
		
	    System.out.println("Test resetAll method");
		System.out.println("====================");
		station1.resetAll();
		station1.print();

        System.out.println();
		System.out.println("-----------------------------------------------------------");
		System.out.println();
		
		System.out.println("Station 2");
		System.out.println("---------");
		System.out.println();
		
		Pump[] pumps2 = {new Pump(300),new Pump(200),new Pump(1000),new Pump(1500)};
		
		Station station2 = new Station(pumps2);
		
		station2.print();
		
		// Test totalSales and toString method
		System.out.println("Test totalSales and toString method");
		System.out.println("===================================");
		System.out.println(station2);
		System.out.println();
		
	    System.out.println("Test resetAll method");
		System.out.println("====================");
		station2.resetAll();
		station2.print();
	}
}