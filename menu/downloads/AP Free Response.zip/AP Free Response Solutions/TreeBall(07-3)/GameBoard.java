import java.util.*;

public class GameBoard
{
    private TreeNode root;  // the root of the tree
    
    // part (b)
    /** Creates a full binary tree rooted at root with numLevels levels
     *  with a random integer from 0 to 9, inclusive, generated for each node
     *  @ param numLevels the number of levels in the tree
     *          Precondition: numLevels > 0
     */
    public GameBoard(int numLevels)
    {  
       root = GameBoardHelper(numLevels);
    }
    
    public TreeNode GameBoardHelper(int numLevels)
    {
    	if(numLevels == 0)
    	{
    		return null;
    	}
    	else
    	{
    		return new TreeNode((int)(Math.random() * 10),
    		           GameBoardHelper(numLevels-1),
    		           GameBoardHelper(numLevels-1));
    	}
    }
    
    /** @ return the maximum path score for this GameBoard
     */
    public int getMaxScore()
    {  return getMaxHelper(root);  }
    
    // part(a)
    /** @param current the root of the subtree to be processed
     *  @return the maximum path score for the subtree rooted at current
     */
    private int getMaxHelper(TreeNode current)
    { 
       if(current == null)
       {
       	  return 0;
       }
       else
       {
       	  int leftMax = getMaxHelper(current.getLeft());
       	  int rightMax = getMaxHelper(current.getRight());
       	  if(leftMax >= rightMax)
       	  {
       	  	  return ((Integer)current.getValue()).intValue() + leftMax;
       	  }
       	  else
       	  {
       	  	return ((Integer)current.getValue()).intValue() + rightMax;
       	  }
       }
    
    }
    // There may be fields, constructors, and methods that are not shown.
    
    
    
   // prints tree vertically so that tree structure
   // can be easily identified - uses reverse inorder
   // traversal: right-root-left
   public String toString()
   {
      return toString(root, 0);
   }
   
   // return string representation of tree's structure
   private String toString(TreeNode root, int level)
   {
      String str = "";
      if(root != null)
      {
        str += toString(root.getRight(), level + 1);
        for(int i = 1; i <= level; i++)
        {
            str = str + "  ";
        }
        str += root.getValue().toString() + "\n";
        str += toString(root.getLeft(), level + 1);
      }
      
      return str;
   }

}
