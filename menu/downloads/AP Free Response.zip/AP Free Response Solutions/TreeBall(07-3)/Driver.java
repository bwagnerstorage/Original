public class Driver
{
	public static void main(String[] args)
	{
		GameBoard board1 = new GameBoard(4);
		System.out.println(board1);
		
		System.out.println("Max score = " + board1.getMaxScore());
		
		System.out.println(); System.out.println();
		
		GameBoard board2 = new GameBoard(3);
		System.out.println(board2);
		
		System.out.println("Max score = " + board2.getMaxScore());
		
		System.out.println(); System.out.println();
	}
}