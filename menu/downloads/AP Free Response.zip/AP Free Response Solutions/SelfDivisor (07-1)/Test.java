import java.util.*;

public class Test
{
	public static void main(String[] args)
	{
	   Collection <Integer> intList;
	   intList = new LinkedList <Integer> ();	
	}
}