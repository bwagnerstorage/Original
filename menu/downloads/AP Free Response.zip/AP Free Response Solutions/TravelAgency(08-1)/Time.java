import java.util.*;

public class Time 
{ 
   private GregorianCalendar time;
   
   public Time(int hour, int minute)
   {
   	  time = new GregorianCalendar(2008, 3, 12, hour, minute, 0);
   }
   
   /* @return difference, in minutes, between this time and other; 
    * difference is negative if other is earlier than this time 
    */ 
   public int minutesUntil(Time other) 
   { 
      long myTime = time.getTimeInMillis();
      long otherTime = other.time.getTimeInMillis();
      
      return (int)((otherTime - myTime) / (1000 * 60));            
   }
    
}