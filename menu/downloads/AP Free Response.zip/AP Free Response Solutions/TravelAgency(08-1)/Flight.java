public class Flight
{
   private Time departureTime;
   private Time arrivalTime;
   
   public Flight()
   {
   	  departureTime = null;
   	  arrivalTime = null;
   }
   
   public Flight(Time depart, Time arrival)
   {
   	  departureTime = depart;
   	  arrivalTime = arrival;
   }
   
   /** @return time at which the flight departs
    */
   public Time getDepartureTime()
   { 
      return departureTime;
   }
   
   /** @return time at which the flight arrives
    */
   public Time getArrivalTime()
   { 
      return arrivalTime;
   }
}