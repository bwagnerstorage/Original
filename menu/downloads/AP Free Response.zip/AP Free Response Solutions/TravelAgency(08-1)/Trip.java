import java.util.*;

public class Trip
{
   private ArrayList<Flight> flights;
   // stores the flights (if any) in chronological order
   
   public Trip()
   {
   	  flights = new ArrayList<Flight>();
   }
   
   public void add(Flight flight)
   {
   	  flights.add(flight);
   }

   /** @return the number of minutes from the departure of the first flight to the arrival
    *          of the last flight if there are one or more flights in the trip;
    *          0, if there are no flights in the trip
    */
   public int getDuration()
   { 
      if(flights.size() == 0)
        return 0;
      else
      {
      	 Flight firstFlight = flights.get(0);
      	 Flight lastFlight = flights.get(flights.size()-1);
      	 
      	 Time depart = firstFlight.getDepartureTime();
      	 Time arrival = lastFlight.getArrivalTime();
      	 
      	 return depart.minutesUntil(arrival);
      	 
      }
   
   }
   
   /** Precondition: the departure time for each flight is later than the arrival time of its
    *                preceding flight
    *  @return the smallest number of minutes between the arrival of a flight and the departure
    *          of the flight immediately after it, if there are two or more flights in the trip;
    *          -1, if there are fewer than two flights in the trip
    */
    public int getShortestLayover()
    { 
       int layover = 99999;
       if(flights.size() < 2)
         return -1;
       for(int i=0; i < flights.size() - 1; i++)
       {
       	  Flight f1 = flights.get(i);
       	  Flight f2 = flights.get(i+1);
       	  Time f1Arrival = f1.getArrivalTime();
       	  Time f2Departure= f2.getDepartureTime();
       	  
       	  int currentLayOver = f1Arrival.minutesUntil(f2Departure);
       	  
       	  if(currentLayOver < layover)
       	  {
       	  	 layover = currentLayOver;
       	  }
       }
       return layover;
    
    }
    
    // There may be instance variables, constructors, and methods that are not shown.
}