public class Driver
{
	public static void main(String[] args)
	{
		Time t1 = new Time(11, 30);
		Time t2 = new Time(12, 15);
		Time t3 = new Time(13, 15);
		Time t4 = new Time(15, 45);
		Time t5 = new Time(16, 00);
		Time t6 = new Time(18, 45);
		Time t7 = new Time(22, 15);
		Time t8 = new Time(23, 00);
		
		Flight f1 = new Flight(t1, t2);
		Flight f2 = new Flight(t3, t4);
		Flight f3 = new Flight(t5, t6);
		Flight f4 = new Flight(t7, t8);
		
		Trip trip = new Trip();
		trip.add(f1);
		trip.add(f2);
		trip.add(f3);
		trip.add(f4);
		
		System.out.println("Test 1");
		System.out.println("======");
		
		
		// test getDuration method - part (a)
		System.out.println("trip.getDuration() = "+ trip.getDuration() + " minutes");
		System.out.println();
		
		// test getShortestLayover method - part (b)
		System.out.println("trip.getShortestLayover() = " + trip.getShortestLayover() + " minutes");
		System.out.println();
		
		System.out.println("Test 2");
		System.out.println("======");
		
		t1 = new Time(1, 30);
		t2 = new Time(3, 45);
		
		f1 = new Flight(t1, t2);
		
		trip = new Trip();
		trip.add(f1);
		
		// test getDuration method - part (a)
		System.out.println("trip.getDuration() = "+ trip.getDuration() + " minutes");
		System.out.println();
		
		// test getShortestLayover method - part (b)
		System.out.println("trip.getShortestLayover() = " + trip.getShortestLayover() + " minutes");
		System.out.println();
		
	    System.out.println("Test 3");
		System.out.println("======");
		
		trip = new Trip();
		
		// test getDuration method - part (a)
		System.out.println("trip.getDuration() = "+ trip.getDuration() + " minutes");
		System.out.println();
		
		// test getShortestLayover method - part (b)
		System.out.println("trip.getShortestLayover() = " + trip.getShortestLayover() + " minutes");
		System.out.println();
		
		
				

	}
}