import java.util.*;

public class SeatingChartDriver
{
	public static void main(String[] args)
	{
		List<Student> list = new ArrayList();

		list.add(new Student("Karen", 3));
		list.add(new Student("Liz", 1));
		list.add(new Student("Paul", 4));
		list.add(new Student("Lester", 1));
		list.add(new Student("Henry", 5));
		list.add(new Student("Renee", 9));
		list.add(new Student("Glen", 2));
		list.add(new Student("Fran", 6));
		list.add(new Student("David", 1));
		list.add(new Student("Danny", 3));

		SeatingChart introCS = new SeatingChart(list, 3, 4); // 3 rows, 4 cols
		System.out.println("*********************************");
		System.out.println("  Test SeatingChart Constructor");
		System.out.println("*********************************");
		introCS.printChart();

		introCS.removeAbsentStudents(4);

		System.out.println("******************************");
		System.out.println("  Test removeAbsentStudents");
		System.out.println("******************************");
		introCS.printChart();


	}
}