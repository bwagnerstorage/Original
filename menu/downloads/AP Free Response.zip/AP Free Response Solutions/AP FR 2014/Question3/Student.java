public class Student
{
	private String name;
	private int absenceCount;

	public Student(String n, int a)
	{
		name = n;
		absenceCount = a;
	}

	/** Returns the name of this student */
	public String getName()
	{
		return name;
	}

	/** Returns the number of times this Student has missed class */
	public int getAbsenceCount()
	{
		return absenceCount;
	}

	public String toString()
	{
		return "[" + name + ", " + absenceCount + "]";
	}

	// There may be instance variables, constructors, and methods not shown.

}