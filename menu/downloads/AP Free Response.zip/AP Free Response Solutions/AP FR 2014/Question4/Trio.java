public class Trio implements MenuItem
{
	private Sandwich sandwich;
	private Salad salad;
	private Drink drink;

    public Trio(Sandwich san, Salad sal, Drink d)
    {
    	sandwich = san;
    	salad = sal;
    	drink = d;
    }

	public String getName()
	{
		return sandwich.getName() + "/" + salad.getName() + "/" + drink.getName();
	}

	public double getPrice()
	{
		double lowest = sandwich.getPrice();

		if(salad.getPrice() < lowest)
		{
			lowest = salad.getPrice();
		}
		if(drink.getPrice() < lowest)
		{
			lowest = drink.getPrice();
		}

		return sandwich.getPrice() + salad.getPrice() + drink.getPrice() - lowest;
	}
}