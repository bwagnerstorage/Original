public class LunchMenu
{
	public static void main(String[] args)
	{
		Sandwich sandwich;
		Salad salad;
		Drink drink;
		Trio trio;

		sandwich = new Sandwich("Cheeseburger", 2.75);
		salad = new Salad("Spinach Salad", 1.25);
		drink = new Drink("Orange Soda", 1.25);

		trio = new Trio(sandwich, salad, drink);

		System.out.println("************");
		System.out.println("   Trio 1   ");
		System.out.println("************");

		System.out.print(trio.getName() + "   ");
		System.out.printf("$%.2f%n", trio.getPrice());
		System.out.println();

		sandwich = new Sandwich("Club Sandwich", 2.75);
		salad = new Salad("Coleslaw", 1.25);
		drink = new Drink("Cappuccino", 3.50);

		trio = new Trio(sandwich, salad, drink);

		System.out.println("************");
		System.out.println("   Trio 2   ");
		System.out.println("************");

		System.out.print(trio.getName() + "   ");
		System.out.printf("$%.2f%n", trio.getPrice());
		System.out.println();


	}
}