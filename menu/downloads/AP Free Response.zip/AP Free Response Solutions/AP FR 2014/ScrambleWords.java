import java.util.*;

public class ScrambleWords
{
	// Part(a)
	/** Scrambles a given word.
	 *  @param word the word to be scrambled
	 *  @return the scrambled word (possibly equal to word)
	 *  Precondition: word is either an empty string or contains only uppercase letters.
	 *  Postcondition: the string returned was created from word as follows:
	 *   - the word was scrambled, beginning at the first letter and continuing from left to right
	 *   - two consecutive letters consisting of "A" followed by a letter that was not "A" were swapped
	 *   - letters were swapped at most once
	 */
	 public static String scrambledWord(String word)
	 {
	 	String str = "";
		for(int i=0; i < word.length();i++)
		{
			if(i+1 < word.length() &&
			    word.substring(i, i+1).equals("A") &&
			   !word.substring(i+1, i+2).equals("A"))
			{
				str+=word.substring(i+1, i+2) + word.substring(i, i+1);
				i++;
			}
			else
			{
				str+=word.substring(i, i+1);
			}
		}

		return str;
	 }

	 // Part (b)
	 /** Modifies wordlist by replacing each word with its scrambled
	  *  version, removing any words that are unchanged as a result of scrambling.
	  *  @param wordlist the list of words
	  *  Precondition: wordList contains only non-null objects
	  *  Postcondition:
	  *  - all words unchanged by scrambling have been removed from wordList
	  *  - each of the remaining words has been replaced by its scrambled version
	  *  - the relative ordering of the entries in wordList is the same as it was
	  *       before the method was called
	  */
	 public static void scrambledOrRemove(List<String> wordList)
	 {
		int i = 0;
		while(i < wordList.size())
		{
			String scrambled = scrambledWord(wordList.get(i));
			if(wordList.get(i).equals(scrambled))
			{
				wordList.remove(i);
			}
			else
			{
				wordList.set(i, scrambled);
				i++;
			}
		}
	 }

	 public static void print(List<String> list)
	 {
	 	for(String s : list)
	 	{
	 		System.out.print(s + " ");
	 	}
	 	System.out.println("\n");
	 }

	 public static void main(String[] args)
	 {
	 	System.out.println("**********************");
	 	System.out.println("  Test scrambledWord  ");
	 	System.out.println("**********************");

	 	System.out.println("TAN = " + scrambledWord("TAN"));
	 	System.out.println("ABRACADABRA = " + scrambledWord("ABRACADABRA"));
	 	System.out.println("WHOA = " + scrambledWord("WHOA"));
	 	System.out.println("AARDVARK = " + scrambledWord("AARDVARK"));
	 	System.out.println("EGGS = "+ scrambledWord("EGGS"));
	 	System.out.println("A = " + scrambledWord("A"));
	 	System.out.println("null = " + scrambledWord(""));

	 	List<String> list = new ArrayList();
	 	list.add("TAN");
	 	list.add("ABRACADABRA");
	 	list.add("WHOA");
	 	list.add("APPLE");
	 	list.add("EGGS");

		System.out.println();
	 	System.out.println("**************************");
	 	System.out.println("  Test scrambledOrRemove  ");
	 	System.out.println("**************************");

	 	print(list);

	 	scrambledOrRemove(list);

	 	print(list);
	 }
}