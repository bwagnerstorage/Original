public class Pack implements Product
{
	private int numProducts;
	private Product prod;
	
	public Pack(int num, Product p)
	{
	   numProducts = num;
	   prod = p;
	}
	public double getPrice()
	{
	   return prod.getPrice() * numProducts;
	}
	
	public String getDescription()
	{
		return numProducts + " X " + prod.getDescription();
	}
	
	public String getType()
	{
		return "Pack";
	}
}