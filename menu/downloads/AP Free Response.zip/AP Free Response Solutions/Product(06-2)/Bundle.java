import java.util.*;

public class Bundle implements Product
{
	private ArrayList<Product> productList;
	private String bundleDescription;
	
	public Bundle(String description)
	{
		productList = new ArrayList<Product>();
		bundleDescription = description;
	}
	
	public void add(Product newProd)
	{
		productList.add(newProd);
	}
	
	public double getPrice()
	{
		double totalCost = 0.0;
		for (int i = 0; i < productList.size(); i++)
		{
			totalCost += ((Product)productList.get(i)).getPrice();
		}
		return totalCost;
	}
	
	public String getDescription()
	{
		String str = bundleDescription + " containing";
		for(Product p : productList)
		{
			str += "\n" + p.getDescription();
		}
		return str;
	}
	
	public String getType()
	{
		return "Bundle";
	}
}