public class Item implements Product
{
    private String itemDescription;   // description of this item
    private double unitPrice;         // price of this item, in dollars
          
    public Item(String description, double price)
    {
        itemDescription = description; 
        unitPrice = price;
    }
          
    // returns the price of this item 
    public double getPrice()
    {
        return unitPrice;
    }
    
    // sets the price of this item
    public void setPrice(double price)
    {
        unitPrice = price;
    }
    
    // returns the description of this item
    public String getDescription()
    {
        return itemDescription;
    }
    
    public String getType()
    {
    	return "Item";
    }
}