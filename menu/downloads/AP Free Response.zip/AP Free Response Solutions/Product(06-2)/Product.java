public interface Product 
{ 
   double getPrice();
   String getDescription();
   String getType();
}