public class Driver
{
	public static void main(String[] args)
	{
		Product oven = new Item("ZapIt Microwave Oven", 90.0); 
		Product toaster = new Item("NeverBurn Toaster", 20.0); 
		Product toasterPack = new Pack(4, toaster); 
		
		Bundle homeCookingKit = new Bundle("Home Cooking Kit"); 
		homeCookingKit.add(oven); 
		homeCookingKit.add(toaster); 
		
		Bundle restaurantStarterKit = new Bundle("Restaurant Starter Kit"); 
		restaurantStarterKit.add(homeCookingKit); restaurantStarterKit.add(toasterPack); 
		Product homeKitPack = new Pack(5, homeCookingKit);
		
		System.out.println();
		System.out.println(oven.getDescription());
		System.out.println(oven.getPrice());
		System.out.println(oven.getType());
		System.out.println();
		System.out.println(toaster.getDescription());
		System.out.println(toaster.getPrice());
		System.out.println(toaster.getType());
		System.out.println();
		System.out.println(toasterPack.getDescription());
		System.out.println(toasterPack.getPrice());
		System.out.println(toasterPack.getType());
		System.out.println();
		System.out.println(homeCookingKit.getDescription());
		System.out.println(homeCookingKit.getPrice());
		System.out.println(homeCookingKit.getType());
		System.out.println();
		System.out.println(restaurantStarterKit.getDescription());
		System.out.println(restaurantStarterKit.getPrice());
		System.out.println(restaurantStarterKit.getType());
		System.out.println();
		System.out.println(homeKitPack.getDescription());
		System.out.println(homeKitPack.getPrice());
		System.out.println(homeKitPack.getType());
		System.out.println();
	}
}
