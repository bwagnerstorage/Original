public class StringPart
{
	private int startPos;
	private int length;
	
   /** @param start the starting position of the substring in a master string
    * @param length the length of the substring in a master string
    */
   public StringPart(int start, int length)
   {
      startPos = start;
      this.length = length;	
   }
   
   /** @return the starting position of the substring in a master string
    */
   public int getStart()
   { 
      return startPos;
   }
   
   /** @return the length of the substring in a master string
    */
   public int getLength()
   { 
      return length;  
   }
}