import java.util.*;

public class Driver
{
	public static void main(String[] args)
	{
		String masterString = "sixtyzipperswerequicklypickedfromthewovenjutebag";
		
		StringCoder coder = new StringCoder(masterString);
		
		// test decodeString (part a)
		System.out.println("Test 1");
		System.out.println("------");
		ArrayList<StringPart> parts = new ArrayList<StringPart>();
		parts.add(new StringPart(37, 3)); 
		parts.add(new StringPart(14, 2));
		parts.add(new StringPart(46, 2));
		parts.add(new StringPart(9, 2));
		
		String str = coder.decodeString(parts);
		System.out.println(str);
		System.out.println();
		
		// test encodeString (part b)
	    parts = coder.encodeString("overeager");
	    for(StringPart part : parts)
	    {
	    	System.out.print("[" + part.getStart() + "," + part.getLength() + "],");
	    }
	    System.out.println();
	    System.out.println();
	    System.out.println("Test 2");
	    System.out.println("------");
	    
	    parts = new ArrayList<StringPart>();
		parts.add(new StringPart(1, 1)); 
		parts.add(new StringPart(46, 1));
		parts.add(new StringPart(32, 1));
		parts.add(new StringPart(0, 1));
		parts.add(new StringPart(24, 3));
		parts.add(new StringPart(31, 1));	
		parts.add(new StringPart(29, 1));
		parts.add(new StringPart(23, 4));
		parts.add(new StringPart(21, 1));
		parts.add(new StringPart(9, 1));
		parts.add(new StringPart(0, 1));
		
		str = coder.decodeString(parts);
		System.out.println(str);
		System.out.println();
	    
	    parts = coder.encodeString("iamsickofpickles");
	    for(StringPart part : parts)
	    {
	    	System.out.print("[" + part.getStart() + "," + part.getLength() + "],");
	    }
	    System.out.println();
	    System.out.println();
	}
}