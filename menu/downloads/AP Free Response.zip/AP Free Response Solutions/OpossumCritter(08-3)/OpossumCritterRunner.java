/* 
 * AP(r) Computer Science GridWorld Case Study:
 * Copyright(c) 2005-2006 Cay S. Horstmann (http://horstmann.com)
 *
 * This code is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * @author Chris Nevison
 * @author Barbara Cloud Wells
 * @author Cay Horstmann
 */

import info.gridworld.actor.*;
import info.gridworld.grid.Location;

import java.awt.Color;

/**
 * This class runs a world that contains chameleon critters. <br />
 * This class is not tested on the AP CS A and AB exams.
 */
public class OpossumCritterRunner
{
    public static void main(String[] args)
    {
        ActorWorld world = new ActorWorld();
        
        Actor actor1 = new Critter();
        Actor actor2 = new Critter();
        Actor actor3 = new Critter();
        Actor actor4 = new Critter();
        Actor actor5 = new Critter();
        Actor actor6 = new Critter();
        Actor actor7 = new Critter();
        Actor actor8 = new Critter();
        Actor actor9 = new Critter();
        Actor actor10 = new Critter();
        Actor actor11 = new Critter();
        Actor actor12 = new Critter();
        Actor actor13 = new Critter();
        Actor actor14 = new Critter();
        Actor actor15 = new Critter();
        Actor actor16 = new Critter();
        Actor actor17 = new Critter();
        
        actor1.setColor(Color.RED);
        actor2.setColor(Color.RED);
        actor3.setColor(Color.RED);
        actor4.setColor(Color.RED);
        actor5.setColor(Color.RED);
        actor6.setColor(Color.RED);
        actor7.setColor(Color.RED);
        actor8.setColor(Color.RED); 
        actor9.setColor(Color.GREEN); 
        actor10.setColor(Color.GREEN);  
        actor11.setColor(Color.GREEN);
        actor12.setColor(Color.GREEN);
        actor13.setColor(Color.GREEN);
        actor14.setColor(Color.GREEN); 
        actor15.setColor(Color.GREEN);
        actor16.setColor(Color.BLUE);
        actor17.setColor(Color.YELLOW);   
        
        world.add(new Location(7, 8), actor1);
        world.add(new Location(3, 3), actor2);
        world.add(new Location(2, 8), actor3);
        world.add(new Location(5, 2), actor4);
        world.add(new Location(1, 5), actor5);
        world.add(new Location(7, 2), actor6);
        world.add(new Location(4, 3), actor7);
        world.add(new Location(5, 8), actor8);
        world.add(new Location(3, 6), actor9);
        world.add(new Location(6, 3), actor10);
        world.add(new Location(2, 2), actor11);
        world.add(new Location(3, 4), actor12);
        world.add(new Location(4, 7), actor13);
        world.add(new Location(1, 3), actor14);
        world.add(new Location(9, 9), actor15);
        world.add(new Location(4, 4), actor16);
        world.add(new Location(7, 4), actor17);
        
        world.add(new Location(5, 5), new OpossumCritter());
        world.show();
    }
}